# How the bundle works

## 1. Compiler bootstrap

The bootstrap composition root contains only the PSC2 TypeScript compiler
composition. No kernel package is part of the generated compiler closure.

The canonical generated workspace in `compiler/workspace/` contains 55 `.ps`
modules. Those sources produce the generated compiler in `compiler/index.js`
and `compiler/index.ts`.

The compiler fixed-point evidence for this bundle is:

```text
source modules: 55
source closure SHA-256:
ee6dd22f1b74b97113cc1a5e36aadad3cceecb2b152653f2c0dc26dd07aa22f7

generated TypeScript SHA-256:
fb173a348d1555d1ff224b9977f6fee68591b79f781a6b292c2572648415b033

generated JavaScript SHA-256:
74dcebb7b296d81924d92987e99146b5d1c5ff9fbe3d8076ca591952d2ef7f76
```

The bootstrap and selfhost generations produced identical canonical sources and
identical TypeScript.

## 2. Canonical admissions boundary

PSC2 does not ask the kernel to parse ProofScript or Lean source text. The generated
compiler parses/elaborates its source and serializes a canonical checked-admissions
v2 request.

The exact request for the bundled compiler is:

```text
compiler/index.admissions.json
SHA-256:
8ba49927746a84c3925abebfbd62ecbdb78c05c3fe6a2c09c95ca29088044f22
```

This separation keeps compiler syntax/elaboration independent from the kernel
implementation.

## 3. Lean WASM kernel

`pskernel-lean-wasm/wasm/pskernel-lean.cjs` launches the bundled WebAssembly module
`pskernel-lean.wasm`. The module contains the provider path around the real pinned
Lean kernel.

Kernel identity:

```text
protocol: pskernel-lean/1
provider: lean4-cpp
Lean: 4.34.0
Lean commit: 293d5d0c0c3f3dded4688b3ccd6a33939ac5102b
profile: lean4.34-core
execution: wasm-node
```

The WASM build is pinned to Emscripten 6.0.9. The package includes its prebuilt
manifest and source manifests so the runtime bytes can be tied back to the intended
Lean/provider source snapshots.

## 4. Checked build order

The intended checked build boundary is:

```text
ProofScript source closure
        |
        v
generated PSC2 compiler
        |
        +--> parse / elaborate
        |
        +--> canonical admissions v2
                    |
                    v
        pskernel-lean-wasm
                    |
                    v
          Lean 4.34 kernel
             /           \
          reject        accept
           |               |
     no output         TS emission
                           |
                           v
                    TypeScript -> JS
```

Kernel rejection is fail-closed. A failed kernel check is not converted into a
successful build and does not select another provider automatically.

## 5. Why the kernel is outside bootstrap

The active architecture is compiler-only self-hosting. This avoids making compiler
completion depend on a second self-hosted kernel project.

The kernel is an assurance boundary supplied by a pinned external implementation.
That means the bootstrap closure stays at 55 compiler modules and remains capable of
reproducing the compiler independently of the kernel package.

The external kernel is then used to validate the compiler's canonical declarations.

## 6. Fixed-point versus kernel assurance

Two properties are intentionally distinct:

1. **Compiler fixed point** — generated compiler source and generated TypeScript are
   stable across generations.
2. **Kernel acceptance** — canonical declarations produced by the compiler are
   accepted by the pinned Lean kernel.

The checked receipt in `compiler/index.checked.json` binds both pieces together:
compiler identity, source closure hash, canonical admissions hash, TypeScript hash,
JavaScript hash, and kernel provider identity.
