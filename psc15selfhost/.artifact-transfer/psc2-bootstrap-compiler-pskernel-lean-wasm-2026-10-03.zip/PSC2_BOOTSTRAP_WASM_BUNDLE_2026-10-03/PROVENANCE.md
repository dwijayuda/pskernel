# Provenance

Bundle date: 2026-10-03

Repository:

```text
dwijayuda/pskernel
branch: psc2/selfhost-lean-kernel
```

The compiler/WASM artifacts in this bundle come from the proven checked-bootstrap
worktree whose compiler fixed-point receipt was recorded at:

```text
d4298a712d1e2ea6505185d311e9af10a698b2ca
Record compiler-only self-host fixed point
```

The branch later gained native-provider performance work; that does not change the
compiler or WASM artifacts bundled here.

## Compiler identities

```text
source count: 55
source closure:
ee6dd22f1b74b97113cc1a5e36aadad3cceecb2b152653f2c0dc26dd07aa22f7

canonical admissions:
8ba49927746a84c3925abebfbd62ecbdb78c05c3fe6a2c09c95ca29088044f22

TypeScript:
fb173a348d1555d1ff224b9977f6fee68591b79f781a6b292c2572648415b033

JavaScript:
74dcebb7b296d81924d92987e99146b5d1c5ff9fbe3d8076ca591952d2ef7f76
```

## Kernel identities

```text
package: @proofscript/pskernel-lean-wasm@4.34.0
protocol: pskernel-lean/1
provider: lean4-cpp
Lean version: 4.34.0
Lean commit: 293d5d0c0c3f3dded4688b3ccd6a33939ac5102b
profile: lean4.34-core
Emscripten: 6.0.9
provider source revision:
1b21b2483df7e8de7542873c24eaff2501539b1b
```

The authoritative per-artifact runtime hashes are also stored in
`pskernel-lean-wasm/PREBUILT_WASM_MANIFEST.json`.

## Checked receipt

`compiler/index.checked.json` is copied from the successful
`lean434-wasm` checked bootstrap. It records the kernel selector, provider identity,
compiler identity, source closure, admissions hash, TypeScript hash and JavaScript
hash.
