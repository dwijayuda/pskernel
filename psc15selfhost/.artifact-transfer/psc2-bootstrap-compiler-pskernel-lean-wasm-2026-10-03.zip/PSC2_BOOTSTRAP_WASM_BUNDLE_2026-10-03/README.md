# PSC2 compiler bootstrap + Lean 4.34 WASM kernel bundle

This ZIP contains a working, generated PSC2 compiler bootstrap and the external
`@proofscript/pskernel-lean-wasm` provider that checked it.

## What is included

- `compiler/index.js` — generated self-hosted compiler JavaScript.
- `compiler/index.ts` — canonical generated TypeScript.
- `compiler/index.d.ts` and `compiler/index.js.map`.
- `compiler/index.admissions.json` — canonical admissions for the compiler closure.
- `compiler/index.checked.json` — the checked-build receipt.
- `compiler/workspace/` — all 55 canonical generated ProofScript source modules.
- `pskernel-lean-wasm/` — runnable Lean 4.34 WASM provider, manifests, audit source,
  and rebuild documentation.
- `tools/check-compiler-admissions.mjs` — re-check the bundled compiler admissions.
- `tools/verify-bundle.mjs` — verify file hashes, receipt identities, source count,
  provider health, and kernel acceptance.
- `HOW_IT_WORKS.md` — architecture and trust boundary.
- `USAGE.md` — commands and API examples.
- `PROVENANCE.md` — exact source/toolchain identities and fixed-point hashes.

## Quick start

Requirement: Node.js 20 or newer.

From the extracted directory:

```text
node tools/verify-bundle.mjs
```

Expected final markers:

```text
PSC2_BUNDLE_HASHES: PASS
PSC2_BUNDLE_WASM_HEALTH: PASS
PSC2_BUNDLE_COMPILER_ADMISSIONS: PASS
PSC2_BUNDLE: PASS
```

You can also check only the kernel:

```text
node pskernel-lean-wasm/wasm/pskernel-lean.cjs --health
node tools/check-compiler-admissions.mjs
```

## Scope of the claim

The compiler is self-hosted: the canonical 55-module compiler source workspace
reproduces itself and reproduces byte-identical generated TypeScript.

The kernel is deliberately external. It is the pinned Lean 4.34.0 kernel compiled
to WebAssembly. This bundle does **not** claim that the kernel self-hosts or that a
joint compiler/kernel fixed point exists.
