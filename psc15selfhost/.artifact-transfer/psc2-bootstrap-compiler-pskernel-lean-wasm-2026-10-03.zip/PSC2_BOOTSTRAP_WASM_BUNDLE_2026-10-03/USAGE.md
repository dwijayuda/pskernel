# Usage

## Requirements

- Node.js 20 or newer.
- No local Lean installation is required to run the bundled WASM provider.
- No Emscripten installation is required unless you intentionally rebuild the WASM
  artifact.

## Verify everything

```text
node tools/verify-bundle.mjs
```

The verifier:

1. checks every file against `BUNDLE_MANIFEST.json`;
2. checks the compiler receipt and canonical workspace identity;
3. verifies that exactly 55 canonical `.ps` sources are present;
4. starts the bundled Lean WASM provider and validates its identity;
5. sends the exact compiler admissions to the kernel and requires acceptance.

## Provider health

```text
node pskernel-lean-wasm/wasm/pskernel-lean.cjs --health
```

The response identifies the protocol, provider, Lean version, Lean commit and profile.

## Check the bundled compiler admissions

```text
node tools/check-compiler-admissions.mjs
```

This reads `compiler/index.admissions.json` and calls the public
`checkCanonicalAdmissions` API from the bundled WASM package.

## Use the kernel API from Node

```js
import { readFile } from 'node:fs/promises';
import { checkCanonicalAdmissions } from './pskernel-lean-wasm/index.mjs';

const admissions = await readFile(
  './compiler/index.admissions.json',
  'utf8',
);

const result = await checkCanonicalAdmissions(admissions);
console.log(result);
```

A valid request returns `accepted: true`. A semantic rejection returns
`accepted: false` with a stable `errorKind` and normally a declaration index.

## Import the generated compiler

```js
import * as compiler from './compiler/index.js';

console.log(compiler.PsCompilerSourceKind);
console.log(typeof compiler.psCompilerPrepareSource);
console.log(typeof compiler.psCompilerAdmissionsSource);
console.log(typeof compiler.psCompilerTypeScriptSource);
```

Important generated APIs include:

- `psCompilerParseSource`
- `psCompilerElaborateSource`
- `psCompilerPrepareSource`
- `psCompilerPrepareSources`
- `psCompilerAdmissionsSource`
- `psCompilerAdmissionsFromPrepared`
- `psCompilerTypeScriptSource`
- `psCompilerTypeScriptFromPrepared`

For an isolated/self-contained source you can call these directly. Real multi-module
projects must provide the complete ordered source closure so imports, environments and
declaration order match the compiler model. The 55-module canonical workspace included
in this ZIP is the reference example.

The original repository's checked-build host adds source-closure collection,
kernel-gating, TypeScript 5.8.3 pinning, atomic staging, and checked receipts around
these generated APIs.

## Direct CLI-style WASM invocation

The low-level provider accepts its canonical request on stdin:

PowerShell:

```text
Get-Content -Raw compiler/index.admissions.json |
  node pskernel-lean-wasm/wasm/pskernel-lean.cjs --check
```

POSIX shell:

```text
cat compiler/index.admissions.json |
  node pskernel-lean-wasm/wasm/pskernel-lean.cjs --check
```

## Rebuilding the WASM provider

See:

```text
pskernel-lean-wasm/BUILDING.md
```

A rebuild requires the exact Lean 4.34 source commit and the pinned Emscripten
toolchain. Normal use of this ZIP does not require rebuilding it.
