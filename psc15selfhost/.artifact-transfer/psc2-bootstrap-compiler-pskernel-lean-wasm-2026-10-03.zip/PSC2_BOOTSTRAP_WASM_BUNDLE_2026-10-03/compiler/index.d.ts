declare const __ps$brand$0: unique symbol;
export interface Prod<T0, T1> {
    readonly [__ps$brand$0]: true;
    readonly fst: T0;
    readonly snd: T1;
}
declare const __ps$brand$1: unique symbol;
export interface PsSourcePos {
    readonly [__ps$brand$1]: true;
    readonly byteOffset: bigint;
    readonly line: bigint;
    readonly column: bigint;
}
declare const __ps$brand$2: unique symbol;
export interface PsSourceSpan {
    readonly [__ps$brand$2]: true;
    readonly start: PsSourcePos;
    readonly stop: PsSourcePos;
}
declare const __ps$brand$3: unique symbol;
export interface PsLexCursor {
    readonly [__ps$brand$3]: true;
    readonly remaining: List<string>;
    readonly position: PsSourcePos;
}
declare const __ps$brand$4: unique symbol;
export interface PsLexStep {
    readonly [__ps$brand$4]: true;
    readonly char: string;
    readonly cursor: PsLexCursor;
}
declare const __ps$brand$5: unique symbol;
export interface PsToken {
    readonly [__ps$brand$5]: true;
    readonly kind: PsTokenKind;
    readonly text: string;
    readonly span: PsSourceSpan;
}
declare const __ps$brand$6: unique symbol;
export interface PsLexRead {
    readonly [__ps$brand$6]: true;
    readonly cursor: PsLexCursor;
    readonly charsRev: List<string>;
}
declare const __ps$brand$7: unique symbol;
export interface PsSyntaxName {
    readonly [__ps$brand$7]: true;
    readonly segments: List<string>;
    readonly span: PsSourceSpan;
}
declare const __ps$brand$8: unique symbol;
export interface PsSyntaxBinderHead {
    readonly [__ps$brand$8]: true;
    readonly name: PsSyntaxName;
    readonly kind: PsSyntaxBinderKind;
    readonly span: PsSourceSpan;
}
declare const __ps$brand$9: unique symbol;
export interface PsSyntaxInductiveConstructor {
    readonly [__ps$brand$9]: true;
    readonly name: PsSyntaxName;
    readonly fields: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>;
    readonly span: PsSourceSpan;
}
declare const __ps$brand$10: unique symbol;
export interface PsSyntaxImport {
    readonly [__ps$brand$10]: true;
    readonly moduleName: PsSyntaxName;
    readonly span: PsSourceSpan;
}
declare const __ps$brand$11: unique symbol;
export interface PsSyntaxModule {
    readonly [__ps$brand$11]: true;
    readonly imports: List<PsSyntaxImport>;
    readonly declarations: List<PsSyntaxDeclaration>;
}
declare const __ps$brand$12: unique symbol;
export interface PsTokenCursor {
    readonly [__ps$brand$12]: true;
    readonly remaining: List<PsToken>;
}
declare const __ps$brand$13: unique symbol;
export interface PsTokenRead {
    readonly [__ps$brand$13]: true;
    readonly token: PsToken;
    readonly cursor: PsTokenCursor;
}
declare const __ps$brand$14: unique symbol;
export interface PsParseResult<T0> {
    readonly [__ps$brand$14]: true;
    readonly value: T0;
    readonly cursor: PsTokenCursor;
}
declare const __ps$brand$15: unique symbol;
export interface PsSyntaxBinderOpening {
    readonly [__ps$brand$15]: true;
    readonly kind: PsSyntaxBinderKind;
    readonly start: PsSourcePos;
    readonly closeText: string;
    readonly closeCount: bigint;
    readonly cursor: PsTokenCursor;
}
declare const __ps$brand$16: unique symbol;
export interface PsLeanEquationClause {
    readonly [__ps$brand$16]: true;
    readonly patterns: List<PsSyntaxPattern>;
    readonly body: PsSyntaxTerm;
    readonly span: PsSourceSpan;
}
declare const __ps$brand$17: unique symbol;
export interface PsProofScriptCallArgs {
    readonly [__ps$brand$17]: true;
    readonly args: List<PsSyntaxTerm>;
    readonly closeSpan: PsSourceSpan;
    readonly cursor: PsTokenCursor;
}
declare const __ps$brand$18: unique symbol;
export interface PsJsonParseResult {
    readonly [__ps$brand$18]: true;
    readonly value: PsJsonValue;
    readonly rest: List<string>;
}
declare const __ps$brand$19: unique symbol;
export interface PsInductiveInfo {
    readonly [__ps$brand$19]: true;
    readonly name: PsName;
    readonly levelParams: List<PsName>;
    readonly type: PsExpr;
    readonly numParams: bigint;
    readonly numIndices: bigint;
    readonly constructors: List<PsName>;
    readonly isStructure: boolean;
}
declare const __ps$brand$20: unique symbol;
export interface PsConstructorInfo {
    readonly [__ps$brand$20]: true;
    readonly name: PsName;
    readonly levelParams: List<PsName>;
    readonly type: PsExpr;
    readonly inductiveName: PsName;
    readonly constructorIndex: bigint;
    readonly numParams: bigint;
    readonly numFields: bigint;
    readonly recursiveFields: List<bigint>;
}
declare const __ps$brand$21: unique symbol;
export interface PsRecursorInfo {
    readonly [__ps$brand$21]: true;
    readonly name: PsName;
    readonly levelParams: List<PsName>;
    readonly type: PsExpr;
    readonly inductiveNames: List<PsName>;
    readonly numParams: bigint;
    readonly numIndices: bigint;
    readonly numMotives: bigint;
    readonly numMinors: bigint;
}
declare const __ps$brand$22: unique symbol;
export interface PsEnvironment {
    readonly [__ps$brand$22]: true;
    readonly declarations: List<PsDeclaration>;
    readonly index: PsEnvironmentIndex;
}
declare const __ps$brand$23: unique symbol;
export interface PsCheckedAdmissionEncodeState {
    readonly [__ps$brand$23]: true;
    readonly heights: PsBridgeHeightIndex;
    readonly admissionsRev: List<string>;
}
declare const __ps$brand$24: unique symbol;
export interface PsCheckedNestedBinder {
    readonly [__ps$brand$24]: true;
    readonly id: bigint;
    readonly name: PsName;
    readonly type: PsExpr;
}
declare const __ps$brand$25: unique symbol;
export interface PsCheckedNestedMinor {
    readonly [__ps$brand$25]: true;
    readonly binder: PsCheckedNestedBinder;
    readonly adapter: PsExpr;
}
declare const __ps$brand$26: unique symbol;
export interface PsLocalContext {
    readonly [__ps$brand$26]: true;
    readonly nextId: bigint;
    readonly declarations: List<PsLocalDecl>;
}
declare const __ps$brand$27: unique symbol;
export interface PsLocalPushResult {
    readonly [__ps$brand$27]: true;
    readonly context: PsLocalContext;
    readonly id: bigint;
}
declare const __ps$brand$28: unique symbol;
export interface PsLevelAssignment {
    readonly [__ps$brand$28]: true;
    readonly id: bigint;
    readonly value: PsLevel;
}
declare const __ps$brand$29: unique symbol;
export interface PsLevelMetaContext {
    readonly [__ps$brand$29]: true;
    readonly nextId: bigint;
    readonly declarations: List<bigint>;
    readonly assignments: List<PsLevelAssignment>;
}
declare const __ps$brand$30: unique symbol;
export interface PsLevelFreshResult {
    readonly [__ps$brand$30]: true;
    readonly context: PsLevelMetaContext;
    readonly level: PsLevel;
}
declare const __ps$brand$31: unique symbol;
export interface PsLevelUnifyResult {
    readonly [__ps$brand$31]: true;
    readonly context: PsLevelMetaContext;
    readonly success: boolean;
}
declare const __ps$brand$32: unique symbol;
export interface PsMetaVarDecl {
    readonly [__ps$brand$32]: true;
    readonly id: bigint;
    readonly type: PsExpr;
    readonly localContext: PsLocalContext;
    readonly kind: PsMetaVarKind;
}
declare const __ps$brand$33: unique symbol;
export interface PsMetaAssignment {
    readonly [__ps$brand$33]: true;
    readonly id: bigint;
    readonly value: PsExpr;
}
declare const __ps$brand$34: unique symbol;
export interface PsMetaContext {
    readonly [__ps$brand$34]: true;
    readonly nextId: bigint;
    readonly declarations: List<PsMetaVarDecl>;
    readonly assignments: List<PsMetaAssignment>;
    readonly levels: PsLevelMetaContext;
}
declare const __ps$brand$35: unique symbol;
export interface PsMetaFreshResult {
    readonly [__ps$brand$35]: true;
    readonly context: PsMetaContext;
    readonly expr: PsExpr;
}
declare const __ps$brand$36: unique symbol;
export interface PsMetaFreshLevelResult {
    readonly [__ps$brand$36]: true;
    readonly context: PsMetaContext;
    readonly level: PsLevel;
}
declare const __ps$brand$37: unique symbol;
export interface PsForallView {
    readonly [__ps$brand$37]: true;
    readonly name: PsName;
    readonly domain: PsExpr;
    readonly body: PsExpr;
    readonly binder: PsBinderInfo;
}
declare const __ps$brand$38: unique symbol;
export interface PsInferAppView {
    readonly [__ps$brand$38]: true;
    readonly head: PsExpr;
    readonly args: List<PsExpr>;
}
declare const __ps$brand$39: unique symbol;
export interface PsInstanceEntry {
    readonly [__ps$brand$39]: true;
    readonly value: PsExpr;
    readonly type: PsExpr;
}
declare const __ps$brand$40: unique symbol;
export interface PsInstanceIndex {
    readonly [__ps$brand$40]: true;
    readonly entries: List<PsInstanceEntry>;
}
declare const __ps$brand$41: unique symbol;
export interface PsUnifyResult {
    readonly [__ps$brand$41]: true;
    readonly context: PsMetaContext;
    readonly success: boolean;
}
declare const __ps$brand$42: unique symbol;
export interface PsPreparedInstanceArgument {
    readonly [__ps$brand$42]: true;
    readonly expr: PsExpr;
    readonly type: PsExpr;
    readonly isInstance: boolean;
}
declare const __ps$brand$43: unique symbol;
export interface PsPreparedInstance {
    readonly [__ps$brand$43]: true;
    readonly context: PsMetaContext;
    readonly value: PsExpr;
    readonly resultType: PsExpr;
    readonly arguments: List<PsPreparedInstanceArgument>;
    readonly success: boolean;
}
declare const __ps$brand$44: unique symbol;
export interface PsSynthInstanceResult {
    readonly [__ps$brand$44]: true;
    readonly context: PsMetaContext;
    readonly value: Option<PsExpr>;
}
declare const __ps$brand$45: unique symbol;
export interface PsSolveInstanceArgsResult {
    readonly [__ps$brand$45]: true;
    readonly context: PsMetaContext;
    readonly success: boolean;
}
declare const __ps$brand$46: unique symbol;
export interface PsElabStructuralRecursion {
    readonly [__ps$brand$46]: true;
    readonly functionName: PsName;
    readonly explicitParameterIds: List<bigint>;
    readonly recursiveParameterIndex: bigint;
    readonly calls: List<Prod<bigint, bigint>>;
}
declare const __ps$brand$47: unique symbol;
export interface PsElabContext {
    readonly [__ps$brand$47]: true;
    readonly environment: PsEnvironment;
    readonly localContext: PsLocalContext;
    readonly instances: PsInstanceIndex;
    readonly metaContext: PsMetaContext;
    readonly structuralRecursion: Option<PsElabStructuralRecursion>;
}
declare const __ps$brand$48: unique symbol;
export interface PsElabTermResult {
    readonly [__ps$brand$48]: true;
    readonly context: PsElabContext;
    readonly term: PsExpr;
    readonly type: PsExpr;
}
declare const __ps$brand$49: unique symbol;
export interface PsElabTypedBinder {
    readonly [__ps$brand$49]: true;
    readonly id: bigint;
    readonly name: PsName;
    readonly type: PsExpr;
    readonly binder: PsBinderInfo;
}
declare const __ps$brand$50: unique symbol;
export interface PsElabTypedBindersResult {
    readonly [__ps$brand$50]: true;
    readonly context: PsElabContext;
    readonly bindersRev: List<PsElabTypedBinder>;
}
declare const __ps$brand$51: unique symbol;
export interface PsExprAppView {
    readonly [__ps$brand$51]: true;
    readonly head: PsExpr;
    readonly args: List<PsExpr>;
}
declare const __ps$brand$52: unique symbol;
export interface PsElabMatchAlternative {
    readonly [__ps$brand$52]: true;
    readonly constructorName: PsName;
    readonly pattern: PsSyntaxPattern;
    readonly body: PsSyntaxTerm;
    readonly span: PsSourceSpan;
}
declare const __ps$brand$53: unique symbol;
export interface PsElabMatchField {
    readonly [__ps$brand$53]: true;
    readonly id: bigint;
    readonly name: PsName;
    readonly type: PsExpr;
    readonly binder: PsBinderInfo;
}
declare const __ps$brand$54: unique symbol;
export interface PsElabMatchFieldsResult {
    readonly [__ps$brand$54]: true;
    readonly context: PsElabContext;
    readonly fieldsRev: List<PsElabMatchField>;
}
declare const __ps$brand$55: unique symbol;
export interface PsElabMatchHypothesesResult {
    readonly [__ps$brand$55]: true;
    readonly context: PsElabContext;
    readonly hypothesesRev: List<PsElabMatchField>;
}
declare const __ps$brand$56: unique symbol;
export interface PsElabMatchMinorResult {
    readonly [__ps$brand$56]: true;
    readonly context: PsElabContext;
    readonly term: PsExpr;
}
declare const __ps$brand$57: unique symbol;
export interface PsElabMatchMinorsResult {
    readonly [__ps$brand$57]: true;
    readonly context: PsElabContext;
    readonly minors: List<PsExpr>;
}
declare const __ps$brand$58: unique symbol;
export interface PsElabApplicationResult {
    readonly [__ps$brand$58]: true;
    readonly result: PsElabTermResult;
    readonly pendingInstancesRev: List<bigint>;
}
declare const __ps$brand$59: unique symbol;
export interface PsElabRecordCandidate {
    readonly [__ps$brand$59]: true;
    readonly constructorName: PsName;
    readonly fieldNames: List<string>;
}
declare const __ps$brand$60: unique symbol;
export interface PsElabDeclarationResult {
    readonly [__ps$brand$60]: true;
    readonly declaration: PsDeclaration;
    readonly metaContext: PsMetaContext;
}
declare const __ps$brand$61: unique symbol;
export interface PsElabDeclarationBatchResult {
    readonly [__ps$brand$61]: true;
    readonly declarations: List<PsDeclaration>;
}
declare const __ps$brand$62: unique symbol;
export interface PsElabConstructorBuildResult {
    readonly [__ps$brand$62]: true;
    readonly context: PsElabContext;
    readonly bindersRev: List<PsElabTypedBinder>;
}
declare const __ps$brand$63: unique symbol;
export interface PsElabModuleResult {
    readonly [__ps$brand$63]: true;
    readonly environment: PsEnvironment;
    readonly declarations: List<PsDeclaration>;
}
declare const __ps$brand$64: unique symbol;
export interface PsElabRecursorMinorsResult {
    readonly [__ps$brand$64]: true;
    readonly context: PsElabContext;
    readonly bindersRev: List<PsElabTypedBinder>;
}
declare const __ps$brand$65: unique symbol;
export interface PsVerifiedIrParameter {
    readonly [__ps$brand$65]: true;
    readonly name: string;
    readonly type: PsVerifiedIrType;
}
declare const __ps$brand$66: unique symbol;
export interface PsVerifiedIrMatchBinding {
    readonly [__ps$brand$66]: true;
    readonly field: string;
    readonly name: string;
    readonly type: PsVerifiedIrType;
}
declare const __ps$brand$67: unique symbol;
export interface PsVerifiedIrTypeParameter {
    readonly [__ps$brand$67]: true;
    readonly name: string;
}
declare const __ps$brand$68: unique symbol;
export interface PsVerifiedIrStructureField {
    readonly [__ps$brand$68]: true;
    readonly name: string;
    readonly type: PsVerifiedIrType;
}
declare const __ps$brand$69: unique symbol;
export interface PsVerifiedIrStructure {
    readonly [__ps$brand$69]: true;
    readonly name: string;
    readonly typeParameters: List<PsVerifiedIrTypeParameter>;
    readonly fields: List<PsVerifiedIrStructureField>;
}
declare const __ps$brand$70: unique symbol;
export interface PsVerifiedIrConstructorField {
    readonly [__ps$brand$70]: true;
    readonly name: string;
    readonly type: PsVerifiedIrType;
}
declare const __ps$brand$71: unique symbol;
export interface PsVerifiedIrConstructor {
    readonly [__ps$brand$71]: true;
    readonly name: string;
    readonly fields: List<PsVerifiedIrConstructorField>;
}
declare const __ps$brand$72: unique symbol;
export interface PsVerifiedIrInductive {
    readonly [__ps$brand$72]: true;
    readonly name: string;
    readonly typeParameters: List<PsVerifiedIrTypeParameter>;
    readonly constructors: List<PsVerifiedIrConstructor>;
}
declare const __ps$brand$73: unique symbol;
export interface PsVerifiedIrDeclaration {
    readonly [__ps$brand$73]: true;
    readonly name: string;
    readonly typeParameters: List<PsVerifiedIrTypeParameter>;
    readonly parameters: List<PsVerifiedIrParameter>;
    readonly resultType: PsVerifiedIrType;
    readonly body: PsVerifiedIrExpr;
}
declare const __ps$brand$74: unique symbol;
export interface PsVerifiedIrExternalImport {
    readonly [__ps$brand$74]: true;
    readonly localName: string;
    readonly source: string;
    readonly importedName: string;
    readonly type: PsVerifiedIrType;
}
declare const __ps$brand$75: unique symbol;
export interface PsVerifiedIrModule {
    readonly [__ps$brand$75]: true;
    readonly imports: List<PsVerifiedIrExternalImport>;
    readonly structures: List<PsVerifiedIrStructure>;
    readonly inductives: List<PsVerifiedIrInductive>;
    readonly declarations: List<PsVerifiedIrDeclaration>;
}
declare const __ps$brand$76: unique symbol;
export interface PsErasureDeclarationNames {
    readonly [__ps$brand$76]: true;
    readonly byCore: PsErasureNameIndex<string>;
    readonly byOutput: PsErasureNameIndex<boolean>;
    readonly count: bigint;
}
declare const __ps$brand$77: unique symbol;
export interface PsRuntimeStructureField {
    readonly [__ps$brand$77]: true;
    readonly sourceIndex: bigint;
    readonly projectionIndex: bigint;
    readonly name: string;
    readonly type: PsVerifiedIrType;
}
declare const __ps$brand$78: unique symbol;
export interface PsRuntimeStructureInfo {
    readonly [__ps$brand$78]: true;
    readonly name: string;
    readonly coreName: PsName;
    readonly constructorName: PsName;
    readonly numParams: bigint;
    readonly typeParameters: List<PsVerifiedIrTypeParameter>;
    readonly fields: List<PsRuntimeStructureField>;
}
declare const __ps$brand$79: unique symbol;
export interface PsRuntimeConstructorField {
    readonly [__ps$brand$79]: true;
    readonly sourceIndex: bigint;
    readonly name: string;
    readonly type: PsVerifiedIrType;
    readonly recursive: boolean;
}
declare const __ps$brand$80: unique symbol;
export interface PsRuntimeConstructorInfo {
    readonly [__ps$brand$80]: true;
    readonly inductiveName: string;
    readonly name: string;
    readonly coreName: PsName;
    readonly numParams: bigint;
    readonly fields: List<PsRuntimeConstructorField>;
}
declare const __ps$brand$81: unique symbol;
export interface PsRuntimeInductiveInfo {
    readonly [__ps$brand$81]: true;
    readonly name: string;
    readonly coreName: PsName;
    readonly recursorName: PsName;
    readonly numParams: bigint;
    readonly typeParameters: List<PsVerifiedIrTypeParameter>;
    readonly constructors: List<PsRuntimeConstructorInfo>;
}
declare const __ps$brand$82: unique symbol;
export interface PsErasureCurrentDefinition {
    readonly [__ps$brand$82]: true;
    readonly name: string;
    readonly runtimeParameters: List<string>;
}
declare const __ps$brand$83: unique symbol;
export interface PsErasureScope {
    readonly [__ps$brand$83]: true;
    readonly localContext: PsLocalContext;
    readonly runtimeLocals: List<Prod<bigint, string>>;
    readonly typeLocals: List<Prod<bigint, string>>;
    readonly erasedLocals: List<bigint>;
    readonly declarationNames: PsErasureDeclarationNames;
    readonly runtimeConstructors: PsErasureNameIndex<PsRuntimeConstructorInfo>;
    readonly runtimeRecursors: PsErasureNameIndex<PsRuntimeInductiveInfo>;
    readonly runtimeStructures: PsErasureNameIndex<PsRuntimeStructureInfo>;
    readonly runtimeStructureConstructors: PsErasureNameIndex<PsRuntimeStructureInfo>;
    readonly runtimeExpressions: List<Prod<bigint, PsVerifiedIrExpr>>;
    readonly currentDefinition: Option<PsErasureCurrentDefinition>;
}
declare const __ps$brand$84: unique symbol;
export interface PsErasureAppView {
    readonly [__ps$brand$84]: true;
    readonly head: PsExpr;
    readonly args: List<PsExpr>;
}
declare const __ps$brand$85: unique symbol;
export interface PsErasureAppliedArguments {
    readonly [__ps$brand$85]: true;
    readonly typeArgumentsRev: List<PsVerifiedIrType>;
    readonly runtimeArgumentsRev: List<PsVerifiedIrExpr>;
    readonly remainingType: PsExpr;
}
declare const __ps$brand$86: unique symbol;
export interface PsErasedMatchMinor {
    readonly [__ps$brand$86]: true;
    readonly constructorName: string;
    readonly bindings: List<PsVerifiedIrMatchBinding>;
    readonly body: PsVerifiedIrExpr;
}
declare const __ps$brand$87: unique symbol;
export interface PsOpenMatchMinor {
    readonly [__ps$brand$87]: true;
    readonly scope: PsErasureScope;
    readonly cursor: PsExpr;
    readonly bindingsRev: List<PsVerifiedIrMatchBinding>;
}
declare const __ps$brand$88: unique symbol;
export interface PsOpenMatchHypotheses {
    readonly [__ps$brand$88]: true;
    readonly scope: PsErasureScope;
    readonly cursor: PsExpr;
}
declare const __ps$brand$89: unique symbol;
export interface PsPreparedInductiveParameters {
    readonly [__ps$brand$89]: true;
    readonly scope: PsErasureScope;
    readonly values: List<PsExpr>;
    readonly typeParameters: List<PsVerifiedIrTypeParameter>;
}
declare const __ps$brand$90: unique symbol;
export interface PsPreparedConstructorFields {
    readonly [__ps$brand$90]: true;
    readonly fields: List<PsRuntimeConstructorField>;
}
declare const __ps$brand$91: unique symbol;
export interface PsPreparedInductiveResult {
    readonly [__ps$brand$91]: true;
    readonly scope: PsErasureScope;
    readonly ir: PsVerifiedIrInductive;
}
declare const __ps$brand$92: unique symbol;
export interface PsPreparedInductivesResult {
    readonly [__ps$brand$92]: true;
    readonly scope: PsErasureScope;
    readonly ir: List<PsVerifiedIrInductive>;
}
declare const __ps$brand$93: unique symbol;
export interface PsPreparedStructureResult {
    readonly [__ps$brand$93]: true;
    readonly scope: PsErasureScope;
    readonly ir: PsVerifiedIrStructure;
}
declare const __ps$brand$94: unique symbol;
export interface PsPreparedStructuresResult {
    readonly [__ps$brand$94]: true;
    readonly scope: PsErasureScope;
    readonly ir: List<PsVerifiedIrStructure>;
}
declare const __ps$brand$95: unique symbol;
export interface PsOpenedErasedDefinition {
    readonly [__ps$brand$95]: true;
    readonly typeParameters: List<PsVerifiedIrTypeParameter>;
    readonly parameters: List<PsVerifiedIrParameter>;
    readonly resultType: PsVerifiedIrType;
    readonly body: PsVerifiedIrExpr;
}
declare const __ps$brand$96: unique symbol;
export interface PsErasureNameState {
    readonly [__ps$brand$96]: true;
    readonly used: List<string>;
    readonly entriesRev: List<Prod<PsName, string>>;
}
declare const __ps$brand$97: unique symbol;
export interface PsCompilerAdmissionReadyModule {
    readonly [__ps$brand$97]: true;
    readonly declarations: List<PsDeclaration>;
}
declare const __ps$brand$98: unique symbol;
export interface PsTsFreshNameResult {
    readonly [__ps$brand$98]: true;
    readonly name: string;
    readonly nextIndex: bigint;
}
declare const __ps$brand$99: unique symbol;
export interface PsTsSymbolMapState {
    readonly [__ps$brand$99]: true;
    readonly used: List<string>;
    readonly nextIndex: bigint;
    readonly entriesRev: List<Prod<string, string>>;
}
declare const __ps$brand$100: unique symbol;
export interface PsTsTailAlias {
    readonly [__ps$brand$100]: true;
    readonly name: string;
    readonly captured: List<PsVerifiedIrExpr>;
    readonly arity: bigint;
}
declare const __ps$tag$0: unique symbol;
export type List<T0> = {
    readonly [__ps$tag$0]: "nil";
} | {
    readonly [__ps$tag$0]: "cons";
    readonly head: T0;
    readonly tail: List<T0>;
};
export declare const List: {
    readonly nil: <T0>() => List<T0>;
    readonly cons: <T0>(__field0: T0, __field1: List<T0>) => List<T0>;
};
declare const __ps$tag$1: unique symbol;
export type Option<T0> = {
    readonly [__ps$tag$1]: "none";
} | {
    readonly [__ps$tag$1]: "some";
    readonly value: T0;
};
export declare const Option: {
    readonly none: <T0>() => Option<T0>;
    readonly some: <T0>(__field0: T0) => Option<T0>;
};
declare const __ps$tag$2: unique symbol;
export type Except<T0, T1> = {
    readonly [__ps$tag$2]: "error";
    readonly error: T0;
} | {
    readonly [__ps$tag$2]: "ok";
    readonly value: T1;
};
export declare const Except: {
    readonly error: <T0, T1>(__field0: T0) => Except<T0, T1>;
    readonly ok: <T0, T1>(__field0: T1) => Except<T0, T1>;
};
declare const __ps$tag$3: unique symbol;
export type PsTokenKind = {
    readonly [__ps$tag$3]: "identifier";
} | {
    readonly [__ps$tag$3]: "natural";
} | {
    readonly [__ps$tag$3]: "string";
} | {
    readonly [__ps$tag$3]: "character";
} | {
    readonly [__ps$tag$3]: "symbol";
} | {
    readonly [__ps$tag$3]: "endOfInput";
};
export declare const PsTokenKind: {
    readonly identifier: PsTokenKind;
    readonly natural: PsTokenKind;
    readonly string: PsTokenKind;
    readonly character: PsTokenKind;
    readonly symbol: PsTokenKind;
    readonly endOfInput: PsTokenKind;
};
declare const __ps$tag$4: unique symbol;
export type PsLexError = {
    readonly [__ps$tag$4]: "unterminatedBlockComment";
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$4]: "unterminatedString";
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$4]: "newlineInString";
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$4]: "unterminatedCharacter";
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$4]: "fuelExhausted";
};
export declare const PsLexError: {
    readonly unterminatedBlockComment: (__field0: PsSourceSpan) => PsLexError;
    readonly unterminatedString: (__field0: PsSourceSpan) => PsLexError;
    readonly newlineInString: (__field0: PsSourceSpan) => PsLexError;
    readonly unterminatedCharacter: (__field0: PsSourceSpan) => PsLexError;
    readonly fuelExhausted: PsLexError;
};
declare const __ps$tag$5: unique symbol;
export type PsSyntaxBinderKind = {
    readonly [__ps$tag$5]: "explicit";
} | {
    readonly [__ps$tag$5]: "implicit";
} | {
    readonly [__ps$tag$5]: "strictImplicit";
} | {
    readonly [__ps$tag$5]: "instanceImplicit";
};
export declare const PsSyntaxBinderKind: {
    readonly explicit: PsSyntaxBinderKind;
    readonly implicit: PsSyntaxBinderKind;
    readonly strictImplicit: PsSyntaxBinderKind;
    readonly instanceImplicit: PsSyntaxBinderKind;
};
declare const __ps$tag$6: unique symbol;
export type PsSyntaxPattern = {
    readonly [__ps$tag$6]: "bool";
    readonly value: boolean;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$6]: "wildcard";
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$6]: "constructor";
    readonly name: PsSyntaxName;
    readonly binders: List<PsSyntaxName>;
    readonly span: PsSourceSpan;
};
export declare const PsSyntaxPattern: {
    readonly bool: (__field0: boolean, __field1: PsSourceSpan) => PsSyntaxPattern;
    readonly wildcard: (__field0: PsSourceSpan) => PsSyntaxPattern;
    readonly constructor: (__field0: PsSyntaxName, __field1: List<PsSyntaxName>, __field2: PsSourceSpan) => PsSyntaxPattern;
};
declare const __ps$tag$7: unique symbol;
export type PsSyntaxTerm = {
    readonly [__ps$tag$7]: "reference";
    readonly name: PsSyntaxName;
} | {
    readonly [__ps$tag$7]: "natural";
    readonly text: string;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$7]: "string";
    readonly text: string;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$7]: "character";
    readonly text: string;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$7]: "bool";
    readonly value: boolean;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$7]: "unit";
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$7]: "record";
    readonly fields: List<Prod<PsSyntaxName, PsSyntaxTerm>>;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$7]: "app";
    readonly fn: PsSyntaxTerm;
    readonly args: List<PsSyntaxTerm>;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$7]: "lambda";
    readonly binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>;
    readonly body: PsSyntaxTerm;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$7]: "forallE";
    readonly binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>;
    readonly body: PsSyntaxTerm;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$7]: "letE";
    readonly name: PsSyntaxName;
    readonly type: Option<PsSyntaxTerm>;
    readonly value: PsSyntaxTerm;
    readonly body: PsSyntaxTerm;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$7]: "ifE";
    readonly condition: PsSyntaxTerm;
    readonly thenBranch: PsSyntaxTerm;
    readonly elseBranch: PsSyntaxTerm;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$7]: "matchE";
    readonly scrutinee: PsSyntaxTerm;
    readonly alternatives: List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>;
    readonly span: PsSourceSpan;
};
export declare const PsSyntaxTerm: {
    readonly reference: (__field0: PsSyntaxName) => PsSyntaxTerm;
    readonly natural: (__field0: string, __field1: PsSourceSpan) => PsSyntaxTerm;
    readonly string: (__field0: string, __field1: PsSourceSpan) => PsSyntaxTerm;
    readonly character: (__field0: string, __field1: PsSourceSpan) => PsSyntaxTerm;
    readonly bool: (__field0: boolean, __field1: PsSourceSpan) => PsSyntaxTerm;
    readonly unit: (__field0: PsSourceSpan) => PsSyntaxTerm;
    readonly record: (__field0: List<Prod<PsSyntaxName, PsSyntaxTerm>>, __field1: PsSourceSpan) => PsSyntaxTerm;
    readonly app: (__field0: PsSyntaxTerm, __field1: List<PsSyntaxTerm>, __field2: PsSourceSpan) => PsSyntaxTerm;
    readonly lambda: (__field0: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, __field1: PsSyntaxTerm, __field2: PsSourceSpan) => PsSyntaxTerm;
    readonly forallE: (__field0: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, __field1: PsSyntaxTerm, __field2: PsSourceSpan) => PsSyntaxTerm;
    readonly letE: (__field0: PsSyntaxName, __field1: Option<PsSyntaxTerm>, __field2: PsSyntaxTerm, __field3: PsSyntaxTerm, __field4: PsSourceSpan) => PsSyntaxTerm;
    readonly ifE: (__field0: PsSyntaxTerm, __field1: PsSyntaxTerm, __field2: PsSyntaxTerm, __field3: PsSourceSpan) => PsSyntaxTerm;
    readonly matchE: (__field0: PsSyntaxTerm, __field1: List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>, __field2: PsSourceSpan) => PsSyntaxTerm;
};
declare const __ps$tag$8: unique symbol;
export type PsSyntaxDeclaration = {
    readonly [__ps$tag$8]: "definition";
    readonly name: PsSyntaxName;
    readonly binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>;
    readonly type: PsSyntaxTerm;
    readonly value: PsSyntaxTerm;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$8]: "partialDefinition";
    readonly name: PsSyntaxName;
    readonly binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>;
    readonly type: PsSyntaxTerm;
    readonly value: PsSyntaxTerm;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$8]: "theoremDecl";
    readonly name: PsSyntaxName;
    readonly binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>;
    readonly type: PsSyntaxTerm;
    readonly value: PsSyntaxTerm;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$8]: "inductiveDecl";
    readonly name: PsSyntaxName;
    readonly params: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>;
    readonly resultType: Option<PsSyntaxTerm>;
    readonly constructors: List<PsSyntaxInductiveConstructor>;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$8]: "structureDecl";
    readonly name: PsSyntaxName;
    readonly params: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>;
    readonly fields: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>;
    readonly span: PsSourceSpan;
};
export declare const PsSyntaxDeclaration: {
    readonly definition: (__field0: PsSyntaxName, __field1: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, __field2: PsSyntaxTerm, __field3: PsSyntaxTerm, __field4: PsSourceSpan) => PsSyntaxDeclaration;
    readonly partialDefinition: (__field0: PsSyntaxName, __field1: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, __field2: PsSyntaxTerm, __field3: PsSyntaxTerm, __field4: PsSourceSpan) => PsSyntaxDeclaration;
    readonly theoremDecl: (__field0: PsSyntaxName, __field1: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, __field2: PsSyntaxTerm, __field3: PsSyntaxTerm, __field4: PsSourceSpan) => PsSyntaxDeclaration;
    readonly inductiveDecl: (__field0: PsSyntaxName, __field1: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, __field2: Option<PsSyntaxTerm>, __field3: List<PsSyntaxInductiveConstructor>, __field4: PsSourceSpan) => PsSyntaxDeclaration;
    readonly structureDecl: (__field0: PsSyntaxName, __field1: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, __field2: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, __field3: PsSourceSpan) => PsSyntaxDeclaration;
};
declare const __ps$tag$9: unique symbol;
export type PsName = {
    readonly [__ps$tag$9]: "anonymous";
} | {
    readonly [__ps$tag$9]: "str";
    readonly parent: PsName;
    readonly value: string;
} | {
    readonly [__ps$tag$9]: "num";
    readonly parent: PsName;
    readonly value: bigint;
};
export declare const PsName: {
    readonly anonymous: PsName;
    readonly str: (__field0: PsName, __field1: string) => PsName;
    readonly num: (__field0: PsName, __field1: bigint) => PsName;
};
declare const __ps$tag$10: unique symbol;
export type PsParseError = {
    readonly [__ps$tag$10]: "fuelExhausted";
} | {
    readonly [__ps$tag$10]: "unexpectedEnd";
    readonly expected: string;
} | {
    readonly [__ps$tag$10]: "expectedText";
    readonly expected: string;
    readonly actual: string;
    readonly span: PsSourceSpan;
} | {
    readonly [__ps$tag$10]: "expectedKind";
    readonly expected: PsTokenKind;
    readonly actual: PsTokenKind;
    readonly span: PsSourceSpan;
};
export declare const PsParseError: {
    readonly fuelExhausted: PsParseError;
    readonly unexpectedEnd: (__field0: string) => PsParseError;
    readonly expectedText: (__field0: string, __field1: string, __field2: PsSourceSpan) => PsParseError;
    readonly expectedKind: (__field0: PsTokenKind, __field1: PsTokenKind, __field2: PsSourceSpan) => PsParseError;
};
declare const __ps$tag$11: unique symbol;
export type PsLeanFrontendError = {
    readonly [__ps$tag$11]: "lex";
    readonly error: PsLexError;
} | {
    readonly [__ps$tag$11]: "parse";
    readonly error: PsParseError;
};
export declare const PsLeanFrontendError: {
    readonly lex: (__field0: PsLexError) => PsLeanFrontendError;
    readonly parse: (__field0: PsParseError) => PsLeanFrontendError;
};
declare const __ps$tag$12: unique symbol;
export type PsProofScriptFrontendError = {
    readonly [__ps$tag$12]: "lex";
    readonly error: PsLexError;
} | {
    readonly [__ps$tag$12]: "parse";
    readonly error: PsParseError;
};
export declare const PsProofScriptFrontendError: {
    readonly lex: (__field0: PsLexError) => PsProofScriptFrontendError;
    readonly parse: (__field0: PsParseError) => PsProofScriptFrontendError;
};
declare const __ps$tag$13: unique symbol;
export type PsSourcePrintError = {
    readonly [__ps$tag$13]: "fuelExhausted";
} | {
    readonly [__ps$tag$13]: "unsupportedApplication";
} | {
    readonly [__ps$tag$13]: "emptyName";
};
export declare const PsSourcePrintError: {
    readonly fuelExhausted: PsSourcePrintError;
    readonly unsupportedApplication: PsSourcePrintError;
    readonly emptyName: PsSourcePrintError;
};
declare const __ps$tag$14: unique symbol;
export type PsTranslationError = {
    readonly [__ps$tag$14]: "leanFrontend";
    readonly error: PsLeanFrontendError;
} | {
    readonly [__ps$tag$14]: "proofScriptFrontend";
    readonly error: PsProofScriptFrontendError;
} | {
    readonly [__ps$tag$14]: "print";
    readonly error: PsSourcePrintError;
};
export declare const PsTranslationError: {
    readonly leanFrontend: (__field0: PsLeanFrontendError) => PsTranslationError;
    readonly proofScriptFrontend: (__field0: PsProofScriptFrontendError) => PsTranslationError;
    readonly print: (__field0: PsSourcePrintError) => PsTranslationError;
};
declare const __ps$tag$15: unique symbol;
export type PsJsonValue = {
    readonly [__ps$tag$15]: "nullE";
} | {
    readonly [__ps$tag$15]: "bool";
    readonly value: boolean;
} | {
    readonly [__ps$tag$15]: "number";
    readonly text: string;
} | {
    readonly [__ps$tag$15]: "string";
    readonly value: string;
} | {
    readonly [__ps$tag$15]: "array";
    readonly values: List<PsJsonValue>;
} | {
    readonly [__ps$tag$15]: "object";
    readonly fields: List<Prod<string, PsJsonValue>>;
};
export declare const PsJsonValue: {
    readonly nullE: PsJsonValue;
    readonly bool: (__field0: boolean) => PsJsonValue;
    readonly number: (__field0: string) => PsJsonValue;
    readonly string: (__field0: string) => PsJsonValue;
    readonly array: (__field0: List<PsJsonValue>) => PsJsonValue;
    readonly object: (__field0: List<Prod<string, PsJsonValue>>) => PsJsonValue;
};
declare const __ps$tag$16: unique symbol;
export type PsJsonParseError = {
    readonly [__ps$tag$16]: "fuelExhausted";
} | {
    readonly [__ps$tag$16]: "unexpectedEnd";
} | {
    readonly [__ps$tag$16]: "expected";
    readonly text: string;
} | {
    readonly [__ps$tag$16]: "invalidEscape";
} | {
    readonly [__ps$tag$16]: "invalidUnicodeEscape";
} | {
    readonly [__ps$tag$16]: "invalidNumber";
} | {
    readonly [__ps$tag$16]: "invalidLiteral";
} | {
    readonly [__ps$tag$16]: "trailingInput";
};
export declare const PsJsonParseError: {
    readonly fuelExhausted: PsJsonParseError;
    readonly unexpectedEnd: PsJsonParseError;
    readonly expected: (__field0: string) => PsJsonParseError;
    readonly invalidEscape: PsJsonParseError;
    readonly invalidUnicodeEscape: PsJsonParseError;
    readonly invalidNumber: PsJsonParseError;
    readonly invalidLiteral: PsJsonParseError;
    readonly trailingInput: PsJsonParseError;
};
declare const __ps$tag$17: unique symbol;
export type PsJsonEncodeError = {
    readonly [__ps$tag$17]: "fuelExhausted";
} | {
    readonly [__ps$tag$17]: "invalidNumber";
    readonly text: string;
} | {
    readonly [__ps$tag$17]: "duplicateObjectKey";
    readonly key: string;
};
export declare const PsJsonEncodeError: {
    readonly fuelExhausted: PsJsonEncodeError;
    readonly invalidNumber: (__field0: string) => PsJsonEncodeError;
    readonly duplicateObjectKey: (__field0: string) => PsJsonEncodeError;
};
declare const __ps$tag$18: unique symbol;
export type PsJsonKeyOrder = {
    readonly [__ps$tag$18]: "lt";
} | {
    readonly [__ps$tag$18]: "eq";
} | {
    readonly [__ps$tag$18]: "gt";
};
export declare const PsJsonKeyOrder: {
    readonly lt: PsJsonKeyOrder;
    readonly eq: PsJsonKeyOrder;
    readonly gt: PsJsonKeyOrder;
};
declare const __ps$tag$19: unique symbol;
export type PsLevel = {
    readonly [__ps$tag$19]: "zero";
} | {
    readonly [__ps$tag$19]: "succ";
    readonly of: PsLevel;
} | {
    readonly [__ps$tag$19]: "max";
    readonly left: PsLevel;
    readonly right: PsLevel;
} | {
    readonly [__ps$tag$19]: "imax";
    readonly left: PsLevel;
    readonly right: PsLevel;
} | {
    readonly [__ps$tag$19]: "param";
    readonly name: PsName;
} | {
    readonly [__ps$tag$19]: "mvar";
    readonly id: bigint;
};
export declare const PsLevel: {
    readonly zero: PsLevel;
    readonly succ: (__field0: PsLevel) => PsLevel;
    readonly max: (__field0: PsLevel, __field1: PsLevel) => PsLevel;
    readonly imax: (__field0: PsLevel, __field1: PsLevel) => PsLevel;
    readonly param: (__field0: PsName) => PsLevel;
    readonly mvar: (__field0: bigint) => PsLevel;
};
declare const __ps$tag$20: unique symbol;
export type PsBinderInfo = {
    readonly [__ps$tag$20]: "explicit";
} | {
    readonly [__ps$tag$20]: "implicit";
} | {
    readonly [__ps$tag$20]: "strictImplicit";
} | {
    readonly [__ps$tag$20]: "instanceImplicit";
};
export declare const PsBinderInfo: {
    readonly explicit: PsBinderInfo;
    readonly implicit: PsBinderInfo;
    readonly strictImplicit: PsBinderInfo;
    readonly instanceImplicit: PsBinderInfo;
};
declare const __ps$tag$21: unique symbol;
export type PsLiteral = {
    readonly [__ps$tag$21]: "natural";
    readonly value: bigint;
} | {
    readonly [__ps$tag$21]: "string";
    readonly value: string;
};
export declare const PsLiteral: {
    readonly natural: (__field0: bigint) => PsLiteral;
    readonly string: (__field0: string) => PsLiteral;
};
declare const __ps$tag$22: unique symbol;
export type PsExpr = {
    readonly [__ps$tag$22]: "bvar";
    readonly index: bigint;
} | {
    readonly [__ps$tag$22]: "fvar";
    readonly id: bigint;
} | {
    readonly [__ps$tag$22]: "mvar";
    readonly id: bigint;
} | {
    readonly [__ps$tag$22]: "sortE";
    readonly level: PsLevel;
} | {
    readonly [__ps$tag$22]: "constE";
    readonly name: PsName;
    readonly levels: List<PsLevel>;
} | {
    readonly [__ps$tag$22]: "app";
    readonly fn: PsExpr;
    readonly arg: PsExpr;
} | {
    readonly [__ps$tag$22]: "lam";
    readonly name: PsName;
    readonly type: PsExpr;
    readonly body: PsExpr;
    readonly binder: PsBinderInfo;
} | {
    readonly [__ps$tag$22]: "forallE";
    readonly name: PsName;
    readonly type: PsExpr;
    readonly body: PsExpr;
    readonly binder: PsBinderInfo;
} | {
    readonly [__ps$tag$22]: "letE";
    readonly name: PsName;
    readonly type: PsExpr;
    readonly value: PsExpr;
    readonly body: PsExpr;
} | {
    readonly [__ps$tag$22]: "lit";
    readonly value: PsLiteral;
} | {
    readonly [__ps$tag$22]: "proj";
    readonly typeName: PsName;
    readonly index: bigint;
    readonly value: PsExpr;
};
export declare const PsExpr: {
    readonly bvar: (__field0: bigint) => PsExpr;
    readonly fvar: (__field0: bigint) => PsExpr;
    readonly mvar: (__field0: bigint) => PsExpr;
    readonly sortE: (__field0: PsLevel) => PsExpr;
    readonly constE: (__field0: PsName, __field1: List<PsLevel>) => PsExpr;
    readonly app: (__field0: PsExpr, __field1: PsExpr) => PsExpr;
    readonly lam: (__field0: PsName, __field1: PsExpr, __field2: PsExpr, __field3: PsBinderInfo) => PsExpr;
    readonly forallE: (__field0: PsName, __field1: PsExpr, __field2: PsExpr, __field3: PsBinderInfo) => PsExpr;
    readonly letE: (__field0: PsName, __field1: PsExpr, __field2: PsExpr, __field3: PsExpr) => PsExpr;
    readonly lit: (__field0: PsLiteral) => PsExpr;
    readonly proj: (__field0: PsName, __field1: bigint, __field2: PsExpr) => PsExpr;
};
declare const __ps$tag$23: unique symbol;
export type PsDeclaration = {
    readonly [__ps$tag$23]: "axiomDecl";
    readonly name: PsName;
    readonly levelParams: List<PsName>;
    readonly type: PsExpr;
} | {
    readonly [__ps$tag$23]: "definitionDecl";
    readonly name: PsName;
    readonly levelParams: List<PsName>;
    readonly type: PsExpr;
    readonly value: PsExpr;
} | {
    readonly [__ps$tag$23]: "theoremDecl";
    readonly name: PsName;
    readonly levelParams: List<PsName>;
    readonly type: PsExpr;
    readonly value: PsExpr;
} | {
    readonly [__ps$tag$23]: "partialDecl";
    readonly name: PsName;
    readonly levelParams: List<PsName>;
    readonly type: PsExpr;
    readonly value: PsExpr;
} | {
    readonly [__ps$tag$23]: "opaqueDecl";
    readonly name: PsName;
    readonly levelParams: List<PsName>;
    readonly type: PsExpr;
    readonly value: PsExpr;
} | {
    readonly [__ps$tag$23]: "inductiveDecl";
    readonly info: PsInductiveInfo;
} | {
    readonly [__ps$tag$23]: "constructorDecl";
    readonly info: PsConstructorInfo;
} | {
    readonly [__ps$tag$23]: "recursorDecl";
    readonly info: PsRecursorInfo;
};
export declare const PsDeclaration: {
    readonly axiomDecl: (__field0: PsName, __field1: List<PsName>, __field2: PsExpr) => PsDeclaration;
    readonly definitionDecl: (__field0: PsName, __field1: List<PsName>, __field2: PsExpr, __field3: PsExpr) => PsDeclaration;
    readonly theoremDecl: (__field0: PsName, __field1: List<PsName>, __field2: PsExpr, __field3: PsExpr) => PsDeclaration;
    readonly partialDecl: (__field0: PsName, __field1: List<PsName>, __field2: PsExpr, __field3: PsExpr) => PsDeclaration;
    readonly opaqueDecl: (__field0: PsName, __field1: List<PsName>, __field2: PsExpr, __field3: PsExpr) => PsDeclaration;
    readonly inductiveDecl: (__field0: PsInductiveInfo) => PsDeclaration;
    readonly constructorDecl: (__field0: PsConstructorInfo) => PsDeclaration;
    readonly recursorDecl: (__field0: PsRecursorInfo) => PsDeclaration;
};
declare const __ps$tag$24: unique symbol;
export type PsEnvironmentIndex = {
    readonly [__ps$tag$24]: "empty";
} | {
    readonly [__ps$tag$24]: "bucket";
    readonly declarations: List<PsDeclaration>;
} | {
    readonly [__ps$tag$24]: "branch";
    readonly left: PsEnvironmentIndex;
    readonly right: PsEnvironmentIndex;
};
export declare const PsEnvironmentIndex: {
    readonly empty: PsEnvironmentIndex;
    readonly bucket: (__field0: List<PsDeclaration>) => PsEnvironmentIndex;
    readonly branch: (__field0: PsEnvironmentIndex, __field1: PsEnvironmentIndex) => PsEnvironmentIndex;
};
declare const __ps$tag$25: unique symbol;
export type PsCheckedAdmissionCodecError = {
    readonly [__ps$tag$25]: "universeMetavariable";
} | {
    readonly [__ps$tag$25]: "freeVariable";
} | {
    readonly [__ps$tag$25]: "expressionMetavariable";
} | {
    readonly [__ps$tag$25]: "missingConstructor";
    readonly name: PsName;
} | {
    readonly [__ps$tag$25]: "mismatchedConstructor";
    readonly name: PsName;
} | {
    readonly [__ps$tag$25]: "unsupportedDeclaration";
};
export declare const PsCheckedAdmissionCodecError: {
    readonly universeMetavariable: PsCheckedAdmissionCodecError;
    readonly freeVariable: PsCheckedAdmissionCodecError;
    readonly expressionMetavariable: PsCheckedAdmissionCodecError;
    readonly missingConstructor: (__field0: PsName) => PsCheckedAdmissionCodecError;
    readonly mismatchedConstructor: (__field0: PsName) => PsCheckedAdmissionCodecError;
    readonly unsupportedDeclaration: PsCheckedAdmissionCodecError;
};
declare const __ps$tag$26: unique symbol;
export type PsBridgeHeightIndex = {
    readonly [__ps$tag$26]: "empty";
} | {
    readonly [__ps$tag$26]: "bucket";
    readonly entries: List<Prod<PsName, bigint>>;
} | {
    readonly [__ps$tag$26]: "branch";
    readonly left: PsBridgeHeightIndex;
    readonly right: PsBridgeHeightIndex;
};
export declare const PsBridgeHeightIndex: {
    readonly empty: PsBridgeHeightIndex;
    readonly bucket: (__field0: List<Prod<PsName, bigint>>) => PsBridgeHeightIndex;
    readonly branch: (__field0: PsBridgeHeightIndex, __field1: PsBridgeHeightIndex) => PsBridgeHeightIndex;
};
declare const __ps$tag$27: unique symbol;
export type PsLocalDecl = {
    readonly [__ps$tag$27]: "binding";
    readonly id: bigint;
    readonly userName: PsName;
    readonly type: PsExpr;
    readonly binder: PsBinderInfo;
} | {
    readonly [__ps$tag$27]: "letDecl";
    readonly id: bigint;
    readonly userName: PsName;
    readonly type: PsExpr;
    readonly value: PsExpr;
};
export declare const PsLocalDecl: {
    readonly binding: (__field0: bigint, __field1: PsName, __field2: PsExpr, __field3: PsBinderInfo) => PsLocalDecl;
    readonly letDecl: (__field0: bigint, __field1: PsName, __field2: PsExpr, __field3: PsExpr) => PsLocalDecl;
};
declare const __ps$tag$28: unique symbol;
export type PsResolvedName = {
    readonly [__ps$tag$28]: "local";
    readonly id: bigint;
} | {
    readonly [__ps$tag$28]: "global";
    readonly name: PsName;
};
export declare const PsResolvedName: {
    readonly local: (__field0: bigint) => PsResolvedName;
    readonly global: (__field0: PsName) => PsResolvedName;
};
declare const __ps$tag$29: unique symbol;
export type PsMetaVarKind = {
    readonly [__ps$tag$29]: "natural";
} | {
    readonly [__ps$tag$29]: "synthetic";
} | {
    readonly [__ps$tag$29]: "syntheticOpaque";
};
export declare const PsMetaVarKind: {
    readonly natural: PsMetaVarKind;
    readonly synthetic: PsMetaVarKind;
    readonly syntheticOpaque: PsMetaVarKind;
};
declare const __ps$tag$30: unique symbol;
export type PsInferError = {
    readonly [__ps$tag$30]: "fuelExhausted";
} | {
    readonly [__ps$tag$30]: "looseBoundVariable";
    readonly index: bigint;
} | {
    readonly [__ps$tag$30]: "unknownFreeVariable";
    readonly id: bigint;
} | {
    readonly [__ps$tag$30]: "unknownMetavariable";
    readonly id: bigint;
} | {
    readonly [__ps$tag$30]: "unknownConstant";
    readonly name: PsName;
} | {
    readonly [__ps$tag$30]: "incorrectUniverseArity";
    readonly name: PsName;
} | {
    readonly [__ps$tag$30]: "expectedSort";
} | {
    readonly [__ps$tag$30]: "expectedFunction";
} | {
    readonly [__ps$tag$30]: "applicationTypeMismatch";
} | {
    readonly [__ps$tag$30]: "letTypeMismatch";
} | {
    readonly [__ps$tag$30]: "projectionUnsupported";
};
export declare const PsInferError: {
    readonly fuelExhausted: PsInferError;
    readonly looseBoundVariable: (__field0: bigint) => PsInferError;
    readonly unknownFreeVariable: (__field0: bigint) => PsInferError;
    readonly unknownMetavariable: (__field0: bigint) => PsInferError;
    readonly unknownConstant: (__field0: PsName) => PsInferError;
    readonly incorrectUniverseArity: (__field0: PsName) => PsInferError;
    readonly expectedSort: PsInferError;
    readonly expectedFunction: PsInferError;
    readonly applicationTypeMismatch: PsInferError;
    readonly letTypeMismatch: PsInferError;
    readonly projectionUnsupported: PsInferError;
};
declare const __ps$tag$31: unique symbol;
export type PsElabError = {
    readonly [__ps$tag$31]: "fuelExhausted";
} | {
    readonly [__ps$tag$31]: "emptyName";
} | {
    readonly [__ps$tag$31]: "unknownName";
    readonly name: PsName;
} | {
    readonly [__ps$tag$31]: "invalidNatural";
    readonly text: string;
} | {
    readonly [__ps$tag$31]: "invalidString";
    readonly text: string;
} | {
    readonly [__ps$tag$31]: "invalidCharacter";
    readonly text: string;
} | {
    readonly [__ps$tag$31]: "infer";
    readonly error: PsInferError;
} | {
    readonly [__ps$tag$31]: "typeMismatch";
} | {
    readonly [__ps$tag$31]: "implicitApplicationUnsupported";
} | {
    readonly [__ps$tag$31]: "unsupportedTerm";
} | {
    readonly [__ps$tag$31]: "matchExpectedType";
} | {
    readonly [__ps$tag$31]: "matchScrutineeUnsupported";
} | {
    readonly [__ps$tag$31]: "matchInductiveUnsupported";
} | {
    readonly [__ps$tag$31]: "matchParameterArity";
} | {
    readonly [__ps$tag$31]: "matchPatternUnsupported";
} | {
    readonly [__ps$tag$31]: "matchConstructorUnknown";
    readonly name: PsName;
} | {
    readonly [__ps$tag$31]: "matchDuplicateConstructor";
    readonly name: PsName;
} | {
    readonly [__ps$tag$31]: "matchNonExhaustive";
} | {
    readonly [__ps$tag$31]: "matchRecursorUnsupported";
} | {
    readonly [__ps$tag$31]: "matchRecursorLevels";
} | {
    readonly [__ps$tag$31]: "matchConstructorArity";
    readonly name: PsName;
} | {
    readonly [__ps$tag$31]: "matchRecursiveFieldUnsupported";
    readonly name: PsName;
} | {
    readonly [__ps$tag$31]: "duplicateDeclaration";
    readonly name: PsName;
} | {
    readonly [__ps$tag$31]: "unresolvedMetavariable";
} | {
    readonly [__ps$tag$31]: "structuralRecursionArity";
} | {
    readonly [__ps$tag$31]: "structuralRecursionNotDecreasing";
} | {
    readonly [__ps$tag$31]: "structuralRecursionInvariantArgument";
} | {
    readonly [__ps$tag$31]: "structuralRecursionInternal";
};
export declare const PsElabError: {
    readonly fuelExhausted: PsElabError;
    readonly emptyName: PsElabError;
    readonly unknownName: (__field0: PsName) => PsElabError;
    readonly invalidNatural: (__field0: string) => PsElabError;
    readonly invalidString: (__field0: string) => PsElabError;
    readonly invalidCharacter: (__field0: string) => PsElabError;
    readonly infer: (__field0: PsInferError) => PsElabError;
    readonly typeMismatch: PsElabError;
    readonly implicitApplicationUnsupported: PsElabError;
    readonly unsupportedTerm: PsElabError;
    readonly matchExpectedType: PsElabError;
    readonly matchScrutineeUnsupported: PsElabError;
    readonly matchInductiveUnsupported: PsElabError;
    readonly matchParameterArity: PsElabError;
    readonly matchPatternUnsupported: PsElabError;
    readonly matchConstructorUnknown: (__field0: PsName) => PsElabError;
    readonly matchDuplicateConstructor: (__field0: PsName) => PsElabError;
    readonly matchNonExhaustive: PsElabError;
    readonly matchRecursorUnsupported: PsElabError;
    readonly matchRecursorLevels: PsElabError;
    readonly matchConstructorArity: (__field0: PsName) => PsElabError;
    readonly matchRecursiveFieldUnsupported: (__field0: PsName) => PsElabError;
    readonly duplicateDeclaration: (__field0: PsName) => PsElabError;
    readonly unresolvedMetavariable: PsElabError;
    readonly structuralRecursionArity: PsElabError;
    readonly structuralRecursionNotDecreasing: PsElabError;
    readonly structuralRecursionInvariantArgument: PsElabError;
    readonly structuralRecursionInternal: PsElabError;
};
declare const __ps$tag$32: unique symbol;
export type PsVerifiedIrPrimitiveType = {
    readonly [__ps$tag$32]: "nat";
} | {
    readonly [__ps$tag$32]: "int";
} | {
    readonly [__ps$tag$32]: "uint8";
} | {
    readonly [__ps$tag$32]: "uint16";
} | {
    readonly [__ps$tag$32]: "uint32";
} | {
    readonly [__ps$tag$32]: "uint64";
} | {
    readonly [__ps$tag$32]: "usize";
} | {
    readonly [__ps$tag$32]: "int8";
} | {
    readonly [__ps$tag$32]: "int16";
} | {
    readonly [__ps$tag$32]: "int32";
} | {
    readonly [__ps$tag$32]: "int64";
} | {
    readonly [__ps$tag$32]: "isize";
} | {
    readonly [__ps$tag$32]: "float";
} | {
    readonly [__ps$tag$32]: "float32";
} | {
    readonly [__ps$tag$32]: "bool";
} | {
    readonly [__ps$tag$32]: "char";
} | {
    readonly [__ps$tag$32]: "string";
} | {
    readonly [__ps$tag$32]: "unit";
};
export declare const PsVerifiedIrPrimitiveType: {
    readonly nat: PsVerifiedIrPrimitiveType;
    readonly int: PsVerifiedIrPrimitiveType;
    readonly uint8: PsVerifiedIrPrimitiveType;
    readonly uint16: PsVerifiedIrPrimitiveType;
    readonly uint32: PsVerifiedIrPrimitiveType;
    readonly uint64: PsVerifiedIrPrimitiveType;
    readonly usize: PsVerifiedIrPrimitiveType;
    readonly int8: PsVerifiedIrPrimitiveType;
    readonly int16: PsVerifiedIrPrimitiveType;
    readonly int32: PsVerifiedIrPrimitiveType;
    readonly int64: PsVerifiedIrPrimitiveType;
    readonly isize: PsVerifiedIrPrimitiveType;
    readonly float: PsVerifiedIrPrimitiveType;
    readonly float32: PsVerifiedIrPrimitiveType;
    readonly bool: PsVerifiedIrPrimitiveType;
    readonly char: PsVerifiedIrPrimitiveType;
    readonly string: PsVerifiedIrPrimitiveType;
    readonly unit: PsVerifiedIrPrimitiveType;
};
declare const __ps$tag$33: unique symbol;
export type PsVerifiedIrType = {
    readonly [__ps$tag$33]: "unknown";
} | {
    readonly [__ps$tag$33]: "typeParameter";
    readonly name: string;
} | {
    readonly [__ps$tag$33]: "primitive";
    readonly name: PsVerifiedIrPrimitiveType;
} | {
    readonly [__ps$tag$33]: "function";
    readonly parameters: List<PsVerifiedIrType>;
    readonly result: PsVerifiedIrType;
} | {
    readonly [__ps$tag$33]: "named";
    readonly name: string;
    readonly arguments: List<PsVerifiedIrType>;
};
export declare const PsVerifiedIrType: {
    readonly unknown: PsVerifiedIrType;
    readonly typeParameter: (__field0: string) => PsVerifiedIrType;
    readonly primitive: (__field0: PsVerifiedIrPrimitiveType) => PsVerifiedIrType;
    readonly function: (__field0: List<PsVerifiedIrType>, __field1: PsVerifiedIrType) => PsVerifiedIrType;
    readonly named: (__field0: string, __field1: List<PsVerifiedIrType>) => PsVerifiedIrType;
};
declare const __ps$tag$34: unique symbol;
export type PsVerifiedIrMachineIntegerType = {
    readonly [__ps$tag$34]: "uint8";
} | {
    readonly [__ps$tag$34]: "uint16";
} | {
    readonly [__ps$tag$34]: "uint32";
} | {
    readonly [__ps$tag$34]: "uint64";
} | {
    readonly [__ps$tag$34]: "usize";
} | {
    readonly [__ps$tag$34]: "int8";
} | {
    readonly [__ps$tag$34]: "int16";
} | {
    readonly [__ps$tag$34]: "int32";
} | {
    readonly [__ps$tag$34]: "int64";
} | {
    readonly [__ps$tag$34]: "isize";
};
export declare const PsVerifiedIrMachineIntegerType: {
    readonly uint8: PsVerifiedIrMachineIntegerType;
    readonly uint16: PsVerifiedIrMachineIntegerType;
    readonly uint32: PsVerifiedIrMachineIntegerType;
    readonly uint64: PsVerifiedIrMachineIntegerType;
    readonly usize: PsVerifiedIrMachineIntegerType;
    readonly int8: PsVerifiedIrMachineIntegerType;
    readonly int16: PsVerifiedIrMachineIntegerType;
    readonly int32: PsVerifiedIrMachineIntegerType;
    readonly int64: PsVerifiedIrMachineIntegerType;
    readonly isize: PsVerifiedIrMachineIntegerType;
};
declare const __ps$tag$35: unique symbol;
export type PsVerifiedIrIntegerBinaryOp = {
    readonly [__ps$tag$35]: "add";
} | {
    readonly [__ps$tag$35]: "sub";
} | {
    readonly [__ps$tag$35]: "mul";
} | {
    readonly [__ps$tag$35]: "bitAnd";
} | {
    readonly [__ps$tag$35]: "bitOr";
} | {
    readonly [__ps$tag$35]: "bitXor";
};
export declare const PsVerifiedIrIntegerBinaryOp: {
    readonly add: PsVerifiedIrIntegerBinaryOp;
    readonly sub: PsVerifiedIrIntegerBinaryOp;
    readonly mul: PsVerifiedIrIntegerBinaryOp;
    readonly bitAnd: PsVerifiedIrIntegerBinaryOp;
    readonly bitOr: PsVerifiedIrIntegerBinaryOp;
    readonly bitXor: PsVerifiedIrIntegerBinaryOp;
};
declare const __ps$tag$36: unique symbol;
export type PsVerifiedIrIntegerCompareOp = {
    readonly [__ps$tag$36]: "eq";
} | {
    readonly [__ps$tag$36]: "ne";
} | {
    readonly [__ps$tag$36]: "lt";
} | {
    readonly [__ps$tag$36]: "le";
} | {
    readonly [__ps$tag$36]: "gt";
} | {
    readonly [__ps$tag$36]: "ge";
};
export declare const PsVerifiedIrIntegerCompareOp: {
    readonly eq: PsVerifiedIrIntegerCompareOp;
    readonly ne: PsVerifiedIrIntegerCompareOp;
    readonly lt: PsVerifiedIrIntegerCompareOp;
    readonly le: PsVerifiedIrIntegerCompareOp;
    readonly gt: PsVerifiedIrIntegerCompareOp;
    readonly ge: PsVerifiedIrIntegerCompareOp;
};
declare const __ps$tag$37: unique symbol;
export type PsVerifiedIrFloatingType = {
    readonly [__ps$tag$37]: "float";
} | {
    readonly [__ps$tag$37]: "float32";
};
export declare const PsVerifiedIrFloatingType: {
    readonly float: PsVerifiedIrFloatingType;
    readonly float32: PsVerifiedIrFloatingType;
};
declare const __ps$tag$38: unique symbol;
export type PsVerifiedIrFloatBinaryOp = {
    readonly [__ps$tag$38]: "add";
} | {
    readonly [__ps$tag$38]: "sub";
} | {
    readonly [__ps$tag$38]: "mul";
} | {
    readonly [__ps$tag$38]: "div";
};
export declare const PsVerifiedIrFloatBinaryOp: {
    readonly add: PsVerifiedIrFloatBinaryOp;
    readonly sub: PsVerifiedIrFloatBinaryOp;
    readonly mul: PsVerifiedIrFloatBinaryOp;
    readonly div: PsVerifiedIrFloatBinaryOp;
};
declare const __ps$tag$39: unique symbol;
export type PsVerifiedIrFloatCompareOp = {
    readonly [__ps$tag$39]: "eq";
} | {
    readonly [__ps$tag$39]: "ne";
} | {
    readonly [__ps$tag$39]: "lt";
} | {
    readonly [__ps$tag$39]: "le";
} | {
    readonly [__ps$tag$39]: "gt";
} | {
    readonly [__ps$tag$39]: "ge";
};
export declare const PsVerifiedIrFloatCompareOp: {
    readonly eq: PsVerifiedIrFloatCompareOp;
    readonly ne: PsVerifiedIrFloatCompareOp;
    readonly lt: PsVerifiedIrFloatCompareOp;
    readonly le: PsVerifiedIrFloatCompareOp;
    readonly gt: PsVerifiedIrFloatCompareOp;
    readonly ge: PsVerifiedIrFloatCompareOp;
};
declare const __ps$tag$40: unique symbol;
export type PsVerifiedIrLiteral = {
    readonly [__ps$tag$40]: "natural";
    readonly value: bigint;
} | {
    readonly [__ps$tag$40]: "integer";
    readonly value: bigint;
} | {
    readonly [__ps$tag$40]: "machineInteger";
    readonly type: PsVerifiedIrMachineIntegerType;
    readonly value: bigint;
} | {
    readonly [__ps$tag$40]: "string";
    readonly value: string;
} | {
    readonly [__ps$tag$40]: "bool";
    readonly value: boolean;
} | {
    readonly [__ps$tag$40]: "unit";
};
export declare const PsVerifiedIrLiteral: {
    readonly natural: (__field0: bigint) => PsVerifiedIrLiteral;
    readonly integer: (__field0: bigint) => PsVerifiedIrLiteral;
    readonly machineInteger: (__field0: PsVerifiedIrMachineIntegerType, __field1: bigint) => PsVerifiedIrLiteral;
    readonly string: (__field0: string) => PsVerifiedIrLiteral;
    readonly bool: (__field0: boolean) => PsVerifiedIrLiteral;
    readonly unit: PsVerifiedIrLiteral;
};
declare const __ps$tag$41: unique symbol;
export type PsVerifiedIrIntrinsic = {
    readonly [__ps$tag$41]: "machineIntBinary";
    readonly type: PsVerifiedIrMachineIntegerType;
    readonly operation: PsVerifiedIrIntegerBinaryOp;
} | {
    readonly [__ps$tag$41]: "machineIntCompare";
    readonly type: PsVerifiedIrMachineIntegerType;
    readonly operation: PsVerifiedIrIntegerCompareOp;
} | {
    readonly [__ps$tag$41]: "floatBinary";
    readonly type: PsVerifiedIrFloatingType;
    readonly operation: PsVerifiedIrFloatBinaryOp;
} | {
    readonly [__ps$tag$41]: "floatCompare";
    readonly type: PsVerifiedIrFloatingType;
    readonly operation: PsVerifiedIrFloatCompareOp;
} | {
    readonly [__ps$tag$41]: "natAdd";
} | {
    readonly [__ps$tag$41]: "natSub";
} | {
    readonly [__ps$tag$41]: "natMul";
} | {
    readonly [__ps$tag$41]: "natDiv";
} | {
    readonly [__ps$tag$41]: "natMod";
} | {
    readonly [__ps$tag$41]: "natEq";
} | {
    readonly [__ps$tag$41]: "natNe";
} | {
    readonly [__ps$tag$41]: "natLe";
} | {
    readonly [__ps$tag$41]: "natLt";
} | {
    readonly [__ps$tag$41]: "intOfNat";
} | {
    readonly [__ps$tag$41]: "intRepr";
} | {
    readonly [__ps$tag$41]: "intNegSucc";
} | {
    readonly [__ps$tag$41]: "intNeg";
} | {
    readonly [__ps$tag$41]: "intAdd";
} | {
    readonly [__ps$tag$41]: "intSub";
} | {
    readonly [__ps$tag$41]: "intMul";
} | {
    readonly [__ps$tag$41]: "intEq";
} | {
    readonly [__ps$tag$41]: "intLe";
} | {
    readonly [__ps$tag$41]: "intLt";
} | {
    readonly [__ps$tag$41]: "boolNot";
} | {
    readonly [__ps$tag$41]: "boolAnd";
} | {
    readonly [__ps$tag$41]: "boolOr";
} | {
    readonly [__ps$tag$41]: "boolEq";
} | {
    readonly [__ps$tag$41]: "boolNe";
} | {
    readonly [__ps$tag$41]: "charOfNat";
} | {
    readonly [__ps$tag$41]: "charToNat";
} | {
    readonly [__ps$tag$41]: "stringPush";
} | {
    readonly [__ps$tag$41]: "stringSingleton";
} | {
    readonly [__ps$tag$41]: "stringLength";
} | {
    readonly [__ps$tag$41]: "stringAppend";
} | {
    readonly [__ps$tag$41]: "stringUtf8ByteSize";
} | {
    readonly [__ps$tag$41]: "stringNext";
} | {
    readonly [__ps$tag$41]: "stringGet";
} | {
    readonly [__ps$tag$41]: "stringAtEnd";
} | {
    readonly [__ps$tag$41]: "stringExtract";
} | {
    readonly [__ps$tag$41]: "stringEq";
} | {
    readonly [__ps$tag$41]: "arrayEmptyWithCapacity";
} | {
    readonly [__ps$tag$41]: "arraySize";
} | {
    readonly [__ps$tag$41]: "arrayPush";
} | {
    readonly [__ps$tag$41]: "arrayGet";
} | {
    readonly [__ps$tag$41]: "arrayGetD";
} | {
    readonly [__ps$tag$41]: "arraySet";
} | {
    readonly [__ps$tag$41]: "arraySetIfInBounds";
} | {
    readonly [__ps$tag$41]: "arrayMap";
} | {
    readonly [__ps$tag$41]: "arrayFoldl";
};
export declare const PsVerifiedIrIntrinsic: {
    readonly machineIntBinary: (__field0: PsVerifiedIrMachineIntegerType, __field1: PsVerifiedIrIntegerBinaryOp) => PsVerifiedIrIntrinsic;
    readonly machineIntCompare: (__field0: PsVerifiedIrMachineIntegerType, __field1: PsVerifiedIrIntegerCompareOp) => PsVerifiedIrIntrinsic;
    readonly floatBinary: (__field0: PsVerifiedIrFloatingType, __field1: PsVerifiedIrFloatBinaryOp) => PsVerifiedIrIntrinsic;
    readonly floatCompare: (__field0: PsVerifiedIrFloatingType, __field1: PsVerifiedIrFloatCompareOp) => PsVerifiedIrIntrinsic;
    readonly natAdd: PsVerifiedIrIntrinsic;
    readonly natSub: PsVerifiedIrIntrinsic;
    readonly natMul: PsVerifiedIrIntrinsic;
    readonly natDiv: PsVerifiedIrIntrinsic;
    readonly natMod: PsVerifiedIrIntrinsic;
    readonly natEq: PsVerifiedIrIntrinsic;
    readonly natNe: PsVerifiedIrIntrinsic;
    readonly natLe: PsVerifiedIrIntrinsic;
    readonly natLt: PsVerifiedIrIntrinsic;
    readonly intOfNat: PsVerifiedIrIntrinsic;
    readonly intRepr: PsVerifiedIrIntrinsic;
    readonly intNegSucc: PsVerifiedIrIntrinsic;
    readonly intNeg: PsVerifiedIrIntrinsic;
    readonly intAdd: PsVerifiedIrIntrinsic;
    readonly intSub: PsVerifiedIrIntrinsic;
    readonly intMul: PsVerifiedIrIntrinsic;
    readonly intEq: PsVerifiedIrIntrinsic;
    readonly intLe: PsVerifiedIrIntrinsic;
    readonly intLt: PsVerifiedIrIntrinsic;
    readonly boolNot: PsVerifiedIrIntrinsic;
    readonly boolAnd: PsVerifiedIrIntrinsic;
    readonly boolOr: PsVerifiedIrIntrinsic;
    readonly boolEq: PsVerifiedIrIntrinsic;
    readonly boolNe: PsVerifiedIrIntrinsic;
    readonly charOfNat: PsVerifiedIrIntrinsic;
    readonly charToNat: PsVerifiedIrIntrinsic;
    readonly stringPush: PsVerifiedIrIntrinsic;
    readonly stringSingleton: PsVerifiedIrIntrinsic;
    readonly stringLength: PsVerifiedIrIntrinsic;
    readonly stringAppend: PsVerifiedIrIntrinsic;
    readonly stringUtf8ByteSize: PsVerifiedIrIntrinsic;
    readonly stringNext: PsVerifiedIrIntrinsic;
    readonly stringGet: PsVerifiedIrIntrinsic;
    readonly stringAtEnd: PsVerifiedIrIntrinsic;
    readonly stringExtract: PsVerifiedIrIntrinsic;
    readonly stringEq: PsVerifiedIrIntrinsic;
    readonly arrayEmptyWithCapacity: PsVerifiedIrIntrinsic;
    readonly arraySize: PsVerifiedIrIntrinsic;
    readonly arrayPush: PsVerifiedIrIntrinsic;
    readonly arrayGet: PsVerifiedIrIntrinsic;
    readonly arrayGetD: PsVerifiedIrIntrinsic;
    readonly arraySet: PsVerifiedIrIntrinsic;
    readonly arraySetIfInBounds: PsVerifiedIrIntrinsic;
    readonly arrayMap: PsVerifiedIrIntrinsic;
    readonly arrayFoldl: PsVerifiedIrIntrinsic;
};
declare const __ps$tag$42: unique symbol;
export type PsVerifiedIrExpr = {
    readonly [__ps$tag$42]: "literal";
    readonly value: PsVerifiedIrLiteral;
} | {
    readonly [__ps$tag$42]: "var";
    readonly name: string;
} | {
    readonly [__ps$tag$42]: "intrinsic";
    readonly operation: PsVerifiedIrIntrinsic;
    readonly typeArguments: List<PsVerifiedIrType>;
    readonly arguments: List<PsVerifiedIrExpr>;
} | {
    readonly [__ps$tag$42]: "lambda";
    readonly parameters: List<PsVerifiedIrParameter>;
    readonly resultType: PsVerifiedIrType;
    readonly body: PsVerifiedIrExpr;
} | {
    readonly [__ps$tag$42]: "call";
    readonly fn: PsVerifiedIrExpr;
    readonly typeArguments: List<PsVerifiedIrType>;
    readonly arguments: List<PsVerifiedIrExpr>;
} | {
    readonly [__ps$tag$42]: "letE";
    readonly name: string;
    readonly type: PsVerifiedIrType;
    readonly value: PsVerifiedIrExpr;
    readonly body: PsVerifiedIrExpr;
} | {
    readonly [__ps$tag$42]: "ifE";
    readonly condition: PsVerifiedIrExpr;
    readonly thenBranch: PsVerifiedIrExpr;
    readonly elseBranch: PsVerifiedIrExpr;
} | {
    readonly [__ps$tag$42]: "record";
    readonly structureName: string;
    readonly typeArguments: List<PsVerifiedIrType>;
    readonly fields: List<Prod<string, PsVerifiedIrExpr>>;
} | {
    readonly [__ps$tag$42]: "projection";
    readonly structureName: string;
    readonly typeArguments: List<PsVerifiedIrType>;
    readonly target: PsVerifiedIrExpr;
    readonly field: string;
} | {
    readonly [__ps$tag$42]: "constructor";
    readonly inductiveName: string;
    readonly constructorName: string;
    readonly typeArguments: List<PsVerifiedIrType>;
    readonly fields: List<Prod<string, PsVerifiedIrExpr>>;
} | {
    readonly [__ps$tag$42]: "matchE";
    readonly inductiveName: string;
    readonly typeArguments: List<PsVerifiedIrType>;
    readonly scrutinee: PsVerifiedIrExpr;
    readonly alternatives: List<Prod<string, Prod<List<PsVerifiedIrMatchBinding>, PsVerifiedIrExpr>>>;
};
export declare const PsVerifiedIrExpr: {
    readonly literal: (__field0: PsVerifiedIrLiteral) => PsVerifiedIrExpr;
    readonly var: (__field0: string) => PsVerifiedIrExpr;
    readonly intrinsic: (__field0: PsVerifiedIrIntrinsic, __field1: List<PsVerifiedIrType>, __field2: List<PsVerifiedIrExpr>) => PsVerifiedIrExpr;
    readonly lambda: (__field0: List<PsVerifiedIrParameter>, __field1: PsVerifiedIrType, __field2: PsVerifiedIrExpr) => PsVerifiedIrExpr;
    readonly call: (__field0: PsVerifiedIrExpr, __field1: List<PsVerifiedIrType>, __field2: List<PsVerifiedIrExpr>) => PsVerifiedIrExpr;
    readonly letE: (__field0: string, __field1: PsVerifiedIrType, __field2: PsVerifiedIrExpr, __field3: PsVerifiedIrExpr) => PsVerifiedIrExpr;
    readonly ifE: (__field0: PsVerifiedIrExpr, __field1: PsVerifiedIrExpr, __field2: PsVerifiedIrExpr) => PsVerifiedIrExpr;
    readonly record: (__field0: string, __field1: List<PsVerifiedIrType>, __field2: List<Prod<string, PsVerifiedIrExpr>>) => PsVerifiedIrExpr;
    readonly projection: (__field0: string, __field1: List<PsVerifiedIrType>, __field2: PsVerifiedIrExpr, __field3: string) => PsVerifiedIrExpr;
    readonly constructor: (__field0: string, __field1: string, __field2: List<PsVerifiedIrType>, __field3: List<Prod<string, PsVerifiedIrExpr>>) => PsVerifiedIrExpr;
    readonly matchE: (__field0: string, __field1: List<PsVerifiedIrType>, __field2: PsVerifiedIrExpr, __field3: List<Prod<string, Prod<List<PsVerifiedIrMatchBinding>, PsVerifiedIrExpr>>>) => PsVerifiedIrExpr;
};
declare const __ps$tag$43: unique symbol;
export type PsErasureNameIndex<T0> = {
    readonly [__ps$tag$43]: "empty";
} | {
    readonly [__ps$tag$43]: "bucket";
    readonly entries: List<Prod<PsName, T0>>;
} | {
    readonly [__ps$tag$43]: "branch";
    readonly left: PsErasureNameIndex<T0>;
    readonly right: PsErasureNameIndex<T0>;
};
export declare const PsErasureNameIndex: {
    readonly empty: <T0>() => PsErasureNameIndex<T0>;
    readonly bucket: <T0>(__field0: List<Prod<PsName, T0>>) => PsErasureNameIndex<T0>;
    readonly branch: <T0>(__field0: PsErasureNameIndex<T0>, __field1: PsErasureNameIndex<T0>) => PsErasureNameIndex<T0>;
};
declare const __ps$tag$44: unique symbol;
export type PsErasedBinderKind = {
    readonly [__ps$tag$44]: "type";
} | {
    readonly [__ps$tag$44]: "proof";
} | {
    readonly [__ps$tag$44]: "runtime";
};
export declare const PsErasedBinderKind: {
    readonly type: PsErasedBinderKind;
    readonly proof: PsErasedBinderKind;
    readonly runtime: PsErasedBinderKind;
};
declare const __ps$tag$45: unique symbol;
export type PsErasureError = {
    readonly [__ps$tag$45]: "fuelExhausted";
} | {
    readonly [__ps$tag$45]: "binderMismatch";
} | {
    readonly [__ps$tag$45]: "looseBoundVariable";
} | {
    readonly [__ps$tag$45]: "unresolvedMetavariable";
} | {
    readonly [__ps$tag$45]: "unknownLocal";
    readonly id: bigint;
} | {
    readonly [__ps$tag$45]: "erasedLocalUsed";
    readonly id: bigint;
} | {
    readonly [__ps$tag$45]: "unsupportedRuntimeTerm";
} | {
    readonly [__ps$tag$45]: "unsupportedApplication";
} | {
    readonly [__ps$tag$45]: "unknownConstant";
    readonly name: PsName;
};
export declare const PsErasureError: {
    readonly fuelExhausted: PsErasureError;
    readonly binderMismatch: PsErasureError;
    readonly looseBoundVariable: PsErasureError;
    readonly unresolvedMetavariable: PsErasureError;
    readonly unknownLocal: (__field0: bigint) => PsErasureError;
    readonly erasedLocalUsed: (__field0: bigint) => PsErasureError;
    readonly unsupportedRuntimeTerm: PsErasureError;
    readonly unsupportedApplication: PsErasureError;
    readonly unknownConstant: (__field0: PsName) => PsErasureError;
};
declare const __ps$tag$46: unique symbol;
export type PsCompilerSourceKind = {
    readonly [__ps$tag$46]: "lean";
} | {
    readonly [__ps$tag$46]: "proofScript";
};
export declare const PsCompilerSourceKind: {
    readonly lean: PsCompilerSourceKind;
    readonly proofScript: PsCompilerSourceKind;
};
declare const __ps$tag$47: unique symbol;
export type PsCompilerError = {
    readonly [__ps$tag$47]: "translation";
    readonly error: PsTranslationError;
} | {
    readonly [__ps$tag$47]: "leanFrontend";
    readonly error: PsLeanFrontendError;
} | {
    readonly [__ps$tag$47]: "proofScriptFrontend";
    readonly error: PsProofScriptFrontendError;
} | {
    readonly [__ps$tag$47]: "elaboration";
    readonly error: PsElabError;
} | {
    readonly [__ps$tag$47]: "admission";
    readonly error: PsCheckedAdmissionCodecError;
} | {
    readonly [__ps$tag$47]: "erasure";
    readonly error: PsErasureError;
};
export declare const PsCompilerError: {
    readonly translation: (__field0: PsTranslationError) => PsCompilerError;
    readonly leanFrontend: (__field0: PsLeanFrontendError) => PsCompilerError;
    readonly proofScriptFrontend: (__field0: PsProofScriptFrontendError) => PsCompilerError;
    readonly elaboration: (__field0: PsElabError) => PsCompilerError;
    readonly admission: (__field0: PsCheckedAdmissionCodecError) => PsCompilerError;
    readonly erasure: (__field0: PsErasureError) => PsCompilerError;
};
declare const __ps$tag$48: unique symbol;
export type PsTsEmitError = {
    readonly [__ps$tag$48]: "fuelExhausted";
} | {
    readonly [__ps$tag$48]: "unsupportedIntrinsic";
} | {
    readonly [__ps$tag$48]: "intrinsicArity";
} | {
    readonly [__ps$tag$48]: "unknownStructure";
    readonly name: string;
} | {
    readonly [__ps$tag$48]: "unknownInductive";
    readonly name: string;
} | {
    readonly [__ps$tag$48]: "genericValueUnsupported";
    readonly name: string;
} | {
    readonly [__ps$tag$48]: "targetWordSizeRequired";
};
export declare const PsTsEmitError: {
    readonly fuelExhausted: PsTsEmitError;
    readonly unsupportedIntrinsic: PsTsEmitError;
    readonly intrinsicArity: PsTsEmitError;
    readonly unknownStructure: (__field0: string) => PsTsEmitError;
    readonly unknownInductive: (__field0: string) => PsTsEmitError;
    readonly genericValueUnsupported: (__field0: string) => PsTsEmitError;
    readonly targetWordSizeRequired: PsTsEmitError;
};
declare const __ps$tag$49: unique symbol;
export type PsCompilerTypeScriptError = {
    readonly [__ps$tag$49]: "compiler";
    readonly error: PsCompilerError;
} | {
    readonly [__ps$tag$49]: "emit";
    readonly error: PsTsEmitError;
};
export declare const PsCompilerTypeScriptError: {
    readonly compiler: (__field0: PsCompilerError) => PsCompilerTypeScriptError;
    readonly emit: (__field0: PsTsEmitError) => PsCompilerTypeScriptError;
};
export declare function psLexStringToListFromWithFuel(fuel: bigint, __ps_eta_0: string, __ps_eta_1: bigint): List<string>;
export declare function psLexStringToListFrom(source: string, position: bigint): List<string>;
export declare function psLexStringToList(source: string): List<string>;
export declare function psLexCursorFromString(source: string): PsLexCursor;
export declare function psLexCursorDone(cursor: PsLexCursor): boolean;
export declare function psLexCursorPeek(cursor: PsLexCursor): Option<string>;
export declare function psLexAdvancePosition(position: PsSourcePos, char: string): PsSourcePos;
export declare function psLexCursorAdvance(cursor: PsLexCursor): Option<PsLexStep>;
export declare function psLexCursorPeekSecond(cursor: PsLexCursor): Option<string>;
export declare function psTokenKindEq(left: PsTokenKind, right: PsTokenKind): boolean;
export declare function psLexSpan(start: PsSourcePos, stop: PsSourcePos): PsSourceSpan;
export declare function psLexString(charsRev: List<string>): string;
export declare function psLexAdvanceChar(position: PsSourcePos, char: string): PsSourcePos;
export declare function psLexAdvanceTwo(position: PsSourcePos, first: string, second: string): PsSourcePos;
export declare function psLexListLength<T0>(xs: List<T0>): bigint;
export declare function psLexCharEq(left: string, right: string): boolean;
export declare function psLexNatBetween(lower: bigint, value: bigint, upper: bigint): boolean;
export declare function psLexWhitespace(char: string): boolean;
export declare function psLexSkipLineComment(remaining: List<string>, __ps_eta_0: PsSourcePos): PsLexCursor;
export declare function psLexSkipBlockCommentWithFuel(fuel: bigint, __ps_eta_0: bigint, __ps_eta_1: List<string>, __ps_eta_2: PsSourcePos, __ps_eta_3: PsSourcePos): Except<PsLexError, PsLexCursor>;
export declare function psLexSkipBlockComment(depth: bigint, remaining: List<string>, start: PsSourcePos, position: PsSourcePos): Except<PsLexError, PsLexCursor>;
export declare function psLexSkipTriviaWithFuel(fuel: bigint, __ps_eta_0: List<string>, __ps_eta_1: PsSourcePos): Except<PsLexError, PsLexCursor>;
export declare function psLexSkipTrivia(remaining: List<string>, position: PsSourcePos): Except<PsLexError, PsLexCursor>;
export declare function psLexLetterLike(char: string): boolean;
export declare function psLexNumericSubscript(char: string): boolean;
export declare function psLexSubscriptAlnum(char: string): boolean;
export declare function psLexAsciiAlpha(char: string): boolean;
export declare function psLexDigit(char: string): boolean;
export declare function psLexIdentifierStart(char: string): boolean;
export declare function psLexIdentifierContinue(char: string): boolean;
export declare function psLexNaturalContinue(char: string): boolean;
export declare function psLexReadIdentifier(remaining: List<string>, __ps_eta_0: PsSourcePos, __ps_eta_1: List<string>): PsLexRead;
export declare function psLexReadNatural(remaining: List<string>, __ps_eta_0: PsSourcePos, __ps_eta_1: List<string>): PsLexRead;
export declare function psLexReadStringBodyWithFuel(fuel: bigint, __ps_eta_0: List<string>, __ps_eta_1: PsSourcePos, __ps_eta_2: PsSourcePos, __ps_eta_3: List<string>): Except<PsLexError, PsLexRead>;
export declare function psLexReadStringBody(remaining: List<string>, position: PsSourcePos, start: PsSourcePos, charsRev: List<string>): Except<PsLexError, PsLexRead>;
export declare function psLexHexDigit(char: string): boolean;
export declare function psLexCharacterEscapeAllowed(char: string): boolean;
export declare function psLexCharacterError(start: PsSourcePos, position: PsSourcePos): Except<PsLexError, PsLexRead>;
export declare function psLexReadCharacterHex2(position: PsSourcePos, start: PsSourcePos, charsRev: List<string>, remaining: List<string>): Except<PsLexError, PsLexRead>;
export declare function psLexReadCharacterHex4(position: PsSourcePos, start: PsSourcePos, charsRev: List<string>, remaining: List<string>): Except<PsLexError, PsLexRead>;
export declare function psLexReadCharacterBody(remaining: List<string>, position: PsSourcePos, start: PsSourcePos, charsRev: List<string>): Except<PsLexError, PsLexRead>;
export declare function psLexPairEq(first: string, second: string, expectedFirst: string, expectedSecond: string): boolean;
export declare function psLexIsTwoCharSymbol(first: string, second: string): boolean;
export declare function psLexTokenFromRead(kind: PsTokenKind, start: PsSourcePos, read: PsLexRead): PsToken;
export declare function psLexReadToken(cursor: PsLexCursor): Except<PsLexError, Prod<PsToken, PsLexCursor>>;
export declare function psLexAllWorker(inputBound: bigint, fuel: bigint, __ps_eta_0: PsLexCursor): Except<PsLexError, List<PsToken>>;
export declare function psLexAllWithFuel(fuel: bigint, cursor: PsLexCursor): Except<PsLexError, List<PsToken>>;
export declare function psLex(source: string): Except<PsLexError, List<PsToken>>;
export declare function psNameDepth(name: PsName): bigint;
export declare function psStringEqFromWithFuel(fuel: bigint, __ps_eta_0: string, __ps_eta_1: string, __ps_eta_2: bigint, __ps_eta_3: bigint): boolean;
export declare function psStringEqFrom(left: string, right: string, leftPos: bigint, rightPos: bigint): boolean;
export declare function psStringEq(left: string, right: string): boolean;
export declare function psNatToString(value: bigint): string;
export declare function psNameEq(left: PsName, __ps_eta_0: PsName): boolean;
export declare function psNameAppendStr(parent: PsName, value: string): PsName;
export declare function psNameAppendNum(parent: PsName, value: bigint): PsName;
export declare function psNameToString(name: PsName): string;
export declare function psNameLastComponent(name: PsName): string;
export declare function psTokenCursorFromTokens(tokens: List<PsToken>): PsTokenCursor;
export declare function psTokenCursorPeek(cursor: PsTokenCursor): Option<PsToken>;
export declare function psTokenCursorDone(cursor: PsTokenCursor): boolean;
export declare function psTokenCursorAdvance(cursor: PsTokenCursor): Option<PsTokenRead>;
export declare function psTokenCursorAtText(cursor: PsTokenCursor, text: string): boolean;
export declare function psTokenCursorAtKind(cursor: PsTokenCursor, kind: PsTokenKind): boolean;
export declare function psTokenCursorExpectText(cursor: PsTokenCursor, expected: string): Except<PsParseError, PsTokenRead>;
export declare function psTokenCursorExpectKind(cursor: PsTokenCursor, expected: PsTokenKind): Except<PsParseError, PsTokenRead>;
export declare function psParseListLength<T0>(xs: List<T0>): bigint;
export declare function psParseListReverseAcc<T0>(xs: List<T0>, __ps_eta_0: List<T0>): List<T0>;
export declare function psParseListReverse<T0>(xs: List<T0>): List<T0>;
export declare function psParseListAppend<T0>(xs: List<T0>, __ps_eta_0: List<T0>): List<T0>;
export declare function psSyntaxSpanJoin(start: PsSourceSpan, stop: PsSourceSpan): PsSourceSpan;
export declare function psSyntaxTermSpan(_eq0: PsSyntaxTerm): PsSourceSpan;
export declare function psSyntaxSyntheticName(text: string, span: PsSourceSpan): PsSyntaxName;
export declare function psSyntaxSyntheticReference(text: string, span: PsSourceSpan): PsSyntaxTerm;
export declare function psSyntaxCompilerPure(value: PsSyntaxTerm, span: PsSourceSpan): PsSyntaxTerm;
export declare function psSyntaxCompilerBind(binder: PsSyntaxBinderHead, binderType: PsSyntaxTerm, action: PsSyntaxTerm, body: PsSyntaxTerm, span: PsSourceSpan): PsSyntaxTerm;
export declare function psParseSyntaxNameTailWithFuel(fuel: bigint, __ps_eta_0: List<string>, __ps_eta_1: PsSourcePos, __ps_eta_2: PsSourcePos, __ps_eta_3: List<PsToken>): Except<PsParseError, PsParseResult<PsSyntaxName>>;
export declare function psParseSyntaxNameTail(segmentsRev: List<string>, start: PsSourcePos, stop: PsSourcePos, tokens: List<PsToken>): Except<PsParseError, PsParseResult<PsSyntaxName>>;
export declare function psParseSyntaxName(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxName>>;
export declare function psTokenCursorStartsNamedAssignment(cursor: PsTokenCursor): boolean;
export declare function psParseRecordFieldsWithFuel(parseTerm: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<Prod<PsSyntaxName, PsSyntaxTerm>>): Except<PsParseError, PsParseResult<List<Prod<PsSyntaxName, PsSyntaxTerm>>>>;
export declare function psParseRecordLiteral(parseTerm: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseSimpleTerm(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseBinderOpening(cursor: PsTokenCursor): Except<PsParseError, PsSyntaxBinderOpening>;
export declare function psParseBinderClosing(opening: PsSyntaxBinderOpening, cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSourceSpan>>;
export declare function psTokenCursorAtBinderStart(cursor: PsTokenCursor): boolean;
export declare function psTokenCursorAtArrow(cursor: PsTokenCursor): boolean;
export declare function psTokenCursorExpectArrow(cursor: PsTokenCursor): Except<PsParseError, PsTokenRead>;
export declare function psSyntaxAnonymousExplicitBinder(span: PsSourceSpan): PsSyntaxBinderHead;
export declare function psSyntaxPatternSpan(_eq0: PsSyntaxPattern): PsSourceSpan;
export declare function psParsePatternBindersWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<PsSyntaxName>): Except<PsParseError, PsParseResult<List<PsSyntaxName>>>;
export declare function psParseConstructorPatternTail(constructorName: PsSyntaxName, cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxPattern>>;
export declare function psParseBasicPattern(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxPattern>>;
export declare function psLeanTermStop(term: PsSyntaxTerm): PsSourcePos;
export declare function psLeanTokenCursor(remaining: List<PsToken>): PsTokenCursor;
export declare function psLeanBoolNot(value: boolean): boolean;
export declare function psLeanPatternParseResult(value: PsSyntaxPattern, remaining: List<PsToken>): PsParseResult<PsSyntaxPattern>;
export declare function psParseLeanImport(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxImport>>;
export declare function psLeanReservedApplicationToken(token: PsToken): boolean;
export declare function psLeanApplicationWithArgument(current: PsSyntaxTerm, argument: PsSyntaxTerm): PsSyntaxTerm;
export declare function psLeanListConstructorName(constructor: string, span: PsSourceSpan): PsSyntaxName;
export declare function psLeanBuildListLiteral(elements: List<PsSyntaxTerm>, span: PsSourceSpan): PsSyntaxTerm;
export declare function psParseLeanListLiteralWithFuel(parseTerm: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, fuel: bigint, __ps_eta_0: PsSourcePos, __ps_eta_1: PsTokenCursor, __ps_eta_2: List<PsSyntaxTerm>): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanListLiteral(parseTerm: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, opening: PsTokenRead): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psLeanCanStartSimpleArgument(current: PsSyntaxTerm, cursor: PsTokenCursor): boolean;
export declare function psParseLeanApplicationTailWithFuel(parseParenthesized: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, fuel: bigint, __ps_eta_0: PsSyntaxTerm, __ps_eta_1: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanApplicationWithFuel(parseParenthesized: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, fuel: bigint, cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanSimpleApplicationWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanSimpleApplication(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanProductWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanProduct(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanBinderTypeWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanBinderType(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanBinderNamesWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<PsSyntaxName>): Except<PsParseError, PsParseResult<List<PsSyntaxName>>>;
export declare function psLeanBinderPairsFromNames(kind: PsSyntaxBinderKind, span: PsSourceSpan, type: PsSyntaxTerm, names: List<PsSyntaxName>): List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>;
export declare function psParseLeanBinderGroup(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>>>;
export declare function psLeanPrependBinderGroupReverse(group: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, __ps_eta_0: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>): List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>;
export declare function psParseLeanBinder(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>>;
export declare function psParseLeanBindersWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>): Except<PsParseError, PsParseResult<List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>>>;
export declare function psParseLeanArrowTail(parseCodomain: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, domain: PsParseResult<PsSyntaxTerm>): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanDependentArrowTail(parseCodomain: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, binder: PsParseResult<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psLeanPatternBinderName(token: PsToken, fallback: string): PsSyntaxName;
export declare function psParseLeanListPattern(cursor: PsTokenCursor): Option<Except<PsParseError, PsParseResult<PsSyntaxPattern>>>;
export declare function psLeanNatPatternName(constructor: string, span: PsSourceSpan): PsSyntaxName;
export declare function psParseLeanNatPattern(cursor: PsTokenCursor): Option<Except<PsParseError, PsParseResult<PsSyntaxPattern>>>;
export declare function psParseLeanPattern(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxPattern>>;
export declare function psParseLeanMatchAlternativesAtColumnWithFuel(parseTerm: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, branchColumn: bigint, fuel: bigint, __ps_eta_0: bigint, __ps_eta_1: PsTokenCursor, __ps_eta_2: List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>): Except<PsParseError, PsParseResult<List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>>>;
export declare function psParseLeanMatchAlternativesWithFuel(parseTerm: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, fuel: bigint, cursor: PsTokenCursor, alternativesRev: List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>): Except<PsParseError, PsParseResult<List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>>>;
export declare function psParseLeanDoWithFuel(parseTerm: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, fuel: bigint, __ps_eta_0: PsSourcePos, __ps_eta_1: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanRecordApplicationTailWithFuel(parseTerm: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, fuel: bigint, __ps_eta_0: PsSyntaxTerm, __ps_eta_1: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanTermWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanTerm(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseLeanInductiveConstructorsWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<PsSyntaxInductiveConstructor>): Except<PsParseError, PsParseResult<List<PsSyntaxInductiveConstructor>>>;
export declare function psLeanTopLevelDeclarationToken(token: PsToken): boolean;
export declare function psSplitTokensThroughLine(line: bigint, tokens: List<PsToken>): Prod<List<PsToken>, List<PsToken>>;
export declare function psParseLeanStructureField(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>>;
export declare function psParseLeanStructureFieldsWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>): Except<PsParseError, PsParseResult<List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>>>;
export declare function psParseLeanStructureDeclaration(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxDeclaration>>;
export declare function psParseLeanInductiveDeclaration(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxDeclaration>>;
export declare function psParseLeanEquationPatternsWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<PsSyntaxPattern>): Except<PsParseError, PsParseResult<List<PsSyntaxPattern>>>;
export declare function psParseLeanEquationClausesWithFuel(parseTerm: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<PsLeanEquationClause>): Except<PsParseError, PsParseResult<List<PsLeanEquationClause>>>;
export declare function psLeanPatternIsWildcard(pattern: PsSyntaxPattern): boolean;
export declare function psLeanStringListEq(left: List<string>, __ps_eta_0: List<string>): boolean;
export declare function psLeanBoolEq(left: boolean, right: boolean): boolean;
export declare function psLeanPatternHeadEq(left: PsSyntaxPattern, right: PsSyntaxPattern): boolean;
export declare function psLeanPatternListContainsHead(patterns: List<PsSyntaxPattern>, target: PsSyntaxPattern): boolean;
export declare function psLeanEquationHeadPatternsAcc(clauses: List<PsLeanEquationClause>, __ps_eta_0: List<PsSyntaxPattern>): List<PsSyntaxPattern>;
export declare function psLeanEquationHeadPatterns(clauses: List<PsLeanEquationClause>): List<PsSyntaxPattern>;
export declare function psLeanEquationClauseForBranch(branch: PsSyntaxPattern, clause: PsLeanEquationClause): Option<PsLeanEquationClause>;
export declare function psLeanEquationClausesForBranchAcc(branch: PsSyntaxPattern, clauses: List<PsLeanEquationClause>, __ps_eta_0: List<PsLeanEquationClause>): List<PsLeanEquationClause>;
export declare function psLeanEquationClausesForBranch(branch: PsSyntaxPattern, clauses: List<PsLeanEquationClause>): List<PsLeanEquationClause>;
export declare function psLeanPatternListIsEmpty(patterns: List<PsSyntaxPattern>): boolean;
export declare function psLeanFirstCompletedEquation(clauses: List<PsLeanEquationClause>): Option<PsLeanEquationClause>;
export declare function psLeanMapPatternAlternatives(lowerClauses: (_arg0: List<PsLeanEquationClause>) => Option<PsSyntaxTerm>, clauses: List<PsLeanEquationClause>, patterns: List<PsSyntaxPattern>): Option<List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>>;
export declare function psLeanLowerEquationClauses(_arguments: List<PsSyntaxName>, __ps_eta_0: List<PsLeanEquationClause>): Option<PsSyntaxTerm>;
export declare function psLeanFlattenForallBinders(type: PsSyntaxTerm): Prod<List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, PsSyntaxTerm>;
export declare function psLeanEquationBinderName(index: bigint, head: PsSyntaxBinderHead): PsSyntaxName;
export declare function psLeanPrepareEquationBindersAcc(remaining: bigint, __ps_eta_0: bigint, __ps_eta_1: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, __ps_eta_2: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, __ps_eta_3: List<PsSyntaxName>): Option<Prod<List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, List<PsSyntaxName>>>;
export declare function psLeanEquationClausesHaveArity(arity: bigint, clauses: List<PsLeanEquationClause>): boolean;
export declare function psLeanEquationArity(clauses: List<PsLeanEquationClause>): Option<bigint>;
export declare function psLeanLowerEquationValue(type: PsSyntaxTerm, clauses: List<PsLeanEquationClause>): Option<PsSyntaxTerm>;
export declare function psFinishLeanValueDeclaration(keyword: PsToken, isPartial: boolean, isDefinition: boolean, name: PsSyntaxName, binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, type: PsSyntaxTerm, value: PsSyntaxTerm, cursor: PsTokenCursor): PsParseResult<PsSyntaxDeclaration>;
export declare function psParseLeanDeclaration(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxDeclaration>>;
export declare function psParseLeanImportsWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<PsSyntaxImport>): Except<PsParseError, PsParseResult<List<PsSyntaxImport>>>;
export declare function psParseLeanDeclarationsWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<PsSyntaxDeclaration>): Except<PsParseError, PsParseResult<List<PsSyntaxDeclaration>>>;
export declare function psParseLeanTokens(tokens: List<PsToken>): Except<PsParseError, PsSyntaxModule>;
export declare function psParseLeanSource(source: string): Except<PsLeanFrontendError, PsSyntaxModule>;
export declare function psProofScriptTermStart(term: PsSyntaxTerm): PsSourcePos;
export declare function psProofScriptTermStop(term: PsSyntaxTerm): PsSourcePos;
export declare function psParseOptionalSemicolon(cursor: PsTokenCursor): PsTokenCursor;
export declare function psProofScriptBoolNot(value: boolean): boolean;
export declare function psProofScriptBoolAnd(left: boolean, right: boolean): boolean;
export declare function psProofScriptBoolOr(left: boolean, right: boolean): boolean;
export declare function psParseProofScriptImport(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxImport>>;
export declare function psParseProofScriptCallArgsWithFuel(parseArgument: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<PsSyntaxTerm>): Except<PsParseError, PsProofScriptCallArgs>;
export declare function psProofScriptCallAdjacent(term: PsSyntaxTerm, cursor: PsTokenCursor): boolean;
export declare function psParseProofScriptApplicationWithFuel(parseArgument: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, fuel: bigint, cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseProofScriptSimpleApplicationWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseProofScriptSimpleApplication(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseProofScriptArrowTail(parseCodomain: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, domain: PsParseResult<PsSyntaxTerm>): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseProofScriptDependentArrowTail(parseCodomain: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, binder: PsParseResult<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseProofScriptGroupedType(parseType: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, opening: PsSyntaxBinderOpening): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseProofScriptNestedBinderType(parseType: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseProofScriptBinderTypeWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseProofScriptBinderType(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseProofScriptBinder(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>>;
export declare function psParseProofScriptBindersWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>): Except<PsParseError, PsParseResult<List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>>>;
export declare function psParseProofScriptMatchAlternativesWithFuel(parseTerm: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>): Except<PsParseError, PsParseResult<List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>>>;
export declare function psParseProofScriptDoWithFuel(parseTerm: (_arg0: PsTokenCursor) => Except<PsParseError, PsParseResult<PsSyntaxTerm>>, fuel: bigint, __ps_eta_0: PsSourcePos, __ps_eta_1: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseProofScriptTermWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseProofScriptTerm(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxTerm>>;
export declare function psParseProofScriptInductiveConstructorsWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<PsSyntaxInductiveConstructor>): Except<PsParseError, PsParseResult<List<PsSyntaxInductiveConstructor>>>;
export declare function psParseProofScriptStructureField(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>>;
export declare function psParseProofScriptStructureFieldsWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>): Except<PsParseError, PsParseResult<List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>>>;
export declare function psParseProofScriptStructureDeclaration(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxDeclaration>>;
export declare function psParseProofScriptInductiveDeclaration(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxDeclaration>>;
export declare function psParseProofScriptDeclaration(cursor: PsTokenCursor): Except<PsParseError, PsParseResult<PsSyntaxDeclaration>>;
export declare function psParseProofScriptImportsWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<PsSyntaxImport>): Except<PsParseError, PsParseResult<List<PsSyntaxImport>>>;
export declare function psParseProofScriptDeclarationsWithFuel(fuel: bigint, __ps_eta_0: PsTokenCursor, __ps_eta_1: List<PsSyntaxDeclaration>): Except<PsParseError, PsParseResult<List<PsSyntaxDeclaration>>>;
export declare function psParseProofScriptTokens(tokens: List<PsToken>): Except<PsParseError, PsSyntaxModule>;
export declare function psParseProofScriptSource(source: string): Except<PsProofScriptFrontendError, PsSyntaxModule>;
export declare function psPrintCommonConcat2(left: string, right: string): string;
export declare function psPrintCommonConcat3(first: string, second: string, third: string): string;
export declare function psPrintJoin(separator: string, values: List<string>): string;
export declare function psPrintSyntaxName(name: PsSyntaxName): Except<PsSourcePrintError, string>;
export declare function psPrintSyntaxNames(names: List<PsSyntaxName>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintBinderDelimiters(kind: PsSyntaxBinderKind): Prod<string, string>;
export declare function psPrintPattern(pattern: PsSyntaxPattern): Except<PsSourcePrintError, string>;
export declare function psSyntaxTermSimpleForApplication(_eq0: PsSyntaxTerm): boolean;
export declare function psPrintArrowChain(binders: List<string>, body: string): string;
export declare function psPrintLeanBoolNot(value: boolean): boolean;
export declare function psPrintLeanConcat2(a: string, b: string): string;
export declare function psPrintLeanConcat3(a: string, b: string, c: string): string;
export declare function psPrintLeanConcat4(a: string, b: string, c: string, d: string): string;
export declare function psPrintLeanConcat5(a: string, b: string, c: string, d: string, e: string): string;
export declare function psPrintLeanConcat6(a: string, b: string, c: string, d: string, e: string, f: string): string;
export declare function psPrintLeanSpaceJoinedSuffix(values: List<string>): string;
export declare function psPrintLeanMapRecordFields(printField: (_arg0: Prod<PsSyntaxName, PsSyntaxTerm>) => Except<PsSourcePrintError, string>, fields: List<Prod<PsSyntaxName, PsSyntaxTerm>>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintLeanMapTerms(printTerm: (_arg0: PsSyntaxTerm) => Except<PsSourcePrintError, string>, terms: List<PsSyntaxTerm>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintLeanMapBinders(printBinder: (_arg0: Prod<PsSyntaxBinderHead, PsSyntaxTerm>) => Except<PsSourcePrintError, string>, binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintLeanMapAlternatives(printAlternative: (_arg0: Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>) => Except<PsSourcePrintError, string>, alternatives: List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintLeanMapConstructors(printConstructor: (_arg0: PsSyntaxInductiveConstructor) => Except<PsSourcePrintError, string>, constructors: List<PsSyntaxInductiveConstructor>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintLeanMapImports(printImport: (_arg0: PsSyntaxImport) => Except<PsSourcePrintError, string>, imports: List<PsSyntaxImport>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintLeanMapDeclarations(printDeclaration: (_arg0: PsSyntaxDeclaration) => Except<PsSourcePrintError, string>, declarations: List<PsSyntaxDeclaration>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintLeanTermWithFuel(fuel: bigint, __ps_eta_0: PsSyntaxTerm): Except<PsSourcePrintError, string>;
export declare function psPrintLeanTerm(term: PsSyntaxTerm): Except<PsSourcePrintError, string>;
export declare function psPrintLeanBinder(binder: Prod<PsSyntaxBinderHead, PsSyntaxTerm>): Except<PsSourcePrintError, string>;
export declare function psPrintLeanStructureField(field: Prod<PsSyntaxBinderHead, PsSyntaxTerm>): Except<PsSourcePrintError, string>;
export declare function psPrintLeanConstructor(constructor: PsSyntaxInductiveConstructor): Except<PsSourcePrintError, string>;
export declare function psPrintLeanDeclaration(declaration: PsSyntaxDeclaration): Except<PsSourcePrintError, string>;
export declare function psPrintLeanImport(sourceImport: PsSyntaxImport): Except<PsSourcePrintError, string>;
export declare function psPrintLeanAppendStrings(xs: List<string>, __ps_eta_0: List<string>): List<string>;
export declare function psPrintLeanModuleParts(sourceImports: List<PsSyntaxImport>, sourceDeclarations: List<PsSyntaxDeclaration>): Except<PsSourcePrintError, string>;
export declare function psPrintLeanModule(module: PsSyntaxModule): Except<PsSourcePrintError, string>;
export declare function psPrintProofScriptBoolNot(value: boolean): boolean;
export declare function psPrintProofScriptConcat2(a: string, b: string): string;
export declare function psPrintProofScriptConcat3(a: string, b: string, c: string): string;
export declare function psPrintProofScriptConcat4(a: string, b: string, c: string, d: string): string;
export declare function psPrintProofScriptConcat5(a: string, b: string, c: string, d: string, e: string): string;
export declare function psPrintProofScriptConcat6(a: string, b: string, c: string, d: string, e: string, f: string): string;
export declare function psPrintProofScriptUnitCallArgs(args: List<PsSyntaxTerm>): boolean;
export declare function psPrintProofScriptMapRecordFields(printField: (_arg0: Prod<PsSyntaxName, PsSyntaxTerm>) => Except<PsSourcePrintError, string>, fields: List<Prod<PsSyntaxName, PsSyntaxTerm>>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintProofScriptMapTerms(printTerm: (_arg0: PsSyntaxTerm) => Except<PsSourcePrintError, string>, terms: List<PsSyntaxTerm>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintProofScriptMapBinders(printBinder: (_arg0: Prod<PsSyntaxBinderHead, PsSyntaxTerm>) => Except<PsSourcePrintError, string>, binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintProofScriptMapAlternatives(printAlternative: (_arg0: Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>) => Except<PsSourcePrintError, string>, alternatives: List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintProofScriptTermWithFuel(fuel: bigint, __ps_eta_0: PsSyntaxTerm): Except<PsSourcePrintError, string>;
export declare function psPrintProofScriptTerm(term: PsSyntaxTerm): Except<PsSourcePrintError, string>;
export declare function psPrintProofScriptBinder(binder: Prod<PsSyntaxBinderHead, PsSyntaxTerm>): Except<PsSourcePrintError, string>;
export declare function psPrintProofScriptStructureField(field: Prod<PsSyntaxBinderHead, PsSyntaxTerm>): Except<PsSourcePrintError, string>;
export declare function psPrintProofScriptSpaceJoinedSuffix(values: List<string>): string;
export declare function psPrintProofScriptMapConstructors(printConstructor: (_arg0: PsSyntaxInductiveConstructor) => Except<PsSourcePrintError, string>, constructors: List<PsSyntaxInductiveConstructor>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintProofScriptMapImports(printImport: (_arg0: PsSyntaxImport) => Except<PsSourcePrintError, string>, imports: List<PsSyntaxImport>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintProofScriptMapDeclarations(printDeclaration: (_arg0: PsSyntaxDeclaration) => Except<PsSourcePrintError, string>, declarations: List<PsSyntaxDeclaration>): Except<PsSourcePrintError, List<string>>;
export declare function psPrintProofScriptConstructor(constructor: PsSyntaxInductiveConstructor): Except<PsSourcePrintError, string>;
export declare function psPrintProofScriptDeclaration(declaration: PsSyntaxDeclaration): Except<PsSourcePrintError, string>;
export declare function psPrintProofScriptImport(sourceImport: PsSyntaxImport): Except<PsSourcePrintError, string>;
export declare function psPrintProofScriptAppendStrings(xs: List<string>, __ps_eta_0: List<string>): List<string>;
export declare function psPrintProofScriptModuleParts(sourceImports: List<PsSyntaxImport>, sourceDeclarations: List<PsSyntaxDeclaration>): Except<PsSourcePrintError, string>;
export declare function psPrintProofScriptModule(module: PsSyntaxModule): Except<PsSourcePrintError, string>;
export declare function psTranslateLeanToProofScript(source: string): Except<PsTranslationError, string>;
export declare function psTranslateProofScriptToLean(source: string): Except<PsTranslationError, string>;
export declare function psCanonicalizeLeanSource(source: string): Except<PsTranslationError, string>;
export declare function psCanonicalizeProofScriptSource(source: string): Except<PsTranslationError, string>;
export declare function psJsonConcat2(left: string, right: string): string;
export declare function psJsonConcat3(first: string, second: string, third: string): string;
export declare function psJsonCharCode(char: string): bigint;
export declare function psJsonCharEq(left: string, right: string): boolean;
export declare function psJsonStringAtEnd(value: string, position: bigint): boolean;
export declare function psJsonStringGet(value: string, position: bigint): string;
export declare function psJsonStringNext(value: string, position: bigint): bigint;
export declare function psJsonReverseCharsAcc(values: List<string>, __ps_eta_0: List<string>): List<string>;
export declare function psJsonReverseChars(values: List<string>): List<string>;
export declare function psJsonStringCharsAccWithFuel(fuel: bigint, __ps_eta_0: string, __ps_eta_1: bigint, __ps_eta_2: List<string>): List<string>;
export declare function psJsonStringCharsWithFuel(fuel: bigint, value: string, position: bigint): List<string>;
export declare function psJsonStringToChars(value: string): List<string>;
export declare function psJsonStringOfCharsAcc(chars: List<string>, __ps_eta_0: string): string;
export declare function psJsonStringOfChars(chars: List<string>): string;
export declare function psJsonCharListEq(left: List<string>, __ps_eta_0: List<string>): boolean;
export declare function psJsonStringEq(left: string, right: string): boolean;
export declare function psJsonNatInRange(value: bigint, lower: bigint, upper: bigint): boolean;
export declare function psJsonHexDigit(value: bigint): string;
export declare function psJsonEscapeControl(value: bigint): string;
export declare function psJsonEscapeChar(char: string): string;
export declare function psJsonEscapeChars(chars: List<string>): string;
export declare function psJsonQuote(value: string): string;
export declare function psJsonJoin(separator: string, values: List<string>): string;
export declare function psJsonArray(values: List<string>): string;
export declare function psJsonField(key: string, value: string): string;
export declare function psJsonMapObjectFields(fields: List<Prod<string, string>>): List<string>;
export declare function psJsonObject(sortedFields: List<Prod<string, string>>): string;
export declare function psJsonWhitespace(char: string): boolean;
export declare function psJsonSkipWhitespace(chars: List<string>): List<string>;
export declare function psJsonHexValue(char: string): Option<bigint>;
export declare function psJsonDecodeUnicode4(chars: List<string>): Except<PsJsonParseError, Prod<string, List<string>>>;
export declare function psJsonParseStringChars(fuel: bigint, __ps_eta_0: List<string>, __ps_eta_1: List<string>): Except<PsJsonParseError, Prod<string, List<string>>>;
export declare function psJsonDigit(char: string): boolean;
export declare function psJsonTakeDigits(chars: List<string>, __ps_eta_0: List<string>): Prod<List<string>, List<string>>;
export declare function psJsonParseNumber(chars: List<string>): Except<PsJsonParseError, PsJsonParseResult>;
export declare function psJsonConsumeLiteral(expected: List<string>, __ps_eta_0: List<string>): Option<List<string>>;
export declare function psJsonReverseValuesAcc(values: List<PsJsonValue>, __ps_eta_0: List<PsJsonValue>): List<PsJsonValue>;
export declare function psJsonReverseValues(values: List<PsJsonValue>): List<PsJsonValue>;
export declare function psJsonParseArrayWith(parseValue: (_arg0: bigint, _arg1: List<string>) => Except<PsJsonParseError, PsJsonParseResult>, fuel: bigint, __ps_eta_0: List<string>, __ps_eta_1: List<PsJsonValue>): Except<PsJsonParseError, PsJsonParseResult>;
export declare function psJsonReverseFieldsAcc(fields: List<Prod<string, PsJsonValue>>, __ps_eta_0: List<Prod<string, PsJsonValue>>): List<Prod<string, PsJsonValue>>;
export declare function psJsonReverseFields(fields: List<Prod<string, PsJsonValue>>): List<Prod<string, PsJsonValue>>;
export declare function psJsonParseObjectWith(parseValue: (_arg0: bigint, _arg1: List<string>) => Except<PsJsonParseError, PsJsonParseResult>, fuel: bigint, __ps_eta_0: List<string>, __ps_eta_1: List<Prod<string, PsJsonValue>>): Except<PsJsonParseError, PsJsonParseResult>;
export declare function psJsonParseValueWithFuelWorker(fallback: Except<PsJsonParseError, PsJsonParseResult>, fuel: bigint, __ps_eta_0: bigint, __ps_eta_1: List<string>): Except<PsJsonParseError, PsJsonParseResult>;
export declare function psJsonParseValueWithFuel(fallback: Except<PsJsonParseError, PsJsonParseResult>, fuel: bigint, input: List<string>): Except<PsJsonParseError, PsJsonParseResult>;
export declare function psJsonCharListLengthAcc(chars: List<string>, __ps_eta_0: bigint): bigint;
export declare function psJsonCharListLength(chars: List<string>): bigint;
export declare function psJsonParse(source: string): Except<PsJsonParseError, PsJsonValue>;
export declare function psJsonObjectFind(fields: List<Prod<string, PsJsonValue>>, __ps_eta_0: string): Option<PsJsonValue>;
export declare function psJsonGetField(value: PsJsonValue, key: string): Option<PsJsonValue>;
export declare function psJsonAsString(_eq0: PsJsonValue): Option<string>;
export declare function psJsonAsBool(_eq0: PsJsonValue): Option<boolean>;
export declare function psJsonAsNumberText(_eq0: PsJsonValue): Option<string>;
export declare function psJsonAsArray(_eq0: PsJsonValue): Option<List<PsJsonValue>>;
export declare function psJsonAsObject(_eq0: PsJsonValue): Option<List<Prod<string, PsJsonValue>>>;
export declare function psJsonCompareCharLists(leftChars: List<string>, __ps_eta_0: List<string>): PsJsonKeyOrder;
export declare function psJsonCompareKeys(left: string, right: string): PsJsonKeyOrder;
export declare function psJsonInsertObjectFieldInto(fields: List<Prod<string, PsJsonValue>>, __ps_eta_0: Prod<string, PsJsonValue>): Except<PsJsonEncodeError, List<Prod<string, PsJsonValue>>>;
export declare function psJsonInsertObjectField(field: Prod<string, PsJsonValue>, fields: List<Prod<string, PsJsonValue>>): Except<PsJsonEncodeError, List<Prod<string, PsJsonValue>>>;
export declare function psJsonSortObjectFields(fields: List<Prod<string, PsJsonValue>>): Except<PsJsonEncodeError, List<Prod<string, PsJsonValue>>>;
export declare function psJsonValidateCanonicalNumber(text: string): boolean;
export declare function psJsonEncodeValueList(encodeValue: (_arg0: PsJsonValue) => Except<PsJsonEncodeError, string>, values: List<PsJsonValue>): Except<PsJsonEncodeError, List<string>>;
export declare function psJsonEncodeFieldList(encodeValue: (_arg0: PsJsonValue) => Except<PsJsonEncodeError, string>, fields: List<Prod<string, PsJsonValue>>): Except<PsJsonEncodeError, List<Prod<string, string>>>;
export declare function psJsonEncodeCanonicalWithFuel(fuel: bigint, __ps_eta_0: PsJsonValue): Except<PsJsonEncodeError, string>;
export declare function psJsonEncodeCanonical(value: PsJsonValue): Except<PsJsonEncodeError, string>;
export declare function psJsonEncodeCanonicalText(value: PsJsonValue): Except<PsJsonEncodeError, string>;
export declare function psLevelSucc(level: PsLevel): PsLevel;
export declare function psExprAbstractFVarAtWorker(target: bigint, expr: PsExpr, __ps_eta_0: bigint): PsExpr;
export declare function psExprAbstractFVarAt(target: bigint, depth: bigint, expr: PsExpr): PsExpr;
export declare function psExprAbstractFVar(target: bigint, expr: PsExpr): PsExpr;
export declare function psExprLiftBVarsWorker(amount: bigint, expr: PsExpr, __ps_eta_0: bigint): PsExpr;
export declare function psExprLiftBVars(amount: bigint, cutoff: bigint, expr: PsExpr): PsExpr;
export declare function psExprInstantiateAtWorker(replacement: PsExpr, expr: PsExpr, __ps_eta_0: bigint): PsExpr;
export declare function psExprInstantiateAt(replacement: PsExpr, depth: bigint, expr: PsExpr): PsExpr;
export declare function psExprInstantiate1(body: PsExpr, replacement: PsExpr): PsExpr;
export declare function psBinderInfoEq(left: PsBinderInfo, right: PsBinderInfo): boolean;
export declare function psLiteralEq(left: PsLiteral, right: PsLiteral): boolean;
export declare function psLevelStructuralEq(left: PsLevel, __ps_eta_0: PsLevel): boolean;
export declare function psLevelListEq(left: List<PsLevel>, __ps_eta_0: List<PsLevel>): boolean;
export declare function psExprAlphaEq(left: PsExpr, __ps_eta_0: PsExpr): boolean;
export declare function psListLength<T0>(values: List<T0>): bigint;
export declare function psListIsEmpty<T0>(values: List<T0>): boolean;
export declare function psListAny<T0>(predicate: (_arg0: T0) => boolean, values: List<T0>): boolean;
export declare function psListReverseAcc<T0>(values: List<T0>, __ps_eta_0: List<T0>): List<T0>;
export declare function psListReverse<T0>(values: List<T0>): List<T0>;
export declare function psListAppend<T0>(left: List<T0>, __ps_eta_0: List<T0>): List<T0>;
export declare function psListMap<T0, T1>(convert: (_arg0: T0) => T1, values: List<T0>): List<T1>;
export declare function psListMapExcept<T0, T1, T2>(convert: (_arg0: T0) => Except<T2, T1>, values: List<T0>): Except<T2, List<T1>>;
export declare function psListTake<T0>(count: bigint, __ps_eta_0: List<T0>): List<T0>;
export declare function psListZip<T0, T1>(left: List<T0>, __ps_eta_0: List<T1>): List<Prod<T0, T1>>;
export declare function psDeclarationName(_eq0: PsDeclaration): PsName;
export declare function psDeclarationLevelParams(_eq0: PsDeclaration): List<PsName>;
export declare function psDeclarationType(_eq0: PsDeclaration): PsExpr;
export declare function psDeclarationValue(_eq0: PsDeclaration): Option<PsExpr>;
export declare function psDeclarationInductiveInfo(_eq0: PsDeclaration): Option<PsInductiveInfo>;
export declare function psDeclarationConstructorInfo(_eq0: PsDeclaration): Option<PsConstructorInfo>;
export declare function psDeclarationRecursorInfo(_eq0: PsDeclaration): Option<PsRecursorInfo>;
export declare function psEnvironmentHashStringWorker(fuel: bigint, __ps_eta_0: string, __ps_eta_1: bigint, __ps_eta_2: bigint): bigint;
export declare function psEnvironmentNameHash(name: PsName): bigint;
export declare function psEnvironmentIndexFindWorker(fuel: bigint, __ps_eta_0: PsEnvironmentIndex, __ps_eta_1: bigint): List<PsDeclaration>;
export declare function psEnvironmentIndexSetWorker(fuel: bigint, __ps_eta_0: PsEnvironmentIndex, __ps_eta_1: bigint, __ps_eta_2: List<PsDeclaration>): PsEnvironmentIndex;
export declare const psEnvironmentEmpty: PsEnvironment;
export declare function psEnvironmentFindInListWorker(declarations: List<PsDeclaration>, __ps_eta_0: PsName): Option<PsDeclaration>;
export declare function psEnvironmentFindInList(name: PsName, declarations: List<PsDeclaration>): Option<PsDeclaration>;
export declare function psEnvironmentFind(environment: PsEnvironment, name: PsName): Option<PsDeclaration>;
export declare function psEnvironmentFindInductive(environment: PsEnvironment, name: PsName): Option<PsInductiveInfo>;
export declare function psEnvironmentFindConstructor(environment: PsEnvironment, name: PsName): Option<PsConstructorInfo>;
export declare function psEnvironmentFindRecursor(environment: PsEnvironment, name: PsName): Option<PsRecursorInfo>;
export declare function psEnvironmentContains(environment: PsEnvironment, name: PsName): boolean;
export declare function psEnvironmentRemoveNameWorker(declarations: List<PsDeclaration>, __ps_eta_0: PsName): List<PsDeclaration>;
export declare function psEnvironmentRemoveName(name: PsName, declarations: List<PsDeclaration>): List<PsDeclaration>;
export declare function psEnvironmentIndexInsert(index: PsEnvironmentIndex, declaration: PsDeclaration): PsEnvironmentIndex;
export declare function psEnvironmentAddReplacingAxiom(environment: PsEnvironment, declaration: PsDeclaration): Option<PsEnvironment>;
export declare function psEnvironmentAdd(environment: PsEnvironment, declaration: PsDeclaration): Option<PsEnvironment>;
export declare function psCheckedAdmissionBoolNot(value: boolean): boolean;
export declare function psCheckedAdmissionJsonField(key: string, value: string): Prod<string, string>;
export declare function psCheckedAdmissionIncrementDecimalDigits(digits: List<bigint>): List<bigint>;
export declare function psCheckedAdmissionDecimalDigits(value: bigint): List<bigint>;
export declare function psCheckedAdmissionDecimalDigitsToString(digits: List<bigint>): string;
export declare function psCheckedAdmissionNatToString(value: bigint): string;
export declare function psEncodeCodecName(name: PsName): string;
export declare function psEncodeCodecLevel(level: PsLevel): Except<PsCheckedAdmissionCodecError, string>;
export declare function psEncodeCodecBinderInfo(binder: PsBinderInfo): string;
export declare function psEncodeCodecLevelList(levels: List<PsLevel>): Except<PsCheckedAdmissionCodecError, List<string>>;
export declare function psEncodeCodecLevels(levels: List<PsLevel>): Except<PsCheckedAdmissionCodecError, string>;
export declare function psEncodeCodecExpr(expr: PsExpr): Except<PsCheckedAdmissionCodecError, string>;
export declare function psEncodeCodecNames(names: List<PsName>): List<string>;
export declare function psEncodeCodecNameList(names: List<PsName>): string;
export declare function psBridgeFindConstructor(declarations: List<PsDeclaration>, __ps_eta_0: PsName): Option<PsConstructorInfo>;
export declare function psEncodeCodecConstructor(allDeclarations: List<PsDeclaration>, inductiveName: PsName, constructorName: PsName): Except<PsCheckedAdmissionCodecError, string>;
export declare function psEncodeCodecConstructors(allDeclarations: List<PsDeclaration>, inductiveName: PsName, constructors: List<PsName>): Except<PsCheckedAdmissionCodecError, List<string>>;
export declare function psEncodeCodecInductive(allDeclarations: List<PsDeclaration>, info: PsInductiveInfo): Except<PsCheckedAdmissionCodecError, string>;
export declare function psBridgeFindRegularHeightInBucket(entries: List<Prod<PsName, bigint>>, __ps_eta_0: PsName): bigint;
export declare function psBridgeHeightBucket(fuel: bigint, __ps_eta_0: PsBridgeHeightIndex, __ps_eta_1: bigint): List<Prod<PsName, bigint>>;
export declare function psBridgeHeightInsertWorker(fuel: bigint, __ps_eta_0: PsBridgeHeightIndex, __ps_eta_1: bigint, __ps_eta_2: PsName, __ps_eta_3: bigint): PsBridgeHeightIndex;
export declare function psBridgeHeightInsert(index: PsBridgeHeightIndex, name: PsName, height: bigint): PsBridgeHeightIndex;
export declare function psBridgeFindRegularHeight(index: PsBridgeHeightIndex, name: PsName): bigint;
export declare function psBridgeNatMax(left: bigint, __ps_eta_0: bigint): bigint;
export declare function psBridgeExprMaxRegularHeight(heights: PsBridgeHeightIndex, expr: PsExpr): bigint;
export declare function psEncodeCodecDefinition(name: PsName, levelParams: List<PsName>, type: PsExpr, value: PsExpr, height: bigint): Except<PsCheckedAdmissionCodecError, string>;
export declare function psEncodeCodecTheorem(name: PsName, levelParams: List<PsName>, type: PsExpr, value: PsExpr): Except<PsCheckedAdmissionCodecError, string>;
export declare function psEncodeConstantAdmission(declaration: string): string;
export declare function psEncodeInductiveAdmission(declaration: string): string;
export declare function psEncodeCheckedAdmissionsLoop(allDeclarations: List<PsDeclaration>, declarations: List<PsDeclaration>, __ps_eta_0: PsCheckedAdmissionEncodeState): Except<PsCheckedAdmissionCodecError, PsCheckedAdmissionEncodeState>;
export declare function psCheckedAdmissionReverseStringsAcc(values: List<string>, __ps_eta_0: List<string>): List<string>;
export declare function psCheckedAdmissionReverseStrings(values: List<string>): List<string>;
export declare function psCheckedNestedName(text: string): PsName;
export declare const psCheckedNestedUnitName: PsName;
export declare const psCheckedNestedLevelName: PsName;
export declare const psCheckedNestedLevel: PsLevel;
export declare const psCheckedNestedUnit: PsExpr;
export declare const psCheckedNestedUnitValue: PsExpr;
export declare function psCheckedNestedBind(lambda: boolean, binders: List<PsCheckedNestedBinder>, __ps_eta_0: PsExpr): PsExpr;
export declare function psCheckedNestedSize(expr: PsExpr): bigint;
export declare function psCheckedNestedOpenWorker(fuel: bigint, __ps_eta_0: bigint, __ps_eta_1: PsExpr): List<PsCheckedNestedBinder>;
export declare function psCheckedNestedOpen(id: bigint, type: PsExpr): List<PsCheckedNestedBinder>;
export declare function psCheckedNestedContains(name: PsName, expr: PsExpr): boolean;
export declare function psCheckedNestedDirect(name: PsName, type: PsExpr): boolean;
export declare function psCheckedNestedAdd(name: PsName, type: PsExpr, shapes: List<PsExpr>): List<PsExpr>;
export declare function psCheckedNestedAddTypes(name: PsName, types: List<PsExpr>, __ps_eta_0: List<PsExpr>): List<PsExpr>;
export declare function psCheckedNestedBinderType(binder: PsCheckedNestedBinder): PsExpr;
export declare function psCheckedNestedBinderExpr(binder: PsCheckedNestedBinder): PsExpr;
export declare function psCheckedNestedRoots(all: List<PsDeclaration>, name: PsName, constructors: List<PsName>, __ps_eta_0: List<PsExpr>): Except<PsCheckedAdmissionCodecError, List<PsExpr>>;
export declare function psCheckedNestedContainerFields(type: PsExpr): Except<PsCheckedAdmissionCodecError, List<List<PsExpr>>>;
export declare function psCheckedNestedConcat<T0>(lists: List<List<T0>>): List<T0>;
export declare function psCheckedNestedExpand(name: PsName, fuel: bigint, __ps_eta_0: List<PsExpr>, __ps_eta_1: List<PsExpr>): Except<PsCheckedAdmissionCodecError, List<PsExpr>>;
export declare function psCheckedNestedSizes(types: List<PsExpr>): bigint;
export declare function psCheckedNestedApply(args: List<PsExpr>, __ps_eta_0: PsExpr): PsExpr;
export declare function psCheckedNestedHypotheses(name: PsName, fields: List<PsCheckedNestedBinder>, __ps_eta_0: bigint): List<PsCheckedNestedBinder>;
export declare function psCheckedNestedDirectHypotheses(hypotheses: List<PsCheckedNestedBinder>): List<PsCheckedNestedBinder>;
export declare function psCheckedNestedMinors(all: List<PsDeclaration>, name: PsName, start: bigint, constructors: List<PsName>, __ps_eta_0: bigint): Except<PsCheckedAdmissionCodecError, List<PsCheckedNestedMinor>>;
export declare function psCheckedNestedMinorBinder(minor: PsCheckedNestedMinor): PsCheckedNestedBinder;
export declare function psCheckedNestedMinorAdapter(minor: PsCheckedNestedMinor): PsExpr;
export declare function psCheckedNestedFields(types: List<PsExpr>, __ps_eta_0: bigint): List<PsCheckedNestedBinder>;
export declare function psCheckedNestedAuxiliaryMinor(name: PsName, start: bigint, types: List<PsExpr>): PsExpr;
export declare function psCheckedNestedAuxiliaryMinors(name: PsName, start: bigint, shapes: List<PsExpr>): Except<PsCheckedAdmissionCodecError, List<PsExpr>>;
export declare function psCheckedNestedMotive(type: PsExpr): PsExpr;
export declare function psCheckedNestedWrapper(all: List<PsDeclaration>, info: PsInductiveInfo, shapes: List<PsExpr>): Except<PsCheckedAdmissionCodecError, PsDeclaration>;
export declare function psCheckedNestedCollect(all: List<PsDeclaration>, declarations: List<PsDeclaration>): Except<PsCheckedAdmissionCodecError, List<Prod<PsName, PsDeclaration>>>;
export declare function psCheckedNestedFind(wrappers: List<Prod<PsName, PsDeclaration>>, __ps_eta_0: PsName): Option<PsDeclaration>;
export declare function psCheckedNestedRewrite(wrappers: List<Prod<PsName, PsDeclaration>>, expr: PsExpr): PsExpr;
export declare function psCheckedNestedNormalize(wrappers: List<Prod<PsName, PsDeclaration>>, declarations: List<PsDeclaration>): List<PsDeclaration>;
export declare const psCheckedNestedUnitDeclarations: List<PsDeclaration>;
export declare function psEncodeCheckedAdmissionsNormalized(declarations: List<PsDeclaration>): Except<PsCheckedAdmissionCodecError, string>;
export declare function psEncodeCheckedAdmissionsCanonical(declarations: List<PsDeclaration>): Except<PsCheckedAdmissionCodecError, string>;
export declare function psEncodeCheckedAdmissionsText(declarations: List<PsDeclaration>): Except<PsCheckedAdmissionCodecError, string>;
export declare function psRootName(value: string): PsName;
export declare const psNatName: PsName;
export declare const psNatZeroName: PsName;
export declare const psNatSuccName: PsName;
export declare const psNatRecName: PsName;
export declare const psNatAddName: PsName;
export declare const psNatSubName: PsName;
export declare const psNatMulName: PsName;
export declare const psNatDivName: PsName;
export declare const psNatModName: PsName;
export declare const psNatBeqName: PsName;
export declare const psNatBleName: PsName;
export declare const psNatBltName: PsName;
export declare const psIntName: PsName;
export declare const psUInt8Name: PsName;
export declare const psUInt16Name: PsName;
export declare const psUInt32Name: PsName;
export declare const psUInt64Name: PsName;
export declare const psUSizeName: PsName;
export declare const psInt8Name: PsName;
export declare const psInt16Name: PsName;
export declare const psInt32Name: PsName;
export declare const psInt64Name: PsName;
export declare const psISizeName: PsName;
export declare const psFloatName: PsName;
export declare const psFloat32Name: PsName;
export declare const psIntOfNatName: PsName;
export declare const psIntNegSuccName: PsName;
export declare const psIntNegName: PsName;
export declare const psIntAddName: PsName;
export declare const psIntSubName: PsName;
export declare const psIntMulName: PsName;
export declare const psIntReprName: PsName;
export declare const psListName: PsName;
export declare const psOptionName: PsName;
export declare const psProdName: PsName;
export declare const psProdMkName: PsName;
export declare const psProdFstName: PsName;
export declare const psProdSndName: PsName;
export declare const psArrayName: PsName;
export declare const psArrayEmptyWithCapacityName: PsName;
export declare const psArraySizeName: PsName;
export declare const psArrayPushName: PsName;
export declare const psArrayGetInternalName: PsName;
export declare const psArrayGetDName: PsName;
export declare const psArraySetName: PsName;
export declare const psArraySetIfInBoundsName: PsName;
export declare const psArrayMapName: PsName;
export declare const psArrayFoldlName: PsName;
export declare const psStringName: PsName;
export declare const psBoolName: PsName;
export declare const psUnitName: PsName;
export declare const psBoolTrueName: PsName;
export declare const psBoolFalseName: PsName;
export declare const psEqName: PsName;
export declare const psDecidableName: PsName;
export declare const psBoolDecEqName: PsName;
export declare const psIteName: PsName;
export declare const psUnitUnitName: PsName;
export declare const psCharName: PsName;
export declare const psCharOfNatName: PsName;
export declare const psCharToNatName: PsName;
export declare const psStringPushName: PsName;
export declare const psStringSingletonName: PsName;
export declare const psStringInternalName: PsName;
export declare const psStringPosName: PsName;
export declare const psStringPosRawName: PsName;
export declare const psStringPosRawMkName: PsName;
export declare const psStringPosRawByteIdxName: PsName;
export declare const psStringLengthName: PsName;
export declare const psStringAppendName: PsName;
export declare const psStringUtf8ByteSizeName: PsName;
export declare const psStringNextName: PsName;
export declare const psStringGetName: PsName;
export declare const psStringAtEndName: PsName;
export declare const psStringExtractName: PsName;
export declare function psPreludeAdd(environment: PsEnvironment, declaration: PsDeclaration): PsEnvironment;
export declare const psPreludeUName: PsName;
export declare const psPreludeAlphaName: PsName;
export declare const psPreludeBetaName: PsName;
export declare const psPreludeFirstName: PsName;
export declare const psPreludeSecondName: PsName;
export declare const psPreludePairName: PsName;
export declare const psPreludeAName: PsName;
export declare const psPreludeBName: PsName;
export declare const psPreludePName: PsName;
export declare const psPreludeCName: PsName;
export declare const psPreludeHName: PsName;
export declare const psPreludeTName: PsName;
export declare const psPreludeEName: PsName;
export declare const psPreludeNName: PsName;
export declare const psPreludeTypeType: PsExpr;
export declare const psPreludePropType: PsExpr;
export declare const psPreludeNatType: PsExpr;
export declare const psPreludeIntType: PsExpr;
export declare const psPreludeStringType: PsExpr;
export declare const psPreludeBoolType: PsExpr;
export declare const psPreludeUnitType: PsExpr;
export declare const psPreludeCharType: PsExpr;
export declare const psPreludeUnaryTypeConstructorType: PsExpr;
export declare const psPreludeProdType: PsExpr;
export declare function psPreludeProdOf(alpha: PsExpr, beta: PsExpr): PsExpr;
export declare const psPreludeProdFstType: PsExpr;
export declare const psPreludeProdSndType: PsExpr;
export declare function psPreludeArrayOf(alpha: PsExpr): PsExpr;
export declare const psPreludeArrayType: PsExpr;
export declare const psPreludeArrayEmptyType: PsExpr;
export declare const psPreludeArraySizeType: PsExpr;
export declare const psPreludeArrayPushType: PsExpr;
export declare const psPreludeArrayGetDType: PsExpr;
export declare const psPreludeArraySetIfInBoundsType: PsExpr;
export declare const psPreludeAlphaToBeta: PsExpr;
export declare const psPreludeArrayMapType: PsExpr;
export declare const psPreludeFoldFunctionType: PsExpr;
export declare const psPreludeArrayFoldlType: PsExpr;
export declare const psPreludeEqType: PsExpr;
export declare const psPreludeDecidableType: PsExpr;
export declare const psPreludeEqAB: PsExpr;
export declare const psPreludeBoolDecEqType: PsExpr;
export declare const psPreludeIteType: PsExpr;
export declare const psPreludeNatUnaryType: PsExpr;
export declare const psPreludeNatBinaryType: PsExpr;
export declare const psPreludeNatBeqType: PsExpr;
export declare const psPreludeIntOfNatType: PsExpr;
export declare const psPreludeIntUnaryType: PsExpr;
export declare const psPreludeIntBinaryType: PsExpr;
export declare const psPreludeCharToNatType: PsExpr;
export declare const psPreludeStringPushType: PsExpr;
export declare const psPreludeStringSingletonType: PsExpr;
export declare const psPreludeStringUnaryNatType: PsExpr;
export declare const psPreludeStringBinaryType: PsExpr;
export declare const psPreludeStringPositionType: PsExpr;
export declare const psPreludeStringGetType: PsExpr;
export declare const psPreludeStringAtEndType: PsExpr;
export declare const psPreludeStringExtractType: PsExpr;
export declare const psPreludeCharOfNatType: PsExpr;
export declare const psPreludeNatMotiveName: PsName;
export declare const psPreludeNatMajorName: PsName;
export declare const psPreludeNatZeroMinorName: PsName;
export declare const psPreludeNatSuccMinorName: PsName;
export declare const psPreludeNatHypothesisName: PsName;
export declare const psPreludeNatMotiveType: PsExpr;
export declare const psPreludeNatZeroMinorType: PsExpr;
export declare const psPreludeNatSuccMinorType: PsExpr;
export declare const psPreludeNatRecType: PsExpr;
export declare const psPreludeEnv0: PsEnvironment;
export declare const psPreludeEnv1: PsEnvironment;
export declare const psPreludeEnvNatZero: PsEnvironment;
export declare const psPreludeEnvNatSucc: PsEnvironment;
export declare const psPreludeEnvNatRec: PsEnvironment;
export declare const psPreludeEnvNat1: PsEnvironment;
export declare const psPreludeEnvNat2: PsEnvironment;
export declare const psPreludeEnvNat3: PsEnvironment;
export declare const psPreludeEnvNat4: PsEnvironment;
export declare const psPreludeEnvNat5: PsEnvironment;
export declare const psPreludeEnvNat6: PsEnvironment;
export declare const psPreludeEnvNat7: PsEnvironment;
export declare const psPreludeEnvNat8: PsEnvironment;
export declare const psPreludeEnv2: PsEnvironment;
export declare const psPreludeEnv3: PsEnvironment;
export declare const psPreludeEnv4: PsEnvironment;
export declare const psPreludeEnv5: PsEnvironment;
export declare const psPreludeEnv6: PsEnvironment;
export declare const psPreludeEnv7: PsEnvironment;
export declare const psPreludeEnv8: PsEnvironment;
export declare const psPreludeEnvScalarUInt8: PsEnvironment;
export declare const psPreludeEnvScalarUInt16: PsEnvironment;
export declare const psPreludeEnvScalarUInt32: PsEnvironment;
export declare const psPreludeEnvScalarUInt64: PsEnvironment;
export declare const psPreludeEnvScalarUSize: PsEnvironment;
export declare const psPreludeEnvScalarInt8: PsEnvironment;
export declare const psPreludeEnvScalarInt16: PsEnvironment;
export declare const psPreludeEnvScalarInt32: PsEnvironment;
export declare const psPreludeEnvScalarInt64: PsEnvironment;
export declare const psPreludeEnvScalarISize: PsEnvironment;
export declare const psPreludeEnvScalarFloat: PsEnvironment;
export declare const psPreludeEnvScalarFloat32: PsEnvironment;
export declare const psPreludeEnv9: PsEnvironment;
export declare const psPreludeEnv10: PsEnvironment;
export declare const psPreludeEnv11: PsEnvironment;
export declare const psPreludeEnv12: PsEnvironment;
export declare const psPreludeEnv13: PsEnvironment;
export declare const psPreludeEnv14: PsEnvironment;
export declare const psPreludeEnv15: PsEnvironment;
export declare const psPreludeEnv16: PsEnvironment;
export declare const psPreludeEnvText0: PsEnvironment;
export declare const psPreludeEnvText1: PsEnvironment;
export declare const psPreludeEnvText2: PsEnvironment;
export declare const psPreludeEnvText3: PsEnvironment;
export declare const psPreludeEnvText4: PsEnvironment;
export declare const psPreludeEnvText5: PsEnvironment;
export declare const psPreludeEnvText6: PsEnvironment;
export declare const psPreludeEnvText7: PsEnvironment;
export declare const psPreludeEnvText8: PsEnvironment;
export declare const psPreludeEnvText9: PsEnvironment;
export declare const psPreludeEnvText10: PsEnvironment;
export declare const psPreludeEnvText11: PsEnvironment;
export declare const psPreludeEnvList0: PsEnvironment;
export declare const psPreludeEnvOption0: PsEnvironment;
export declare const psPreludeEnvProd0: PsEnvironment;
export declare const psPreludeEnvProd1: PsEnvironment;
export declare const psPreludeEnvProd2: PsEnvironment;
export declare const psPreludeEnvArray0: PsEnvironment;
export declare const psPreludeEnvArray1: PsEnvironment;
export declare const psPreludeEnvArray2: PsEnvironment;
export declare const psPreludeEnvArray3: PsEnvironment;
export declare const psPreludeEnvArray4: PsEnvironment;
export declare const psPreludeEnvArray5: PsEnvironment;
export declare const psPreludeEnvArray6: PsEnvironment;
export declare const psPreludeEnvArray7: PsEnvironment;
export declare const psPreludeEnv17: PsEnvironment;
export declare const psPreludeEnv18: PsEnvironment;
export declare const psPreludeEnv19: PsEnvironment;
export declare const psBootstrapPreludeEnvironment: PsEnvironment;
export declare const psSelfHostListNilName: PsName;
export declare const psSelfHostListConsName: PsName;
export declare const psSelfHostListRecName: PsName;
export declare const psSelfHostOptionNoneName: PsName;
export declare const psSelfHostOptionSomeName: PsName;
export declare const psSelfHostOptionRecName: PsName;
export declare const psSelfHostExceptName: PsName;
export declare const psSelfHostExceptErrorName: PsName;
export declare const psSelfHostExceptOkName: PsName;
export declare const psSelfHostExceptRecName: PsName;
export declare function psSelfHostListOf(alpha: PsExpr): PsExpr;
export declare function psSelfHostListNilOf(alpha: PsExpr): PsExpr;
export declare function psSelfHostListConsOf(alpha: PsExpr, head: PsExpr, tail: PsExpr): PsExpr;
export declare function psSelfHostOptionOf(alpha: PsExpr): PsExpr;
export declare function psSelfHostOptionNoneOf(alpha: PsExpr): PsExpr;
export declare function psSelfHostOptionSomeOf(alpha: PsExpr, value: PsExpr): PsExpr;
export declare function psSelfHostExceptOf(errorType: PsExpr, valueType: PsExpr): PsExpr;
export declare function psSelfHostExceptErrorOf(errorType: PsExpr, valueType: PsExpr, error: PsExpr): PsExpr;
export declare function psSelfHostExceptOkOf(errorType: PsExpr, valueType: PsExpr, value: PsExpr): PsExpr;
export declare function psSelfHostReplacePreludeAxiom(environment: PsEnvironment, declaration: PsDeclaration): PsEnvironment;
export declare const psSelfHostPreludeEnvironment: PsEnvironment;
export declare const psSelfHostRuntimePreludeDeclarations: List<PsDeclaration>;
export declare const psSelfHostProdRecName: PsName;
export declare function psSelfHostProdOf(alpha: PsExpr, beta: PsExpr): PsExpr;
export declare function psSelfHostProdMkOf(alpha: PsExpr, beta: PsExpr, fst: PsExpr, snd: PsExpr): PsExpr;
export declare const psSelfHostProdPreludeEnvironment: PsEnvironment;
export declare const psSelfHostRuntimePreludeDeclarationsWithProd: List<PsDeclaration>;
export declare const psLocalEmpty: PsLocalContext;
export declare function psLocalDeclId(_eq0: PsLocalDecl): bigint;
export declare function psLocalDeclType(_eq0: PsLocalDecl): PsExpr;
export declare function psLocalDeclUserName(_eq0: PsLocalDecl): PsName;
export declare function psLocalFindByIdInList(id: bigint, declarations: List<PsLocalDecl>): Option<PsLocalDecl>;
export declare function psLocalFindById(context: PsLocalContext, id: bigint): Option<PsLocalDecl>;
export declare function psLocalContainsId(context: PsLocalContext, id: bigint): boolean;
export declare function psLocalFindUserInList(userName: PsName, declarations: List<PsLocalDecl>): Option<PsLocalDecl>;
export declare function psLocalFindUser(context: PsLocalContext, userName: PsName): Option<PsLocalDecl>;
export declare function psLocalPushBinding(context: PsLocalContext, userName: PsName, type: PsExpr, binder: PsBinderInfo): PsLocalPushResult;
export declare function psLocalPushLet(context: PsLocalContext, userName: PsName, type: PsExpr, value: PsExpr): PsLocalPushResult;
export declare function psResolveName(localContext: PsLocalContext, environment: PsEnvironment, name: PsName): Option<PsResolvedName>;
export declare function psFindLevelArgumentWorker(parameters: List<PsName>, __ps_eta_0: List<PsLevel>, __ps_eta_1: PsName): Option<PsLevel>;
export declare function psFindLevelArgument(parameters: List<PsName>, _arguments: List<PsLevel>, target: PsName): Option<PsLevel>;
export declare function psLevelInstantiateParams(parameters: List<PsName>, _arguments: List<PsLevel>, level: PsLevel): PsLevel;
export declare function psLevelListInstantiateParams(parameters: List<PsName>, _arguments: List<PsLevel>, levels: List<PsLevel>): List<PsLevel>;
export declare function psExprInstantiateLevelParams(parameters: List<PsName>, _arguments: List<PsLevel>, expr: PsExpr): PsExpr;
export declare const psLevelMetaEmpty: PsLevelMetaContext;
export declare function psNatListContains(values: List<bigint>, target: bigint): boolean;
export declare function psLevelFindAssignmentInList(id: bigint, assignments: List<PsLevelAssignment>): Option<PsLevel>;
export declare function psLevelMetaFresh(context: PsLevelMetaContext): PsLevelFreshResult;
export declare function psLevelFindAssignment(context: PsLevelMetaContext, id: bigint): Option<PsLevel>;
export declare function psLevelAssignmentCount(assignments: List<PsLevelAssignment>): bigint;
export declare function psLevelInstantiateWithFuel(context: PsLevelMetaContext, fuel: bigint, __ps_eta_0: PsLevel): PsLevel;
export declare function psLevelInstantiate(context: PsLevelMetaContext, level: PsLevel): PsLevel;
export declare function psLevelOccursResolved(target: bigint, level: PsLevel): boolean;
export declare function psLevelOccurs(context: PsLevelMetaContext, target: bigint, level: PsLevel): boolean;
export declare function psLevelAssign(context: PsLevelMetaContext, id: bigint, value: PsLevel): Option<PsLevelMetaContext>;
export declare function psLevelUnifyWithFuelWorker(fuel: bigint, __ps_eta_0: PsLevelMetaContext, __ps_eta_1: PsLevel, __ps_eta_2: PsLevel): PsLevelUnifyResult;
export declare function psLevelUnifyWithFuel(context: PsLevelMetaContext, fuel: bigint, left: PsLevel, right: PsLevel): PsLevelUnifyResult;
export declare function psLevelUnify(context: PsLevelMetaContext, left: PsLevel, right: PsLevel): PsLevelUnifyResult;
export declare function psLevelInstantiateList(context: PsLevelMetaContext, levels: List<PsLevel>): List<PsLevel>;
export declare function psLevelInstantiateExpr(context: PsLevelMetaContext, expr: PsExpr): PsExpr;
export declare function psLevelHasMVar(level: PsLevel): boolean;
export declare function psLevelListHasMVar(levels: List<PsLevel>): boolean;
export declare const psMetaEmpty: PsMetaContext;
export declare function psMetaSnapshot(context: PsMetaContext): PsMetaContext;
export declare function psMetaRestore(_current: PsMetaContext, snapshot: PsMetaContext): PsMetaContext;
export declare function psMetaFindDeclInList(id: bigint, declarations: List<PsMetaVarDecl>): Option<PsMetaVarDecl>;
export declare function psMetaFindDecl(context: PsMetaContext, id: bigint): Option<PsMetaVarDecl>;
export declare function psMetaFindAssignmentInList(id: bigint, assignments: List<PsMetaAssignment>): Option<PsExpr>;
export declare function psMetaFindAssignment(context: PsMetaContext, id: bigint): Option<PsExpr>;
export declare function psMetaAssignmentListLength(assignments: List<PsMetaAssignment>): bigint;
export declare function psMetaFresh(context: PsMetaContext, localContext: PsLocalContext, type: PsExpr, kind: PsMetaVarKind): PsMetaFreshResult;
export declare function psExprContainsMVar(target: bigint, expr: PsExpr): boolean;
export declare function psExprFVarsInContext(localContext: PsLocalContext, expr: PsExpr): boolean;
export declare function psMetaInstantiateStep(context: PsMetaContext, expr: PsExpr): PsExpr;
export declare function psMetaExprHasAssignedVar(context: PsMetaContext, expr: PsExpr): boolean;
export declare function psMetaInstantiateRounds(context: PsMetaContext, fuel: bigint, __ps_eta_0: PsExpr): PsExpr;
export declare function psMetaInstantiate(context: PsMetaContext, expr: PsExpr): PsExpr;
export declare function psMetaFreshLevel(context: PsMetaContext): PsMetaFreshLevelResult;
export declare function psMetaAssign(context: PsMetaContext, id: bigint, value: PsExpr): Option<PsMetaContext>;
export declare function psExprHasUnresolvedMeta(expr: PsExpr): boolean;
export declare function psReduceNameListLength(values: List<PsName>): bigint;
export declare function psReduceLevelListLength(values: List<PsLevel>): bigint;
export declare function psWhnfCoreWithFuel(metaContext: PsMetaContext, localContext: PsLocalContext, fuel: bigint, __ps_eta_0: PsExpr): PsExpr;
export declare function psWhnfCore(metaContext: PsMetaContext, localContext: PsLocalContext, expr: PsExpr): PsExpr;
export declare function psDefEqReadOnly(metaContext: PsMetaContext, localContext: PsLocalContext, left: PsExpr, right: PsExpr): boolean;
export declare function psWhnfWithFuel(environment: PsEnvironment, metaContext: PsMetaContext, localContext: PsLocalContext, fuel: bigint, __ps_eta_0: PsExpr): PsExpr;
export declare function psWhnf(environment: PsEnvironment, metaContext: PsMetaContext, localContext: PsLocalContext, expr: PsExpr): PsExpr;
export declare function psDefEqReadOnlyWithEnvFuel(environment: PsEnvironment, metaContext: PsMetaContext, localContext: PsLocalContext, fuel: bigint, __ps_eta_0: PsExpr, __ps_eta_1: PsExpr): boolean;
export declare function psDefEqReadOnlyWithEnv(environment: PsEnvironment, metaContext: PsMetaContext, localContext: PsLocalContext, left: PsExpr, right: PsExpr): boolean;
export declare function psInferBoolNot(value: boolean): boolean;
export declare function psInferBoolOr(left: boolean, right: boolean): boolean;
export declare function psInferNatNe(left: bigint, right: bigint): boolean;
export declare function psInferExprListLength(values: List<PsExpr>): bigint;
export declare function psInferNameListLength(values: List<PsName>): bigint;
export declare function psInferLevelListLength(values: List<PsLevel>): bigint;
export declare function psInferEnsureSort(environment: PsEnvironment, metaContext: PsMetaContext, localContext: PsLocalContext, expr: PsExpr): Except<PsInferError, PsLevel>;
export declare function psInferEnsureForall(environment: PsEnvironment, metaContext: PsMetaContext, localContext: PsLocalContext, expr: PsExpr): Except<PsInferError, PsForallView>;
export declare function psInferAppViewAcc(expr: PsExpr, __ps_eta_0: List<PsExpr>): PsInferAppView;
export declare function psInferAppView(expr: PsExpr): PsInferAppView;
export declare function psInferApplyStructureParametersWorker(_arguments: List<PsExpr>, __ps_eta_0: PsEnvironment, __ps_eta_1: PsMetaContext, __ps_eta_2: PsLocalContext, __ps_eta_3: PsExpr): Except<PsInferError, PsExpr>;
export declare function psInferApplyStructureParameters(environment: PsEnvironment, metaContext: PsMetaContext, localContext: PsLocalContext, cursor: PsExpr, _arguments: List<PsExpr>): Except<PsInferError, PsExpr>;
export declare function psInferStructureProjectionFieldWorker(remainingFuel: bigint, __ps_eta_0: PsEnvironment, __ps_eta_1: PsMetaContext, __ps_eta_2: PsLocalContext, __ps_eta_3: PsName, __ps_eta_4: PsExpr, __ps_eta_5: bigint, __ps_eta_6: bigint, __ps_eta_7: PsExpr): Except<PsInferError, PsExpr>;
export declare function psInferStructureProjectionField(environment: PsEnvironment, metaContext: PsMetaContext, localContext: PsLocalContext, typeName: PsName, target: PsExpr, remainingFuel: bigint, requestedIndex: bigint, fieldIndex: bigint, cursor: PsExpr): Except<PsInferError, PsExpr>;
export declare function psInferProjectionType(environment: PsEnvironment, metaContext: PsMetaContext, localContext: PsLocalContext, targetType: PsExpr, typeName: PsName, index: bigint, target: PsExpr): Except<PsInferError, PsExpr>;
export declare function psInferTypeWithFuelWorker(remainingFuel: bigint, __ps_eta_0: PsEnvironment, __ps_eta_1: PsMetaContext, __ps_eta_2: PsLocalContext, __ps_eta_3: PsExpr): Except<PsInferError, PsExpr>;
export declare function psInferTypeWithFuel(environment: PsEnvironment, metaContext: PsMetaContext, localContext: PsLocalContext, fuel: bigint, expr: PsExpr): Except<PsInferError, PsExpr>;
export declare const psInferDefaultFuel: bigint;
export declare function psInferType(environment: PsEnvironment, metaContext: PsMetaContext, localContext: PsLocalContext, expr: PsExpr): Except<PsInferError, PsExpr>;
export declare const psInstanceIndexEmpty: PsInstanceIndex;
export declare function psInstanceListAppend(left: List<PsInstanceEntry>, right: List<PsInstanceEntry>): List<PsInstanceEntry>;
export declare function psInstanceIndexAdd(index: PsInstanceIndex, entry: PsInstanceEntry): PsInstanceIndex;
export declare function psLocalInstanceEntriesFromList(declarations: List<PsLocalDecl>): List<PsInstanceEntry>;
export declare function psLocalInstanceEntries(context: PsLocalContext): List<PsInstanceEntry>;
export declare function psAllInstanceEntries(context: PsLocalContext, index: PsInstanceIndex): List<PsInstanceEntry>;
export declare function psUnifySuccess(context: PsMetaContext): PsUnifyResult;
export declare function psUnifyFailure(context: PsMetaContext): PsUnifyResult;
export declare function psMetaSetLevels(context: PsMetaContext, levels: PsLevelMetaContext): PsMetaContext;
export declare function psMetaVarAssignable(context: PsMetaContext, id: bigint): boolean;
export declare function psMetaVarIsNatural(context: PsMetaContext, id: bigint): boolean;
export declare function psUnifyAssign(context: PsMetaContext, id: bigint, value: PsExpr): PsUnifyResult;
export declare function psUnifyLevelLists(leftLevels: List<PsLevel>, __ps_eta_0: PsMetaContext, __ps_eta_1: List<PsLevel>): PsUnifyResult;
export declare function psUnifyWithFuelWorker(fuel: bigint, __ps_eta_0: PsEnvironment, __ps_eta_1: PsLocalContext, __ps_eta_2: PsMetaContext, __ps_eta_3: PsExpr, __ps_eta_4: PsExpr): PsUnifyResult;
export declare function psUnifyWithFuel(environment: PsEnvironment, localContext: PsLocalContext, context: PsMetaContext, fuel: bigint, left: PsExpr, right: PsExpr): PsUnifyResult;
export declare function psUnify(environment: PsEnvironment, localContext: PsLocalContext, context: PsMetaContext, left: PsExpr, right: PsExpr): PsUnifyResult;
export declare function psSynthFailure(context: PsMetaContext): PsSynthInstanceResult;
export declare function psSynthSuccess(context: PsMetaContext, value: PsExpr): PsSynthInstanceResult;
export declare function psBinderInfoIsInstance(binder: PsBinderInfo): boolean;
export declare function psPreparedInstanceArgumentListReverseAux(remaining: List<PsPreparedInstanceArgument>, __ps_eta_0: List<PsPreparedInstanceArgument>): List<PsPreparedInstanceArgument>;
export declare function psPreparedInstanceArgumentListReverse(values: List<PsPreparedInstanceArgument>): List<PsPreparedInstanceArgument>;
export declare function psPrepareInstanceWithFuelWorker(remainingFuel: bigint, __ps_eta_0: PsEnvironment, __ps_eta_1: PsLocalContext, __ps_eta_2: PsMetaContext, __ps_eta_3: PsExpr, __ps_eta_4: PsExpr, __ps_eta_5: List<PsPreparedInstanceArgument>): PsPreparedInstance;
export declare function psPrepareInstanceWithFuel(environment: PsEnvironment, localContext: PsLocalContext, context: PsMetaContext, value: PsExpr, type: PsExpr, _arguments: List<PsPreparedInstanceArgument>, fuel: bigint): PsPreparedInstance;
export declare function psPrepareInstance(environment: PsEnvironment, localContext: PsLocalContext, context: PsMetaContext, entry: PsInstanceEntry): PsPreparedInstance;
export declare function psSolvePreparedInstanceArgumentsWorker(_arguments: List<PsPreparedInstanceArgument>, __ps_eta_0: (_arg0: PsMetaContext, _arg1: PsExpr) => PsSynthInstanceResult, __ps_eta_1: PsMetaContext): PsSolveInstanceArgsResult;
export declare function psSolvePreparedInstanceArguments(synthesize: (_arg0: PsMetaContext, _arg1: PsExpr) => PsSynthInstanceResult, _arguments: List<PsPreparedInstanceArgument>, current: PsMetaContext): PsSolveInstanceArgsResult;
export declare function psTryInstanceCandidate(environment: PsEnvironment, localContext: PsLocalContext, original: PsMetaContext, target: PsExpr, synthesize: (_arg0: PsMetaContext, _arg1: PsExpr) => PsSynthInstanceResult, entry: PsInstanceEntry): PsSynthInstanceResult;
export declare function psTryInstanceCandidatesWorker(entries: List<PsInstanceEntry>, __ps_eta_0: PsEnvironment, __ps_eta_1: PsLocalContext, __ps_eta_2: PsMetaContext, __ps_eta_3: PsExpr, __ps_eta_4: (_arg0: PsMetaContext, _arg1: PsExpr) => PsSynthInstanceResult): PsSynthInstanceResult;
export declare function psTryInstanceCandidates(environment: PsEnvironment, localContext: PsLocalContext, original: PsMetaContext, target: PsExpr, synthesize: (_arg0: PsMetaContext, _arg1: PsExpr) => PsSynthInstanceResult, entries: List<PsInstanceEntry>): PsSynthInstanceResult;
export declare function psSynthInstanceWithFuelWorker(remainingFuel: bigint, __ps_eta_0: PsEnvironment, __ps_eta_1: PsLocalContext, __ps_eta_2: PsInstanceIndex, __ps_eta_3: PsMetaContext, __ps_eta_4: PsExpr): PsSynthInstanceResult;
export declare function psSynthInstanceWithFuel(environment: PsEnvironment, localContext: PsLocalContext, index: PsInstanceIndex, context: PsMetaContext, fuel: bigint, target: PsExpr): PsSynthInstanceResult;
export declare function psSynthInstance(environment: PsEnvironment, localContext: PsLocalContext, index: PsInstanceIndex, context: PsMetaContext, target: PsExpr): PsSynthInstanceResult;
export declare function psElabStructuralRecursionFindCall(calls: List<Prod<bigint, bigint>>, fieldId: bigint): Option<bigint>;
export declare function psElabContextEmpty(environment: PsEnvironment): PsElabContext;
export declare function psElabContextWithLocal(context: PsElabContext, localContext: PsLocalContext): PsElabContext;
export declare function psElabContextWithMeta(context: PsElabContext, metaContext: PsMetaContext): PsElabContext;
export declare function psElabContextWithStructuralRecursion(context: PsElabContext, structuralRecursion: Option<PsElabStructuralRecursion>): PsElabContext;
export declare function psCharCodeEq(char: string, code: bigint): boolean;
export declare function psDecimalDigitValue(char: string): Option<bigint>;
export declare function psParseNaturalChars(chars: List<string>, __ps_eta_0: bigint): Option<bigint>;
export declare function psParseNaturalText(text: string): Option<bigint>;
export declare function psHexDigitValue(char: string): Option<bigint>;
export declare function psReadFixedHex(count: bigint, __ps_eta_0: List<string>, __ps_eta_1: bigint): Option<Prod<bigint, List<string>>>;
export declare function psValidUnicodeScalar(value: bigint): boolean;
export declare function psDecodeEscapedChar(count: bigint, rest: List<string>): Option<Prod<string, List<string>>>;
export declare function psStringFromReversedChars(charsRev: List<string>): string;
export declare function psDecodeStringBodyWithFuel(fuel: bigint, __ps_eta_0: List<string>, __ps_eta_1: List<string>): Option<string>;
export declare function psCharListLength(chars: List<string>): bigint;
export declare function psDecodeStringLiteral(text: string): Option<string>;
export declare function psDecodeCharacterEscape(escaped: string): Option<string>;
export declare function psDecodeCharacterEscapedTail(decoded: Option<Prod<string, List<string>>>): Option<string>;
export declare function psDecodeCharacterLiteral(text: string): Option<string>;
export declare function psElabBoolNot(value: boolean): boolean;
export declare function psElabBoolOr(left: boolean, right: boolean): boolean;
export declare function psElabBoolAnd(left: boolean, right: boolean): boolean;
export declare function psElabNatNe(left: bigint, right: bigint): boolean;
export declare function psElabListLength<T0>(values: List<T0>): bigint;
export declare function psSyntaxNameAppendSegments(segments: List<string>, __ps_eta_0: PsName): PsName;
export declare function psSyntaxNameToName(name: PsSyntaxName): Option<PsName>;
export declare function psElabResultWithMeta(result: PsElabTermResult, metaContext: PsMetaContext, type: PsExpr): PsElabTermResult;
export declare function psElabFinalizeExpected(result: PsElabTermResult, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabResolvedTerm(context: PsElabContext, term: PsExpr, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabProjectionApplyParameters(context: PsElabContext, parameters: List<PsExpr>, __ps_eta_0: PsExpr): Except<PsElabError, PsExpr>;
export declare function psElabFindStructureField(context: PsElabContext, typeName: PsName, target: PsExpr, fieldName: string, remaining: bigint, __ps_eta_0: bigint, __ps_eta_1: PsExpr): Except<PsElabError, bigint>;
export declare function psElabProjectionStep(context: PsElabContext, current: PsElabTermResult, fieldName: string): Except<PsElabError, PsElabTermResult>;
export declare function psElabProjectionChainWorker(fields: List<string>, __ps_eta_0: PsElabContext, __ps_eta_1: PsElabTermResult): Except<PsElabError, PsElabTermResult>;
export declare function psElabProjectionChain(context: PsElabContext, current: PsElabTermResult, fields: List<string>): Except<PsElabError, PsElabTermResult>;
export declare function psElabProjectionReference(context: PsElabContext, sourceName: PsSyntaxName, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabNamedReference(context: PsElabContext, sourceName: PsSyntaxName, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabReference(context: PsElabContext, sourceName: PsSyntaxName, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabNatural(context: PsElabContext, text: string, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabString(context: PsElabContext, text: string, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabCharacter(context: PsElabContext, text: string, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabUnit(context: PsElabContext, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabBool(context: PsElabContext, value: boolean, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabBinderKindToCore(_eq0: PsSyntaxBinderKind): PsBinderInfo;
export declare function psElabTypedBindersAcc(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, entries: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, __ps_eta_0: PsElabContext, __ps_eta_1: List<PsElabTypedBinder>): Except<PsElabError, PsElabTypedBindersResult>;
export declare function psElabTypedBinders(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, context: PsElabContext, binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>): Except<PsElabError, PsElabTypedBindersResult>;
export declare function psElabTypedBinderListReverseAux(remaining: List<PsElabTypedBinder>, __ps_eta_0: List<PsElabTypedBinder>): List<PsElabTypedBinder>;
export declare function psElabTypedBinderListReverse(values: List<PsElabTypedBinder>): List<PsElabTypedBinder>;
export declare function psCloseElabTypedBinders(metaContext: PsMetaContext, binders: List<PsElabTypedBinder>, __ps_eta_0: PsExpr, __ps_eta_1: PsExpr): Prod<PsExpr, PsExpr>;
export declare function psElabLambdaExpectedBody(binders: List<PsElabTypedBinder>, __ps_eta_0: PsElabContext, __ps_eta_1: PsExpr): Except<PsElabError, Prod<PsElabContext, PsExpr>>;
export declare function psElabLambdaBodyExpected(context: PsElabContext, binders: List<PsElabTypedBinder>, expected: Option<PsExpr>): Except<PsElabError, Prod<PsElabContext, Option<PsExpr>>>;
export declare function psElabLambda(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, context: PsElabContext, binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, body: PsSyntaxTerm, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psCloseElabForallBinders(metaContext: PsMetaContext, binders: List<PsElabTypedBinder>, __ps_eta_0: PsExpr): PsExpr;
export declare function psElabForall(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, context: PsElabContext, binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, body: PsSyntaxTerm, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabLetAfterValue(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, outerContext: PsElabContext, name: PsName, bindingType: PsExpr, valueResult: PsElabTermResult, body: PsSyntaxTerm, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabLet(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, context: PsElabContext, nameSyntax: PsSyntaxName, declaredType: Option<PsSyntaxTerm>, value: PsSyntaxTerm, body: PsSyntaxTerm, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psExprApplyManyWorker(_arguments: List<PsExpr>, __ps_eta_0: PsExpr): PsExpr;
export declare function psExprApplyMany(fn: PsExpr, _arguments: List<PsExpr>): PsExpr;
export declare function psElabIf(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, context: PsElabContext, condition: PsSyntaxTerm, thenBranch: PsSyntaxTerm, elseBranch: PsSyntaxTerm, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psExprAppViewAccWorker(expr: PsExpr, __ps_eta_0: List<PsExpr>): PsExprAppView;
export declare function psExprAppViewAcc(expr: PsExpr, args: List<PsExpr>): PsExprAppView;
export declare function psExprAppView(expr: PsExpr): PsExprAppView;
export declare function psExprHasConst(target: PsName, expr: PsExpr): boolean;
export declare function psMatchNameEqTarget(target: PsName, name: PsName): boolean;
export declare function psMatchNameListContains(names: List<PsName>, target: PsName): boolean;
export declare function psElabMatchAlternativeFind(name: PsName, alternatives: List<PsElabMatchAlternative>): Option<PsElabMatchAlternative>;
export declare function psElabMatchAlternativeCovered(alternatives: List<PsElabMatchAlternative>, ctorName: PsName): boolean;
export declare function psElabFillWildcardAlternatives(pattern: PsSyntaxPattern, body: PsSyntaxTerm, span: PsSourceSpan, constructors: List<PsName>, __ps_eta_0: List<PsElabMatchAlternative>): List<PsElabMatchAlternative>;
export declare function psElabMatchAlternativeListReverseAux(values: List<PsElabMatchAlternative>, __ps_eta_0: List<PsElabMatchAlternative>): List<PsElabMatchAlternative>;
export declare function psElabMatchAlternativeListReverse(values: List<PsElabMatchAlternative>): List<PsElabMatchAlternative>;
export declare function psElabMatchAlternativesCoverConstructors(alternatives: List<PsElabMatchAlternative>, constructors: List<PsName>): boolean;
export declare function psElabMatchPatternConstructorName(inductiveInfo: PsName, pattern: PsSyntaxPattern): Except<PsElabError, PsName>;
export declare function psElabPrepareMatchAlternativesWorker(inductiveInfo: PsInductiveInfo, entries: List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>, __ps_eta_0: List<PsElabMatchAlternative>): Except<PsElabError, List<PsElabMatchAlternative>>;
export declare function psElabPrepareMatchAlternatives(inductiveInfo: PsInductiveInfo, entries: List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>, alternativesRev: List<PsElabMatchAlternative>): Except<PsElabError, List<PsElabMatchAlternative>>;
export declare function psElabMatchApplyParametersWorker(context: PsElabContext, parameters: List<PsExpr>, __ps_eta_0: PsExpr): Except<PsElabError, PsExpr>;
export declare function psElabMatchApplyParameters(context: PsElabContext, parameters: List<PsExpr>, cursor: PsExpr): Except<PsElabError, PsExpr>;
export declare function psSyntaxNameIsWildcardBinder(name: PsSyntaxName): boolean;
export declare function psSyntaxNameMatchesCore(coreName: Option<PsName>, candidate: PsSyntaxName): boolean;
export declare function psSyntaxNameListContainsCore(coreName: Option<PsName>, candidates: List<PsSyntaxName>): boolean;
export declare function psSyntaxNameListHasDuplicate(names: List<PsSyntaxName>): boolean;
export declare function psElabMatchFieldsWorker(inductiveName: PsName, binderSyntaxes: List<PsSyntaxName>, __ps_eta_0: PsElabContext, __ps_eta_1: PsExpr, __ps_eta_2: List<PsElabMatchField>): Except<PsElabError, PsElabMatchFieldsResult>;
export declare function psElabMatchFields(context: PsElabContext, inductiveName: PsName, cursor: PsExpr, binderSyntaxes: List<PsSyntaxName>, fieldsRev: List<PsElabMatchField>): Except<PsElabError, PsElabMatchFieldsResult>;
export declare function psElabMatchFieldAtWorker(index: bigint, __ps_eta_0: List<PsElabMatchField>): Option<PsElabMatchField>;
export declare function psElabMatchFieldAt(fields: List<PsElabMatchField>, index: bigint): Option<PsElabMatchField>;
export declare function psElabPushRecursiveHypothesesWorker(expectedType: PsExpr, fields: List<PsElabMatchField>, fieldIndices: List<bigint>, __ps_eta_0: PsElabContext, __ps_eta_1: List<PsElabMatchField>): Except<PsElabError, PsElabMatchHypothesesResult>;
export declare function psElabPushRecursiveHypotheses(expectedType: PsExpr, fields: List<PsElabMatchField>, fieldIndices: List<bigint>, context: PsElabContext, hypothesesRev: List<PsElabMatchField>): Except<PsElabError, PsElabMatchHypothesesResult>;
export declare function psCloseElabMatchFieldsWorker(metaContext: PsMetaContext, fields: List<PsElabMatchField>, __ps_eta_0: PsExpr): PsExpr;
export declare function psCloseElabMatchFields(metaContext: PsMetaContext, fields: List<PsElabMatchField>, term: PsExpr): PsExpr;
export declare function psElabWildcardBinderNamesWorker(span: PsSourceSpan, remaining: bigint, __ps_eta_0: bigint): List<PsSyntaxName>;
export declare function psElabWildcardBinderNames(span: PsSourceSpan, index: bigint, remaining: bigint): List<PsSyntaxName>;
export declare function psElabMatchFieldListReverseWorker(fields: List<PsElabMatchField>, __ps_eta_0: List<PsElabMatchField>): List<PsElabMatchField>;
export declare function psElabMatchFieldListReverse(fields: List<PsElabMatchField>): List<PsElabMatchField>;
export declare function psElabMatchConstructorMinor(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, context: PsElabContext, inductiveInfo: PsInductiveInfo, inductiveLevels: List<PsLevel>, parameterArgs: List<PsExpr>, expectedType: PsExpr, constructorName: PsName, body: PsSyntaxTerm, span: PsSourceSpan, sourceBinders: Option<List<PsSyntaxName>>): Except<PsElabError, PsElabMatchMinorResult>;
export declare function psElabMatchMinor(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, context: PsElabContext, inductiveInfo: PsInductiveInfo, inductiveLevels: List<PsLevel>, parameterArgs: List<PsExpr>, expectedType: PsExpr, alternative: PsElabMatchAlternative): Except<PsElabError, PsElabMatchMinorResult>;
export declare function psElabMatchMinorsWorker(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, inductiveInfo: PsInductiveInfo, inductiveLevels: List<PsLevel>, parameterArgs: List<PsExpr>, expectedType: PsExpr, alternatives: List<PsElabMatchAlternative>, constructorNames: List<PsName>, __ps_eta_0: PsElabContext): Except<PsElabError, PsElabMatchMinorsResult>;
export declare function psElabMatchMinors(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, inductiveInfo: PsInductiveInfo, inductiveLevels: List<PsLevel>, parameterArgs: List<PsExpr>, expectedType: PsExpr, alternatives: List<PsElabMatchAlternative>, context: PsElabContext, constructorNames: List<PsName>): Except<PsElabError, PsElabMatchMinorsResult>;
export declare function psElabExprListAppendWorker(values: List<PsExpr>, __ps_eta_0: List<PsExpr>): List<PsExpr>;
export declare function psElabExprListAppend(left: List<PsExpr>, right: List<PsExpr>): List<PsExpr>;
export declare function psElabMatch(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, context: PsElabContext, scrutineeSyntax: PsSyntaxTerm, alternativesSyntax: List<Prod<PsSyntaxPattern, Prod<PsSyntaxTerm, PsSourceSpan>>>, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psBinderAcceptsExplicitArgument(binder: PsBinderInfo): boolean;
export declare function psBinderIsStrictImplicit(binder: PsBinderInfo): boolean;
export declare function psBinderIsInstanceImplicit(binder: PsBinderInfo): boolean;
export declare function psSyntaxTermListIsEmpty(values: List<PsSyntaxTerm>): boolean;
export declare function psElabApplyArgsWithFuelWorker(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, remainingFuel: bigint, __ps_eta_0: PsElabTermResult, __ps_eta_1: List<PsSyntaxTerm>, __ps_eta_2: List<bigint>): Except<PsElabError, PsElabApplicationResult>;
export declare function psElabApplyArgsWithFuel(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, remainingFuel: bigint, current: PsElabTermResult, _arguments: List<PsSyntaxTerm>, pendingInstancesRev: List<bigint>): Except<PsElabError, PsElabApplicationResult>;
export declare function psElabApplyArgs(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, current: PsElabTermResult, _arguments: List<PsSyntaxTerm>, pendingInstancesRev: List<bigint>): Except<PsElabError, PsElabApplicationResult>;
export declare function psElabSolvePendingInstancesWorker(pendingInstances: List<bigint>, __ps_eta_0: PsElabTermResult): Except<PsElabError, PsElabTermResult>;
export declare function psElabSolvePendingInstances(current: PsElabTermResult, pendingInstances: List<bigint>): Except<PsElabError, PsElabTermResult>;
export declare function psElabFinishApplication(application: PsElabApplicationResult, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabDropForallBindersWorker(remaining: bigint, __ps_eta_0: PsExpr): Option<PsExpr>;
export declare function psElabDropForallBinders(remaining: bigint, type: PsExpr): Option<PsExpr>;
export declare function psElabTakeForallNamesWorker(remaining: bigint, __ps_eta_0: PsExpr): Option<List<string>>;
export declare function psElabTakeForallNames(remaining: bigint, type: PsExpr): Option<List<string>>;
export declare function psSyntaxRecordLastSegment(segments: List<string>): Option<string>;
export declare function psSyntaxRecordFieldName(field: Prod<PsSyntaxName, PsSyntaxTerm>): Option<string>;
export declare function psSyntaxRecordFieldMatchesName(name: string, field: Prod<PsSyntaxName, PsSyntaxTerm>): boolean;
export declare function psSyntaxRecordHasField(fields: List<Prod<PsSyntaxName, PsSyntaxTerm>>, name: string): boolean;
export declare function psSyntaxRecordHasNamedField(fields: List<Prod<PsSyntaxName, PsSyntaxTerm>>, name: string): boolean;
export declare function psSyntaxRecordFieldsMatchWorker(names: List<string>, __ps_eta_0: List<Prod<PsSyntaxName, PsSyntaxTerm>>): boolean;
export declare function psSyntaxRecordFieldsMatch(fields: List<Prod<PsSyntaxName, PsSyntaxTerm>>, names: List<string>): boolean;
export declare function psSyntaxRecordFindField(fields: List<Prod<PsSyntaxName, PsSyntaxTerm>>, name: string): Option<PsSyntaxTerm>;
export declare function psSyntaxRecordOrderFields(fields: List<Prod<PsSyntaxName, PsSyntaxTerm>>, names: List<string>): Option<List<PsSyntaxTerm>>;
export declare function psElabRecordCandidateForInfo(environment: PsEnvironment, info: PsInductiveInfo): Option<PsElabRecordCandidate>;
export declare function psElabRecordCandidateFromExpected(context: PsElabContext, expected: PsExpr): Option<PsElabRecordCandidate>;
export declare function psElabRecordCandidates(environment: PsEnvironment, fields: List<Prod<PsSyntaxName, PsSyntaxTerm>>, declarations: List<PsDeclaration>, candidatesRev: List<PsElabRecordCandidate>): List<PsElabRecordCandidate>;
export declare function psElabUniqueRecordCandidate(environment: PsEnvironment, fields: List<Prod<PsSyntaxName, PsSyntaxTerm>>): Option<PsElabRecordCandidate>;
export declare function psElabRecord(elaborate: (_arg0: PsElabContext, _arg1: PsSyntaxTerm, _arg2: Option<PsExpr>) => Except<PsElabError, PsElabTermResult>, context: PsElabContext, fields: List<Prod<PsSyntaxName, PsSyntaxTerm>>, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabSyntaxLocalId(context: PsElabContext, _eq0: PsSyntaxTerm): Option<bigint>;
export declare function psElabNatListAtWorker(index: bigint, __ps_eta_0: List<bigint>): Option<bigint>;
export declare function psElabNatListAt(values: List<bigint>, index: bigint): Option<bigint>;
export declare function psElabValidateStructuralCallWorker(_arguments: List<PsSyntaxTerm>, __ps_eta_0: PsElabContext, __ps_eta_1: PsElabStructuralRecursion, __ps_eta_2: bigint, __ps_eta_3: Option<bigint>): Except<PsElabError, bigint>;
export declare function psElabValidateStructuralCall(context: PsElabContext, recursion: PsElabStructuralRecursion, index: bigint, _arguments: List<PsSyntaxTerm>, hypothesisId: Option<bigint>): Except<PsElabError, bigint>;
export declare function psTryElabStructuralSelfCall(context: PsElabContext, fn: PsSyntaxTerm, _arguments: List<PsSyntaxTerm>, expected: Option<PsExpr>): Except<PsElabError, Option<PsElabTermResult>>;
export declare function psElabTermWithFuel(fuel: bigint, __ps_eta_0: PsElabContext, __ps_eta_1: PsSyntaxTerm, __ps_eta_2: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabTerm(context: PsElabContext, term: PsSyntaxTerm, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabExplicitParameterIds(binders: List<PsElabTypedBinder>): List<bigint>;
export declare function psElabFindNatIndexWorker(target: bigint, values: List<bigint>, __ps_eta_0: bigint): Option<bigint>;
export declare function psElabFindNatIndex(target: bigint, values: List<bigint>, index: bigint): Option<bigint>;
export declare function psElabStructuralRecursionFromSource(functionName: PsName, bindersRev: List<PsElabTypedBinder>, body: PsSyntaxTerm, context: PsElabContext): Option<PsElabStructuralRecursion>;
export declare function psElabDeclarationTermCallback(context: PsElabContext, term: PsSyntaxTerm, expected: Option<PsExpr>): Except<PsElabError, PsElabTermResult>;
export declare function psElabDeclarationParts(environment: PsEnvironment, nameSyntax: PsSyntaxName, binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, typeSyntax: PsSyntaxTerm, valueSyntax: PsSyntaxTerm, isTheorem: boolean): Except<PsElabError, PsElabDeclarationResult>;
export declare function psSyntaxConstructorCoreName(inductiveName: PsName, sourceName: PsSyntaxName): Option<PsName>;
export declare function psElabInductiveConstructorNames(inductiveName: PsName, sources: List<PsSyntaxInductiveConstructor>): List<PsName>;
export declare function psElabContextWithEnvironment(context: PsElabContext, environment: PsEnvironment): PsElabContext;
export declare function psElabBinderArgument(binder: PsElabTypedBinder): PsExpr;
export declare function psElabBinderArgumentsInOrder(binders: List<PsElabTypedBinder>): List<PsExpr>;
export declare function psElabBinderArguments(bindersRev: List<PsElabTypedBinder>): List<PsExpr>;
export declare function psCloseElabImplicitBindersWorker(binders: List<PsElabTypedBinder>, __ps_eta_0: PsMetaContext, __ps_eta_1: PsExpr): PsExpr;
export declare function psCloseElabImplicitBinders(metaContext: PsMetaContext, binders: List<PsElabTypedBinder>, body: PsExpr): PsExpr;
export declare function psExprListAlphaEqWorker(left: List<PsExpr>, __ps_eta_0: List<PsExpr>): boolean;
export declare function psExprListAlphaEq(left: List<PsExpr>, right: List<PsExpr>): boolean;
export declare function psElabIsDirectRecursiveField(context: PsElabContext, inductiveName: PsName, parameterArgs: List<PsExpr>, type: PsExpr): boolean;
export declare function psElabContainerRecursiveName(name: PsName): boolean;
export declare function psElabNestedRecursiveFieldTypeSupportedWithFuel(fuel: bigint, __ps_eta_0: PsName, __ps_eta_1: PsExpr): boolean;
export declare function psElabNestedRecursiveFieldTypeSupported(inductiveName: PsName, type: PsExpr): boolean;
export declare function psElabReverseNatListAcc(values: List<bigint>, __ps_eta_0: List<bigint>): List<bigint>;
export declare function psElabReverseNatList(values: List<bigint>): List<bigint>;
export declare function psElabRecursiveFieldIndicesWorker(context: PsElabContext, inductiveName: PsName, parameterArgs: List<PsExpr>, fields: List<PsElabTypedBinder>, __ps_eta_0: bigint, __ps_eta_1: List<bigint>): Except<PsElabError, List<bigint>>;
export declare function psElabRecursiveFieldIndices(context: PsElabContext, inductiveName: PsName, parameterArgs: List<PsExpr>, fields: List<PsElabTypedBinder>, index: bigint, indicesRev: List<bigint>): Except<PsElabError, List<bigint>>;
export declare function psElabInductiveConstructor(context: PsElabContext, parameterBindersRev: List<PsElabTypedBinder>, inductiveName: PsName, source: PsSyntaxInductiveConstructor): Except<PsElabError, PsDeclaration>;
export declare function psSetConstructorIndex(index: bigint, declaration: PsDeclaration): PsDeclaration;
export declare function psElabReverseDeclarationsAcc(declarations: List<PsDeclaration>, __ps_eta_0: List<PsDeclaration>): List<PsDeclaration>;
export declare function psElabReverseDeclarations(declarations: List<PsDeclaration>): List<PsDeclaration>;
export declare function psElabInductiveConstructorsWorker(context: PsElabContext, parameterBindersRev: List<PsElabTypedBinder>, inductiveName: PsName, sources: List<PsSyntaxInductiveConstructor>, __ps_eta_0: bigint, __ps_eta_1: List<PsDeclaration>): Except<PsElabError, List<PsDeclaration>>;
export declare function psElabInductiveConstructors(context: PsElabContext, parameterBindersRev: List<PsElabTypedBinder>, inductiveName: PsName, index: bigint, sources: List<PsSyntaxInductiveConstructor>, declarationsRev: List<PsDeclaration>): Except<PsElabError, List<PsDeclaration>>;
export declare function psEnvironmentAddOwnedBootstrapDeclaration(environment: PsEnvironment, declaration: PsDeclaration): Option<PsEnvironment>;
export declare function psAddDeclarationListWorker(declarations: List<PsDeclaration>, __ps_eta_0: PsEnvironment): Except<PsElabError, PsEnvironment>;
export declare function psAddDeclarationList(environment: PsEnvironment, declarations: List<PsDeclaration>): Except<PsElabError, PsEnvironment>;
export declare function psOpenConstructorFieldsWorker(fuel: bigint, __ps_eta_0: PsElabContext, __ps_eta_1: PsExpr, __ps_eta_2: List<PsElabTypedBinder>): Except<PsElabError, PsElabConstructorBuildResult>;
export declare function psOpenConstructorFields(context: PsElabContext, fuel: bigint, cursor: PsExpr, bindersRev: List<PsElabTypedBinder>): Except<PsElabError, PsElabConstructorBuildResult>;
export declare function psElabExprAt(values: List<PsExpr>, __ps_eta_0: bigint): Option<PsExpr>;
export declare function psElabAppendExprs(left: List<PsExpr>, __ps_eta_0: List<PsExpr>): List<PsExpr>;
export declare function psElabAppendDeclarations(left: List<PsDeclaration>, __ps_eta_0: List<PsDeclaration>): List<PsDeclaration>;
export declare function psWrapRecursiveHypotheses(motiveId: bigint, fieldArgs: List<PsExpr>, indices: List<bigint>, body: PsExpr): Except<PsElabError, PsExpr>;
export declare function psBuildInductiveMinorType(context: PsElabContext, parameterArgs: List<PsExpr>, motiveId: bigint, declaration: PsDeclaration): Except<PsElabError, PsExpr>;
export declare function psBuildRecursorMinorBindersWorker(parameterArgs: List<PsExpr>, motiveId: bigint, declarations: List<PsDeclaration>, __ps_eta_0: PsElabContext, __ps_eta_1: bigint, __ps_eta_2: List<PsElabTypedBinder>): Except<PsElabError, PsElabRecursorMinorsResult>;
export declare function psBuildRecursorMinorBinders(parameterArgs: List<PsExpr>, motiveId: bigint, declarations: List<PsDeclaration>, context: PsElabContext, index: bigint, bindersRev: List<PsElabTypedBinder>): Except<PsElabError, PsElabRecursorMinorsResult>;
export declare function psBuildInductiveRecursor(context: PsElabContext, parameterBindersRev: List<PsElabTypedBinder>, inductiveInfo: PsInductiveInfo, constructors: List<PsDeclaration>): Except<PsElabError, PsDeclaration>;
export declare function psElabInductiveDeclaration(environment: PsEnvironment, nameSyntax: PsSyntaxName, params: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, resultType: Option<PsSyntaxTerm>, constructors: List<PsSyntaxInductiveConstructor>, isStructure: boolean): Except<PsElabError, PsElabDeclarationBatchResult>;
export declare function psElabStructureDeclaration(environment: PsEnvironment, name: PsSyntaxName, params: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, fields: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, span: PsSourceSpan): Except<PsElabError, PsElabDeclarationBatchResult>;
export declare function psElabPartialDeclaration(environment: PsEnvironment, nameSyntax: PsSyntaxName, binders: List<Prod<PsSyntaxBinderHead, PsSyntaxTerm>>, typeSyntax: PsSyntaxTerm, valueSyntax: PsSyntaxTerm): Except<PsElabError, PsElabDeclarationResult>;
export declare function psElabDeclaration(environment: PsEnvironment, source: PsSyntaxDeclaration): Except<PsElabError, PsElabDeclarationResult>;
export declare function psElabDeclarationBatch(environment: PsEnvironment, source: PsSyntaxDeclaration): Except<PsElabError, PsElabDeclarationBatchResult>;
export declare function psPrependBatchReverse(declarations: List<PsDeclaration>, declarationsRev: List<PsDeclaration>): List<PsDeclaration>;
export declare function psElabDeclarationsWorker(sources: List<PsSyntaxDeclaration>, __ps_eta_0: PsEnvironment, __ps_eta_1: List<PsDeclaration>): Except<PsElabError, PsElabModuleResult>;
export declare function psElabDeclarations(environment: PsEnvironment, sources: List<PsSyntaxDeclaration>, declarationsRev: List<PsDeclaration>): Except<PsElabError, PsElabModuleResult>;
export declare function psElabModule(environment: PsEnvironment, module: PsSyntaxModule): Except<PsElabError, PsElabModuleResult>;
export declare const psVerifiedIrModuleEmpty: PsVerifiedIrModule;
export declare function psErasureIndexBucket<T0>(fuel: bigint, __ps_eta_0: PsErasureNameIndex<T0>, __ps_eta_1: bigint): List<Prod<PsName, T0>>;
export declare function psErasureIndexSet<T0>(fuel: bigint, __ps_eta_0: PsErasureNameIndex<T0>, __ps_eta_1: bigint, __ps_eta_2: List<Prod<PsName, T0>>): PsErasureNameIndex<T0>;
export declare function psErasureIndexFindInBucket<T0>(entries: List<Prod<PsName, T0>>, __ps_eta_0: PsName): Option<T0>;
export declare function psErasureIndexFind<T0>(index: PsErasureNameIndex<T0>, name: PsName): Option<T0>;
export declare function psErasureIndexInsert<T0>(index: PsErasureNameIndex<T0>, name: PsName, value: T0): PsErasureNameIndex<T0>;
export declare function psErasureIndexPrepend<T0>(entries: List<Prod<PsName, T0>>, __ps_eta_0: PsErasureNameIndex<T0>): PsErasureNameIndex<T0>;
export declare function psErasureDeclarationNameIndex(entries: List<Prod<PsName, string>>): PsErasureDeclarationNames;
export declare const psErasureNatRecursor: PsRuntimeInductiveInfo;
export declare function psErasureScopeEmpty(declarationNames: List<Prod<PsName, string>>): PsErasureScope;
export declare function psErasureLookupRuntimeExpression(entries: List<Prod<bigint, PsVerifiedIrExpr>>, __ps_eta_0: bigint): Option<PsVerifiedIrExpr>;
export declare function psErasureLookupNat(entries: List<Prod<bigint, string>>, __ps_eta_0: bigint): Option<string>;
export declare function psErasureLookupName(entries: PsErasureDeclarationNames, name: PsName): Option<string>;
export declare function psErasureLookupStructure(entries: PsErasureNameIndex<PsRuntimeStructureInfo>, name: PsName): Option<PsRuntimeStructureInfo>;
export declare function psErasureLookupConstructor(entries: PsErasureNameIndex<PsRuntimeConstructorInfo>, name: PsName): Option<PsRuntimeConstructorInfo>;
export declare function psErasureLookupRecursor(entries: PsErasureNameIndex<PsRuntimeInductiveInfo>, name: PsName): Option<PsRuntimeInductiveInfo>;
export declare function psErasureNatInList(values: List<bigint>, __ps_eta_0: bigint): boolean;
export declare function psLevelNormalizesToZero(level: PsLevel): boolean;
export declare function psErasureNatNotEqual(left: bigint, right: bigint): boolean;
export declare function psErasureIsProp(environment: PsEnvironment, localContext: PsLocalContext, expr: PsExpr): boolean;
export declare function psErasureClassifyBinder(environment: PsEnvironment, localContext: PsLocalContext, type: PsExpr): PsErasedBinderKind;
export declare function psErasureNatBetween(lower: bigint, value: bigint, upper: bigint): boolean;
export declare function psErasureAsciiAlpha(char: string): boolean;
export declare function psErasureSafeChar(char: string): string;
export declare function psErasureSafeChars(chars: List<string>): List<string>;
export declare function psErasureSafeStringFromWithFuel(fuel: bigint, __ps_eta_0: string, __ps_eta_1: bigint, __ps_eta_2: string): string;
export declare function psErasureSafeStringFrom(raw: string, position: bigint, mapped: string): string;
export declare function psErasureSafeIdentifier(raw: string, fallback: string): string;
export declare function psErasureLocalNameUsed(scope: PsErasureScope, candidate: string): boolean;
export declare function psErasureLocalNameWithFuel(scope: PsErasureScope, base: string, fuel: bigint, __ps_eta_0: bigint): string;
export declare function psErasureLocalName(scope: PsErasureScope, raw: string, fallback: string, id: bigint): string;
export declare function psErasureAppViewAcc(expr: PsExpr, __ps_eta_0: List<PsExpr>): PsErasureAppView;
export declare function psErasureAppView(expr: PsExpr): PsErasureAppView;
export declare function psErasureExprListAtWorker(index: bigint, __ps_eta_0: List<PsExpr>): Option<PsExpr>;
export declare function psErasureExprListAt(values: List<PsExpr>, index: bigint): Option<PsExpr>;
export declare function psErasurePrimitiveType(name: PsName): Option<PsVerifiedIrType>;
export declare function psErasureMapRuntimeTypes(erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrType>, values: List<PsExpr>): Except<PsErasureError, List<PsVerifiedIrType>>;
export declare function psEraseRuntimeTypeWithFuelWorker(environment: PsEnvironment, fuel: bigint, __ps_eta_0: PsErasureScope, __ps_eta_1: PsExpr): Except<PsErasureError, PsVerifiedIrType>;
export declare function psEraseRuntimeTypeWithFuel(environment: PsEnvironment, scope: PsErasureScope, fuel: bigint, type: PsExpr): Except<PsErasureError, PsVerifiedIrType>;
export declare function psEraseRuntimeType(environment: PsEnvironment, scope: PsErasureScope, type: PsExpr): Except<PsErasureError, PsVerifiedIrType>;
export declare function psErasureAppendRuntimeArgument(_arguments: List<PsVerifiedIrExpr>, __ps_eta_0: PsVerifiedIrExpr): List<PsVerifiedIrExpr>;
export declare function psEraseApplicationArgumentsWorker(erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, environment: PsEnvironment, scope: PsErasureScope, _arguments: List<PsExpr>, __ps_eta_0: PsExpr, __ps_eta_1: PsErasureAppliedArguments): Except<PsErasureError, PsErasureAppliedArguments>;
export declare function psEraseApplicationArguments(erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, environment: PsEnvironment, scope: PsErasureScope, functionType: PsExpr, _arguments: List<PsExpr>, state: PsErasureAppliedArguments): Except<PsErasureError, PsErasureAppliedArguments>;
export declare function psEraseFinishApplicationWithFuelWorker(environment: PsEnvironment, fn: PsVerifiedIrExpr, typeArguments: List<PsVerifiedIrType>, fuel: bigint, __ps_eta_0: PsErasureScope, __ps_eta_1: PsExpr, __ps_eta_2: List<PsVerifiedIrParameter>, __ps_eta_3: List<PsVerifiedIrExpr>): Except<PsErasureError, PsVerifiedIrExpr>;
export declare function psEraseFinishApplicationWithFuel(environment: PsEnvironment, scope: PsErasureScope, fn: PsVerifiedIrExpr, typeArguments: List<PsVerifiedIrType>, fuel: bigint, functionType: PsExpr, parametersRev: List<PsVerifiedIrParameter>, runtimeArguments: List<PsVerifiedIrExpr>): Except<PsErasureError, PsVerifiedIrExpr>;
export declare function psEraseFinishApplication(environment: PsEnvironment, scope: PsErasureScope, fn: PsVerifiedIrExpr, typeArguments: List<PsVerifiedIrType>, runtimeArguments: List<PsVerifiedIrExpr>, remainingType: PsExpr): Except<PsErasureError, PsVerifiedIrExpr>;
export declare function psEraseMappedIntrinsic(erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, operation: PsVerifiedIrIntrinsic, _arguments: List<PsExpr>): Except<PsErasureError, PsVerifiedIrExpr>;
export declare function psEraseSelectedArguments(erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, _arguments: List<PsExpr>, indexes: List<bigint>): Except<PsErasureError, List<PsVerifiedIrExpr>>;
export declare function psEraseSelectedTypeArguments(environment: PsEnvironment, scope: PsErasureScope, _arguments: List<PsExpr>, indexes: List<bigint>): Except<PsErasureError, List<PsVerifiedIrType>>;
export declare function psEraseTypedIntrinsic(environment: PsEnvironment, scope: PsErasureScope, erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, operation: PsVerifiedIrIntrinsic, _arguments: List<PsExpr>, typeIndexes: List<bigint>, runtimeIndexes: List<bigint>): Except<PsErasureError, PsVerifiedIrExpr>;
export declare function psErasureBoolAnd(left: boolean, right: boolean): boolean;
export declare function psErasureBoolOr(left: boolean, right: boolean): boolean;
export declare function psErasureBoolNot(value: boolean): boolean;
export declare function psErasePrimitiveApplication(environment: PsEnvironment, scope: PsErasureScope, erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, view: PsErasureAppView): Except<PsErasureError, Option<PsVerifiedIrExpr>>;
export declare function psEraseCondition(erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, proposition: PsExpr): Except<PsErasureError, PsVerifiedIrExpr>;
export declare function psEraseIteApplication(erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, view: PsErasureAppView): Except<PsErasureError, Option<PsVerifiedIrExpr>>;
export declare function psErasureLookupTypeSubstitution(entries: List<Prod<string, PsVerifiedIrType>>, __ps_eta_0: string): Option<PsVerifiedIrType>;
export declare function psSubstituteVerifiedTypeWithFuel(substitutions: List<Prod<string, PsVerifiedIrType>>, fuel: bigint, __ps_eta_0: PsVerifiedIrType): PsVerifiedIrType;
export declare function psSubstituteVerifiedType(substitutions: List<Prod<string, PsVerifiedIrType>>, type: PsVerifiedIrType): PsVerifiedIrType;
export declare function psEraseRuntimeStructureFields(erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, _arguments: List<PsExpr>, fields: List<PsRuntimeStructureField>, __ps_eta_0: List<Prod<string, PsVerifiedIrExpr>>): Except<PsErasureError, List<Prod<string, PsVerifiedIrExpr>>>;
export declare function psEraseRuntimeStructureApplication(environment: PsEnvironment, scope: PsErasureScope, erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, view: PsErasureAppView): Except<PsErasureError, Option<PsVerifiedIrExpr>>;
export declare function psEraseRuntimeConstructorFields(erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, _arguments: List<PsExpr>, fields: List<PsRuntimeConstructorField>, __ps_eta_0: List<Prod<string, PsVerifiedIrExpr>>): Except<PsErasureError, List<Prod<string, PsVerifiedIrExpr>>>;
export declare function psEraseRuntimeConstructorApplication(environment: PsEnvironment, scope: PsErasureScope, erase: (_arg0: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, view: PsErasureAppView): Except<PsErasureError, Option<PsVerifiedIrExpr>>;
export declare function psOpenMatchMinorFields(environment: PsEnvironment, substitutions: List<Prod<string, PsVerifiedIrType>>, fields: List<PsRuntimeConstructorField>, __ps_eta_0: PsOpenMatchMinor): Except<PsErasureError, PsOpenMatchMinor>;
export declare function psErasureFindStringIndex(target: string, values: List<string>, __ps_eta_0: bigint): Option<bigint>;
export declare function psErasureRuntimeVariables(names: List<string>): List<PsVerifiedIrExpr>;
export declare function psErasureRecursiveCallArguments(names: List<string>, __ps_eta_0: bigint, __ps_eta_1: string): List<PsVerifiedIrExpr>;
export declare function psErasureFindMatchBinding(fieldName: string, bindings: List<PsVerifiedIrMatchBinding>): Option<PsVerifiedIrMatchBinding>;
export declare function psOpenMatchMinorHypotheses(environment: PsEnvironment, recursiveParameterIndex: Option<bigint>, bindings: List<PsVerifiedIrMatchBinding>, fields: List<PsRuntimeConstructorField>, __ps_eta_0: PsOpenMatchHypotheses): Except<PsErasureError, PsOpenMatchHypotheses>;
export declare function psEraseMatchMinor(environment: PsEnvironment, eraseAt: (_arg0: PsErasureScope, _arg1: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, scope: PsErasureScope, substitutions: List<Prod<string, PsVerifiedIrType>>, recursiveParameterIndex: Option<bigint>, ctorInfo: PsRuntimeConstructorInfo, minor: PsExpr): Except<PsErasureError, PsErasedMatchMinor>;
export declare function psEraseMatchAlternativesWorker(environment: PsEnvironment, eraseAt: (_arg0: PsErasureScope, _arg1: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, scope: PsErasureScope, substitutions: List<Prod<string, PsVerifiedIrType>>, recursiveParameterIndex: Option<bigint>, _arguments: List<PsExpr>, minorStart: bigint, constructors: List<PsRuntimeConstructorInfo>, __ps_eta_0: bigint, __ps_eta_1: List<Prod<string, Prod<List<PsVerifiedIrMatchBinding>, PsVerifiedIrExpr>>>): Except<PsErasureError, List<Prod<string, Prod<List<PsVerifiedIrMatchBinding>, PsVerifiedIrExpr>>>>;
export declare function psEraseMatchAlternatives(environment: PsEnvironment, eraseAt: (_arg0: PsErasureScope, _arg1: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, scope: PsErasureScope, substitutions: List<Prod<string, PsVerifiedIrType>>, recursiveParameterIndex: Option<bigint>, _arguments: List<PsExpr>, minorStart: bigint, index: bigint, constructors: List<PsRuntimeConstructorInfo>, alternativesRev: List<Prod<string, Prod<List<PsVerifiedIrMatchBinding>, PsVerifiedIrExpr>>>): Except<PsErasureError, List<Prod<string, Prod<List<PsVerifiedIrMatchBinding>, PsVerifiedIrExpr>>>>;
export declare function psEraseNatRecursorAlternatives(scrutinee: PsVerifiedIrExpr, alternatives: List<Prod<string, Prod<List<PsVerifiedIrMatchBinding>, PsVerifiedIrExpr>>>): Except<PsErasureError, PsVerifiedIrExpr>;
export declare function psEraseRuntimeRecursorApplication(environment: PsEnvironment, scope: PsErasureScope, eraseAt: (_arg0: PsErasureScope, _arg1: PsExpr) => Except<PsErasureError, PsVerifiedIrExpr>, view: PsErasureAppView): Except<PsErasureError, Option<PsVerifiedIrExpr>>;
export declare function psErasureFindProjectionField(index: bigint, fields: List<PsRuntimeStructureField>): Option<PsRuntimeStructureField>;
export declare function psErasureIrUsesNameWithFuel(fuel: bigint, __ps_eta_0: PsVerifiedIrExpr, __ps_eta_1: string): boolean;
export declare function psErasureEtaNameWithFuel(body: PsVerifiedIrExpr, used: List<PsVerifiedIrParameter>, fuel: bigint, __ps_eta_0: bigint): Except<PsErasureError, string>;
export declare function psErasureEtaParameters(body: PsVerifiedIrExpr, types: List<PsVerifiedIrType>, __ps_eta_0: List<PsVerifiedIrParameter>, __ps_eta_1: bigint): Except<PsErasureError, List<PsVerifiedIrParameter>>;
export declare function psErasureEtaFunction(parameters: List<PsVerifiedIrParameter>, resultType: PsVerifiedIrType, body: PsVerifiedIrExpr): Except<PsErasureError, PsVerifiedIrExpr>;
export declare function psEraseRuntimeExprWithFuelWorker(environment: PsEnvironment, fuel: bigint, __ps_eta_0: PsErasureScope, __ps_eta_1: PsExpr): Except<PsErasureError, PsVerifiedIrExpr>;
export declare function psEraseRuntimeExprWithFuel(environment: PsEnvironment, scope: PsErasureScope, fuel: bigint, expr: PsExpr): Except<PsErasureError, PsVerifiedIrExpr>;
export declare function psEraseRuntimeExpr(environment: PsEnvironment, scope: PsErasureScope, expr: PsExpr): Except<PsErasureError, PsVerifiedIrExpr>;
export declare function psPrepareInductiveParametersWithFuel(environment: PsEnvironment, fuel: bigint, __ps_eta_0: PsErasureScope, __ps_eta_1: PsExpr, __ps_eta_2: bigint, __ps_eta_3: bigint, __ps_eta_4: List<PsExpr>, __ps_eta_5: List<PsVerifiedIrTypeParameter>): Except<PsErasureError, PsPreparedInductiveParameters>;
export declare function psPrepareInductiveParameters(environment: PsEnvironment, scope: PsErasureScope, info: PsInductiveInfo): Except<PsErasureError, PsPreparedInductiveParameters>;
export declare function psApplyConstructorParameters(environment: PsEnvironment, scope: PsErasureScope, values: List<PsExpr>, __ps_eta_0: PsExpr): Except<PsErasureError, PsExpr>;
export declare function psPrepareConstructorFieldsWithFuel(environment: PsEnvironment, fuel: bigint, __ps_eta_0: PsErasureScope, __ps_eta_1: PsExpr, __ps_eta_2: bigint, __ps_eta_3: bigint, __ps_eta_4: List<PsRuntimeConstructorField>): Except<PsErasureError, PsPreparedConstructorFields>;
export declare function psPrepareConstructorFields(environment: PsEnvironment, scope: PsErasureScope, cursor: PsExpr, fieldCount: bigint): Except<PsErasureError, PsPreparedConstructorFields>;
export declare function psFindConstructorDeclaration(declarations: List<PsDeclaration>, __ps_eta_0: PsName): Option<PsConstructorInfo>;
export declare function psFindRecursorDeclaration(declarations: List<PsDeclaration>, __ps_eta_0: PsName): Option<PsRecursorInfo>;
export declare function psPrepareRuntimeConstructors(environment: PsEnvironment, declarations: List<PsDeclaration>, parameterScope: PsErasureScope, parameterValues: List<PsExpr>, inductiveName: string, names: List<PsName>, __ps_eta_0: List<PsRuntimeConstructorInfo>): Except<PsErasureError, List<PsRuntimeConstructorInfo>>;
export declare function psErasureAppendConstructorEntries(entries: List<Prod<PsName, PsRuntimeConstructorInfo>>, tail: PsErasureNameIndex<PsRuntimeConstructorInfo>): PsErasureNameIndex<PsRuntimeConstructorInfo>;
export declare function psPrepareRuntimeInductive(environment: PsEnvironment, declarations: List<PsDeclaration>, scope: PsErasureScope, info: PsInductiveInfo): Except<PsErasureError, PsPreparedInductiveResult>;
export declare function psPrepareRuntimeInductives(environment: PsEnvironment, declarations: List<PsDeclaration>, inputs: List<PsDeclaration>, __ps_eta_0: PsErasureScope, __ps_eta_1: List<PsVerifiedIrInductive>): Except<PsErasureError, PsPreparedInductivesResult>;
export declare function psPrepareRuntimeStructure(environment: PsEnvironment, declarations: List<PsDeclaration>, scope: PsErasureScope, info: PsInductiveInfo): Except<PsErasureError, PsPreparedStructureResult>;
export declare function psPrepareRuntimeStructures(environment: PsEnvironment, declarations: List<PsDeclaration>, inputs: List<PsDeclaration>, __ps_eta_0: PsErasureScope, __ps_eta_1: List<PsVerifiedIrStructure>): Except<PsErasureError, PsPreparedStructuresResult>;
export declare function psErasureStructureNameFromRecursor(name: PsName): Option<PsName>;
export declare function psErasureApplyStructureMinorFields(structureName: PsName, major: PsExpr, count: bigint, __ps_eta_0: bigint, __ps_eta_1: PsExpr): Except<PsErasureError, PsExpr>;
export declare function psTryLowerStructureRecursorApplication(environment: PsEnvironment, expr: PsExpr): Except<PsErasureError, Option<PsExpr>>;
export declare function psLowerStructureRecursorsWithFuel(environment: PsEnvironment, fuel: bigint, __ps_eta_0: PsExpr): Except<PsErasureError, PsExpr>;
export declare function psLowerStructureRecursors(environment: PsEnvironment, expr: PsExpr): Except<PsErasureError, PsExpr>;
export declare function psErasureStringInList(values: List<string>, __ps_eta_0: string): boolean;
export declare function psErasureAddUniqueStringWorker(used: List<string>, attempts: bigint, __ps_eta_0: string): string;
export declare function psErasureAddUniqueString(used: List<string>, base: string, attempts: bigint): string;
export declare function psBuildErasureDeclarationNamesWorker(declarations: List<PsDeclaration>, __ps_eta_0: PsErasureNameState): PsErasureNameState;
export declare function psBuildErasureDeclarationNames(declarations: List<PsDeclaration>, state: PsErasureNameState): PsErasureNameState;
export declare function psErasureReverseDeclarationNamesAcc(entries: List<Prod<PsName, string>>, __ps_eta_0: List<Prod<PsName, string>>): List<Prod<PsName, string>>;
export declare function psErasureDeclarationNames(declarations: List<PsDeclaration>): List<Prod<PsName, string>>;
export declare function psErasureReverseTypeParametersAcc(parameters: List<PsVerifiedIrTypeParameter>, __ps_eta_0: List<PsVerifiedIrTypeParameter>): List<PsVerifiedIrTypeParameter>;
export declare function psErasureReverseParametersAcc(parameters: List<PsVerifiedIrParameter>, __ps_eta_0: List<PsVerifiedIrParameter>): List<PsVerifiedIrParameter>;
export declare function psErasureAppendRuntimeParameter(parameters: List<string>, name: string): List<string>;
export declare function psEraseOpenDefinitionWithFuel(environment: PsEnvironment, fuel: bigint, __ps_eta_0: PsErasureScope, __ps_eta_1: PsExpr, __ps_eta_2: PsExpr, __ps_eta_3: bigint, __ps_eta_4: List<PsVerifiedIrTypeParameter>, __ps_eta_5: List<PsVerifiedIrParameter>): Except<PsErasureError, PsOpenedErasedDefinition>;
export declare function psEraseOpenDefinition(environment: PsEnvironment, scope: PsErasureScope, type: PsExpr, value: PsExpr): Except<PsErasureError, PsOpenedErasedDefinition>;
export declare function psEraseDefinition(environment: PsEnvironment, scope: PsErasureScope, name: PsName, type: PsExpr, value: PsExpr): Except<PsErasureError, Option<PsVerifiedIrDeclaration>>;
export declare function psErasureReverseIrDeclarationsAcc(declarations: List<PsVerifiedIrDeclaration>, __ps_eta_0: List<PsVerifiedIrDeclaration>): List<PsVerifiedIrDeclaration>;
export declare function psEraseDefinitionsLoopWorker(environment: PsEnvironment, scope: PsErasureScope, declarations: List<PsDeclaration>, __ps_eta_0: List<PsVerifiedIrDeclaration>): Except<PsErasureError, List<PsVerifiedIrDeclaration>>;
export declare function psEraseDefinitionsLoop(environment: PsEnvironment, scope: PsErasureScope, declarations: List<PsDeclaration>, declarationsRev: List<PsVerifiedIrDeclaration>): Except<PsErasureError, List<PsVerifiedIrDeclaration>>;
export declare function psErasureAppendDeclarations(declarations: List<PsDeclaration>, __ps_eta_0: List<PsDeclaration>): List<PsDeclaration>;
export declare function psEraseCoreModuleWithRuntimePrelude(environment: PsEnvironment, runtimePreludeDeclarations: List<PsDeclaration>, declarations: List<PsDeclaration>): Except<PsErasureError, PsVerifiedIrModule>;
export declare function psEraseCoreModule(environment: PsEnvironment, declarations: List<PsDeclaration>): Except<PsErasureError, PsVerifiedIrModule>;
export declare function psCompilerTranslateSource(sourceKind: PsCompilerSourceKind, targetKind: PsCompilerSourceKind, source: string): Except<PsCompilerError, string>;
export declare function psCompilerParseSource(sourceKind: PsCompilerSourceKind, source: string): Except<PsCompilerError, PsSyntaxModule>;
export declare function psCompilerElaborateModule(sourceModule: PsSyntaxModule): Except<PsCompilerError, PsElabModuleResult>;
export declare function psCompilerElaborateSource(sourceKind: PsCompilerSourceKind, source: string): Except<PsCompilerError, PsElabModuleResult>;
export declare function psCompilerPrepareElaborated(elaborated: PsElabModuleResult): Except<PsCompilerError, PsCompilerAdmissionReadyModule>;
export declare function psCompilerCheckElaborated(elaborated: PsElabModuleResult): Except<PsCompilerError, PsCompilerAdmissionReadyModule>;
export declare function psCompilerPrepareSource(sourceKind: PsCompilerSourceKind, source: string): Except<PsCompilerError, PsCompilerAdmissionReadyModule>;
export declare function psCompilerElaborateSourcesWorker(sourceKind: PsCompilerSourceKind, sources: List<string>, __ps_eta_0: PsEnvironment, __ps_eta_1: List<PsDeclaration>): Except<PsCompilerError, PsElabModuleResult>;
export declare function psCompilerPrepareSources(sourceKind: PsCompilerSourceKind, sources: List<string>): Except<PsCompilerError, PsCompilerAdmissionReadyModule>;
export declare function psCompilerCheckSource(sourceKind: PsCompilerSourceKind, source: string): Except<PsCompilerError, PsCompilerAdmissionReadyModule>;
export declare function psCompilerValidatePrepared(prepared: PsCompilerAdmissionReadyModule): Except<PsCompilerError, undefined>;
export declare function psCompilerAdmissionsFromPrepared(prepared: PsCompilerAdmissionReadyModule): Except<PsCompilerError, string>;
export declare function psCompilerAdmissionsFromElaborated(elaborated: PsElabModuleResult): Except<PsCompilerError, string>;
export declare function psCompilerAdmissionsSource(sourceKind: PsCompilerSourceKind, source: string): Except<PsCompilerError, string>;
export declare function psCompilerEnvironmentFromPrepared(prepared: PsCompilerAdmissionReadyModule): Except<PsCompilerError, PsEnvironment>;
export declare function psCompilerVerifiedIrFromPrepared(prepared: PsCompilerAdmissionReadyModule): Except<PsCompilerError, PsVerifiedIrModule>;
export declare function psCompilerVerifiedIrFromElaborated(elaborated: PsElabModuleResult): Except<PsCompilerError, PsVerifiedIrModule>;
export declare function psCompilerVerifiedIrSource(sourceKind: PsCompilerSourceKind, source: string): Except<PsCompilerError, PsVerifiedIrModule>;
export declare function psTsJoin(separator: string, values: List<string>): string;
export declare function psTsEmitPrimitiveType(type: PsVerifiedIrPrimitiveType): string;
export declare function psTsIndexTypesWorker(values: List<string>, __ps_eta_0: bigint): List<string>;
export declare function psTsIndexTypes(index: bigint, values: List<string>): List<string>;
export declare function psTsEmitTypeWithFuel(fuel: bigint, __ps_eta_0: PsVerifiedIrType): Except<PsTsEmitError, string>;
export declare function psTsEmitType(type: PsVerifiedIrType): Except<PsTsEmitError, string>;
export declare function psTsMachineIntegerUsesBigInt(type: PsVerifiedIrMachineIntegerType): boolean;
export declare function psTsEmitLiteral(literal: PsVerifiedIrLiteral): Except<PsTsEmitError, string>;
export declare function psTsLookup(entries: List<Prod<string, string>>, __ps_eta_0: string): Option<string>;
export declare function psTsExprUsesNameWithFuel(fuel: bigint, __ps_eta_0: PsVerifiedIrExpr, __ps_eta_1: string): boolean;
export declare function psTsFreshMatchTempWorker(expr: PsVerifiedIrExpr, attempts: bigint, __ps_eta_0: bigint): string;
export declare function psTsFreshMatchTempLoop(expr: PsVerifiedIrExpr, index: bigint, attempts: bigint): string;
export declare function psTsFreshMatchTemp(expr: PsVerifiedIrExpr): string;
export declare function psTsEmitTypeArguments(_arguments: List<PsVerifiedIrType>): Except<PsTsEmitError, string>;
export declare function psTsNormalizeMachineInteger(type: PsVerifiedIrMachineIntegerType, value: string): Except<PsTsEmitError, string>;
export declare function psTsMachineIntegerBinaryRaw(type: PsVerifiedIrMachineIntegerType, operation: PsVerifiedIrIntegerBinaryOp, left: string, right: string): string;
export declare function psTsEmitMachineIntegerBinary(type: PsVerifiedIrMachineIntegerType, operation: PsVerifiedIrIntegerBinaryOp, left: string, right: string): Except<PsTsEmitError, string>;
export declare function psTsEmitMachineIntegerCompare(operation: PsVerifiedIrIntegerCompareOp, left: string, right: string): string;
export declare function psTsEmitFloatBinary(type: PsVerifiedIrFloatingType, operation: PsVerifiedIrFloatBinaryOp, left: string, right: string): string;
export declare function psTsEmitFloatCompare(operation: PsVerifiedIrFloatCompareOp, left: string, right: string): string;
export declare function psTsPrinted1(emit: (_arg0: string) => Except<PsTsEmitError, string>, _arguments: List<string>): Except<PsTsEmitError, string>;
export declare function psTsPrinted2(emit: (_arg0: string, _arg1: string) => Except<PsTsEmitError, string>, _arguments: List<string>): Except<PsTsEmitError, string>;
export declare function psTsPrinted3(emit: (_arg0: string, _arg1: string, _arg2: string) => Except<PsTsEmitError, string>, _arguments: List<string>): Except<PsTsEmitError, string>;
export declare function psTsPrinted5(emit: (_arg0: string, _arg1: string, _arg2: string, _arg3: string, _arg4: string) => Except<PsTsEmitError, string>, _arguments: List<string>): Except<PsTsEmitError, string>;
export declare function psTsEmitIntrinsicFromPrinted(operation: PsVerifiedIrIntrinsic, _arguments: List<string>): Except<PsTsEmitError, string>;
export declare function psTsEmitLetStatements(emit: (_arg0: PsVerifiedIrExpr) => Except<PsTsEmitError, string>, expr: PsVerifiedIrExpr): Except<PsTsEmitError, string>;
export declare function psTsEmitExprWithFuel(brands: List<Prod<string, string>>, tags: List<Prod<string, string>>, fuel: bigint, __ps_eta_0: PsVerifiedIrExpr): Except<PsTsEmitError, string>;
export declare function psTsEmitExpr(brands: List<Prod<string, string>>, tags: List<Prod<string, string>>, expr: PsVerifiedIrExpr): Except<PsTsEmitError, string>;
export declare function psTsAppendLines(left: List<string>, __ps_eta_0: List<string>): List<string>;
export declare function psTsFreshInternalWorker(used: List<string>, namePrefix: string, attempts: bigint, __ps_eta_0: bigint): PsTsFreshNameResult;
export declare function psTsFreshInternalWithFuel(used: List<string>, namePrefix: string, index: bigint, attempts: bigint): PsTsFreshNameResult;
export declare function psTsFreshInternal(used: List<string>, namePrefix: string, index: bigint): PsTsFreshNameResult;
export declare function psTsBuildSymbolMap(namePrefix: string, names: List<string>, __ps_eta_0: PsTsSymbolMapState): PsTsSymbolMapState;
export declare function psTsStructureName(value: PsVerifiedIrStructure): string;
export declare function psTsInductiveName(value: PsVerifiedIrInductive): string;
export declare function psTsDeclarationName(value: PsVerifiedIrDeclaration): string;
export declare function psTsTypeParameterName(value: PsVerifiedIrTypeParameter): string;
export declare function psTsModuleTopLevelNames(module: PsVerifiedIrModule): List<string>;
export declare function psTsBuildBrandMap(module: PsVerifiedIrModule): List<Prod<string, string>>;
export declare function psTsBuildTagMap(module: PsVerifiedIrModule): List<Prod<string, string>>;
export declare function psTsGenericNames(parameters: List<PsVerifiedIrTypeParameter>): string;
export declare function psTsNameSequence(namePrefix: string, count: bigint, __ps_eta_0: bigint): List<string>;
export declare function psTsEmitStructure(brands: List<Prod<string, string>>, structureInfo: PsVerifiedIrStructure): Except<PsTsEmitError, List<string>>;
export declare function psTsEmitConstructorVariant(tag: string, constructorInfo: PsVerifiedIrConstructor): Except<PsTsEmitError, string>;
export declare function psTsEmitConstructorValue(tag: string, inductiveInfo: PsVerifiedIrInductive, constructorInfo: PsVerifiedIrConstructor): Except<PsTsEmitError, string>;
export declare function psTsEmitInductive(tags: List<Prod<string, string>>, inductiveInfo: PsVerifiedIrInductive): Except<PsTsEmitError, List<string>>;
export declare function psTsEmitImport(item: PsVerifiedIrExternalImport): string;
export declare const psTsStackRuntimeSupport: string;
export declare const psTsUtf8RuntimeSupport: string;
export declare const psTsRuntimeSupport: string;
export declare function psTsEtaArgumentsFresh(fn: PsVerifiedIrExpr, _arguments: List<PsVerifiedIrExpr>): boolean;
export declare function psTsEtaBind(parameters: List<PsVerifiedIrParameter>, __ps_eta_0: List<PsVerifiedIrExpr>, __ps_eta_1: PsVerifiedIrExpr): Option<PsVerifiedIrExpr>;
export declare function psTsEtaAlternatives(apply: (_arg0: PsVerifiedIrExpr) => Option<PsVerifiedIrExpr>, alternatives: List<Prod<string, Prod<List<PsVerifiedIrMatchBinding>, PsVerifiedIrExpr>>>): Option<List<Prod<string, Prod<List<PsVerifiedIrMatchBinding>, PsVerifiedIrExpr>>>>;
export declare function psTsEtaApplyWorker(_arguments: List<PsVerifiedIrExpr>, fuel: bigint, __ps_eta_0: PsVerifiedIrExpr): Option<PsVerifiedIrExpr>;
export declare function psTsInlineEtaApplication(expr: PsVerifiedIrExpr): PsVerifiedIrExpr;
export declare function psTsEmitDeclarationGeneral(brands: List<Prod<string, string>>, tags: List<Prod<string, string>>, declaration: PsVerifiedIrDeclaration): Except<PsTsEmitError, string>;
export declare function psTsCountLiteral(expected: bigint, expr: PsVerifiedIrExpr): boolean;
export declare function psTsCountRecursiveArgument(name: string, expr: PsVerifiedIrExpr): Option<string>;
export declare function psTsCountStepArgument(name: string, expr: PsVerifiedIrExpr): Option<string>;
export declare function psTsCountField(localName: string, bindings: List<PsVerifiedIrMatchBinding>): Option<string>;
export declare function psTsEmitCountCases(tag: string, name: string, base: Prod<string, Prod<List<PsVerifiedIrMatchBinding>, PsVerifiedIrExpr>>, step: Prod<string, Prod<List<PsVerifiedIrMatchBinding>, PsVerifiedIrExpr>>): Option<string>;
export declare function psTsEmitCountLoop(tags: List<Prod<string, string>>, declaration: PsVerifiedIrDeclaration): Option<string>;
export declare function psTsTailMap<T0, T1>(convert: (_arg0: T0) => Option<T1>, values: List<T0>): Option<List<T1>>;
export declare function psTsTailFindAlias(aliases: List<PsTsTailAlias>, name: string): Option<PsTsTailAlias>;
export declare function psTsTailParametersMatch(parameters: List<PsVerifiedIrParameter>, __ps_eta_0: List<PsVerifiedIrExpr>): boolean;
export declare function psTsTailAliasPrefix(parameters: List<PsVerifiedIrParameter>, _arguments: List<PsVerifiedIrExpr>): Option<List<PsVerifiedIrExpr>>;
export declare function psTsTailAliasValue(self: string, name: string, value: PsVerifiedIrExpr): Option<PsTsTailAlias>;
export declare function psTsTailPureWithFuel(aliases: List<PsTsTailAlias>, fuel: bigint, __ps_eta_0: PsVerifiedIrExpr): boolean;
export declare function psTsTailPrintPure(brands: List<Prod<string, string>>, tags: List<Prod<string, string>>, aliases: List<PsTsTailAlias>, expr: PsVerifiedIrExpr): Option<string>;
export declare function psTsTailBindingSafe(declaration: PsVerifiedIrDeclaration, aliases: List<PsTsTailAlias>, name: string): boolean;
export declare function psTsTailCallArguments(self: string, aliases: List<PsTsTailAlias>, fn: PsVerifiedIrExpr, _arguments: List<PsVerifiedIrExpr>): Option<List<PsVerifiedIrExpr>>;
export declare function psTsTailEmitWithFuel(brands: List<Prod<string, string>>, tags: List<Prod<string, string>>, declaration: PsVerifiedIrDeclaration, fuel: bigint, __ps_eta_0: List<PsTsTailAlias>, __ps_eta_1: PsVerifiedIrExpr): Option<string>;
export declare function psTsEmitTailLoop(brands: List<Prod<string, string>>, tags: List<Prod<string, string>>, declaration: PsVerifiedIrDeclaration): Option<string>;
export declare function psTsEmitDeclaration(brands: List<Prod<string, string>>, tags: List<Prod<string, string>>, declaration: PsVerifiedIrDeclaration): Except<PsTsEmitError, string>;
export declare function psTsFlattenLines(groups: List<List<string>>): List<string>;
export declare function psTsEmitModule(module: PsVerifiedIrModule): Except<PsTsEmitError, string>;
export declare function psCompilerTypeScriptFromPrepared(prepared: PsCompilerAdmissionReadyModule): Except<PsCompilerTypeScriptError, string>;
export declare function psCompilerTypeScriptFromElaborated(elaborated: PsElabModuleResult): Except<PsCompilerTypeScriptError, string>;
export declare function psCompilerTypeScriptSource(sourceKind: PsCompilerSourceKind, source: string): Except<PsCompilerTypeScriptError, string>;
export {};
