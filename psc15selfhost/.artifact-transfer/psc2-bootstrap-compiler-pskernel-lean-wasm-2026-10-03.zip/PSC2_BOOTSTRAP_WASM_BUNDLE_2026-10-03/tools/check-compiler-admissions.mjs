import { readFile } from 'node:fs/promises';
import { checkCanonicalAdmissions } from '../pskernel-lean-wasm/index.mjs';

const admissions = await readFile(
  new URL('../compiler/index.admissions.json', import.meta.url),
  'utf8',
);
const result = await checkCanonicalAdmissions(admissions);
if (result?.accepted !== true) {
  console.error(JSON.stringify(result, null, 2));
  throw new Error('PSC2_BUNDLE_COMPILER_ADMISSIONS_REJECTED');
}
console.log('PSC2_BUNDLE_COMPILER_ADMISSIONS: PASS');
console.log(JSON.stringify(result));
