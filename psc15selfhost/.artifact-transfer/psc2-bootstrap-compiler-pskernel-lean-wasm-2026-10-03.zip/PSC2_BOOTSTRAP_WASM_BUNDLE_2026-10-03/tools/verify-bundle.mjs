import { createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createKernel } from '../pskernel-lean-wasm/index.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const sha256 = data => createHash('sha256').update(data).digest('hex');
const manifest = JSON.parse(await readFile(path.join(root, 'BUNDLE_MANIFEST.json'), 'utf8'));

for (const entry of manifest.files) {
  const actual = sha256(await readFile(path.join(root, ...entry.path.split('/'))));
  if (actual !== entry.sha256) {
    throw new Error(`PSC2_BUNDLE_HASH_MISMATCH: ${entry.path}: ${actual}`);
  }
}
console.log(`PSC2_BUNDLE_HASHES: PASS (${manifest.files.length} files)`);

const receipt = JSON.parse(await readFile(path.join(root, 'compiler/index.checked.json'), 'utf8'));
if (receipt.sourceCount !== 55) throw new Error('PSC2_BUNDLE_SOURCE_COUNT');
if (receipt.sourceClosureSha256 !== 'ee6dd22f1b74b97113cc1a5e36aadad3cceecb2b152653f2c0dc26dd07aa22f7') {
  throw new Error('PSC2_BUNDLE_SOURCE_CLOSURE');
}
if (receipt.canonicalAdmissionsSha256 !== '8ba49927746a84c3925abebfbd62ecbdb78c05c3fe6a2c09c95ca29088044f22') {
  throw new Error('PSC2_BUNDLE_ADMISSIONS_IDENTITY');
}
if (receipt.typeScriptSha256 !== 'fb173a348d1555d1ff224b9977f6fee68591b79f781a6b292c2572648415b033') {
  throw new Error('PSC2_BUNDLE_TS_IDENTITY');
}
if (receipt.javaScriptSha256 !== '74dcebb7b296d81924d92987e99146b5d1c5ff9fbe3d8076ca591952d2ef7f76') {
  throw new Error('PSC2_BUNDLE_JS_IDENTITY');
}

async function countPs(dir) {
  let count = 0;
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) count += await countPs(p);
    else if (entry.isFile() && entry.name.endsWith('.ps')) count++;
  }
  return count;
}
const sourceCount = await countPs(path.join(root, 'compiler/workspace'));
if (sourceCount !== 55) throw new Error(`PSC2_BUNDLE_WORKSPACE_COUNT: ${sourceCount}`);

const kernel = await createKernel();
if (kernel.metadata?.status !== 'ok' ||
    kernel.metadata?.protocol !== 'pskernel-lean/1' ||
    kernel.metadata?.leanVersion !== '4.34.0' ||
    kernel.metadata?.leanCommit !== '293d5d0c0c3f3dded4688b3ccd6a33939ac5102b') {
  throw new Error('PSC2_BUNDLE_WASM_IDENTITY');
}
console.log('PSC2_BUNDLE_WASM_HEALTH: PASS');

const admissions = await readFile(path.join(root, 'compiler/index.admissions.json'), 'utf8');
if (sha256(admissions) !== receipt.canonicalAdmissionsSha256) {
  throw new Error('PSC2_BUNDLE_ADMISSIONS_HASH');
}
const checked = await kernel.checkCanonicalAdmissions(admissions);
if (checked?.accepted !== true) {
  console.error(JSON.stringify(checked, null, 2));
  throw new Error('PSC2_BUNDLE_COMPILER_ADMISSIONS_REJECTED');
}
console.log('PSC2_BUNDLE_COMPILER_ADMISSIONS: PASS');
console.log('PSC2_BUNDLE: PASS');
