# How it works

## Architecture

```text
55 canonical ProofScript compiler modules
                |
                v
     generated PSC2 compiler
       compiler/index.js
                |
       parse + elaborate
                |
                v
 canonical checked-admissions v2
                |
                v
   pskernel-lean-wasm (Node)
                |
                v
      Lean 4.34 WebAssembly
                |
        real Lean kernel
          /          \
       reject       accept
                      |
                      v
              compiler emission
```

## Compiler fixed point

The active bootstrap is intentionally compiler-only. Its composition root imports only
the TypeScript compiler composition; no kernel implementation belongs to the generated
bootstrap source closure.

The fixed point contains exactly 55 canonical `.ps` modules.

```text
source closure SHA-256
ee6dd22f1b74b97113cc1a5e36aadad3cceecb2b152653f2c0dc26dd07aa22f7

generated TypeScript SHA-256
fb173a348d1555d1ff224b9977f6fee68591b79f781a6b292c2572648415b033

generated JavaScript SHA-256
74dcebb7b296d81924d92987e99146b5d1c5ff9fbe3d8076ca591952d2ef7f76
```

The generated bootstrap compiler re-emitted the same 55 source modules and reproduced
the same TypeScript bytes.

## Kernel boundary

The compiler does not send source code to Lean for parsing. It serializes elaborated
core declarations into canonical checked-admissions v2. This is the stable provider
boundary.

The bundled provider is pinned to:

```text
@proofscript/pskernel-lean-wasm@4.34.0
protocol: pskernel-lean/1
provider: lean4-cpp
Lean: 4.34.0
Lean commit: 293d5d0c0c3f3dded4688b3ccd6a33939ac5102b
profile: lean4.34-core
Emscripten: 6.0.9
```

The checked-build receipt records the exact compiler source closure, admissions hash,
generated TS/JS hashes, and kernel identity.

## Fail-closed behavior

Kernel rejection is authoritative for that checked build. Rejection does not silently
fall back to another provider, and code generation is not promoted as checked output
after a failed kernel gate.

## What this bundle claims

It demonstrates a working self-hosted **compiler** plus a working external Lean-WASM
kernel assurance path.

It does not claim that Lean-WASM is itself bootstrapped by PSC2, and it does not claim
a joint compiler/kernel self-hosting fixed point.
