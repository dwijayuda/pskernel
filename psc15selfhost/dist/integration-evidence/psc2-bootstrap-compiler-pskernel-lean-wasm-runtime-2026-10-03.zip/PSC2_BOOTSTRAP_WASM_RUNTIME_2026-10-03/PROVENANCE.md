# Provenance

Bundle date: 2026-10-03

Repository:

```text
https://github.com/dwijayuda/pskernel
branch: psc2/selfhost-lean-kernel
```

The runtime artifacts were copied from the successful checked-bootstrap worktree whose
compiler fixed point was recorded at commit:

```text
d4298a712d1e2ea6505185d311e9af10a698b2ca
Record compiler-only self-host fixed point
```

Later native-provider performance commits do not change the bundled compiler or
Lean-WASM runtime.

## Compiler

```text
source modules: 55
source closure:
ee6dd22f1b74b97113cc1a5e36aadad3cceecb2b152653f2c0dc26dd07aa22f7

canonical admissions hash recorded by checked receipt:
8ba49927746a84c3925abebfbd62ecbdb78c05c3fe6a2c09c95ca29088044f22

TypeScript:
fb173a348d1555d1ff224b9977f6fee68591b79f781a6b292c2572648415b033

JavaScript:
74dcebb7b296d81924d92987e99146b5d1c5ff9fbe3d8076ca591952d2ef7f76
```

## Lean-WASM provider

```text
package: @proofscript/pskernel-lean-wasm@4.34.0
Lean: 4.34.0
Lean commit: 293d5d0c0c3f3dded4688b3ccd6a33939ac5102b
Emscripten: 6.0.9
provider source revision:
1b21b2483df7e8de7542873c24eaff2501539b1b
```

See `pskernel-lean-wasm/PREBUILT_WASM_MANIFEST.json` for the exact launcher and
WASM byte hashes.
