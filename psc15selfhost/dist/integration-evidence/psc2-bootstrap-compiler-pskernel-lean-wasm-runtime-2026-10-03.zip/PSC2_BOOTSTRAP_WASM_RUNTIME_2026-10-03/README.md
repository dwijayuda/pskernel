# PSC2 working bootstrap compiler + pskernel-lean-wasm

Portable runtime bundle for the completed compiler-only PSC2 bootstrap.

It contains:

- the generated self-hosted compiler: `compiler/index.js`;
- its successful Lean-WASM checked receipt: `compiler/index.checked.json`;
- the complete 55-module canonical ProofScript compiler workspace;
- the prebuilt `@proofscript/pskernel-lean-wasm@4.34.0` runtime;
- manifests identifying the exact Lean/provider/toolchain sources;
- standalone verification and compiler→kernel smoke tests;
- architecture and usage documentation.

This is the **compiler-only bootstrap architecture**. The kernel is an external
pinned Lean 4.34 assurance provider and is not part of the generated compiler closure.

## Quick start

Requirement: Node.js 20 or newer.

```text
node tools/verify-bundle.mjs
```

Expected:

```text
PSC2_RUNTIME_BUNDLE_HASHES: PASS
PSC2_RUNTIME_BUNDLE_COMPILER: PASS
PSC2_RUNTIME_BUNDLE_WASM_HEALTH: PASS
PSC2_RUNTIME_BUNDLE_COMPILER_KERNEL_SMOKE: PASS
PSC2_RUNTIME_BUNDLE_REJECTION: PASS
PSC2_RUNTIME_BUNDLE: PASS
```

You can also run:

```text
node tools/compiler-kernel-smoke.mjs
node pskernel-lean-wasm/wasm/pskernel-lean.cjs --health
```

See `HOW_IT_WORKS.md`, `USAGE.md`, and `PROVENANCE.md`.
