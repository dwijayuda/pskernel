# Usage

## Requirements

Only Node.js 20+ is required for the bundled runtime.

You do **not** need Lean, Lake, CMake, Emscripten, or a C++ compiler unless you
deliberately rebuild the kernel provider.

## Verify the complete bundle

```text
node tools/verify-bundle.mjs
```

This verifies all ZIP contents by SHA-256, validates the compiler receipt, confirms
the 55-source workspace, starts the Lean-WASM provider, compiles a small ProofScript
definition with the generated compiler, sends the compiler-produced canonical
admissions into Lean-WASM, and finally proves that an ill-typed admission is rejected.

## Compiler + kernel smoke test

```text
node tools/compiler-kernel-smoke.mjs
```

The smoke program compiles:

```proofscript
def bundleSmoke : Nat := 1;
```

through the bundled generated PSC2 compiler. It obtains canonical checked-admissions
JSON from the compiler and passes that JSON to `pskernel-lean-wasm`. Success requires
Lean 4.34 kernel acceptance.

## Inspect kernel identity

```text
node pskernel-lean-wasm/wasm/pskernel-lean.cjs --health
```

Expected identity:

```text
protocol    pskernel-lean/1
provider    lean4-cpp
Lean        4.34.0
profile     lean4.34-core
```

## Use the generated compiler from JavaScript

```js
import * as compiler from './compiler/index.js';

const source = 'def example : Nat := 7;\n';

const admissions = compiler.psCompilerAdmissionsSource(
  compiler.PsCompilerSourceKind.proofScript,
  source,
);

if (!('value' in admissions)) {
  console.error(admissions);
  process.exit(1);
}

console.log(admissions.value);
```

Other important generated APIs include:

- `psCompilerParseSource`
- `psCompilerElaborateSource`
- `psCompilerPrepareSource`
- `psCompilerPrepareSources`
- `psCompilerAdmissionsSource`
- `psCompilerAdmissionsFromPrepared`
- `psCompilerTypeScriptSource`
- `psCompilerTypeScriptFromPrepared`

For multi-module projects, provide the complete ordered source closure. The included
`compiler/workspace/` directory is the exact 55-module canonical compiler closure
that reached the fixed point.

## Use the WASM provider API

```js
import { checkCanonicalAdmissions } from './pskernel-lean-wasm/index.mjs';

const result = await checkCanonicalAdmissions(admissionsJson);
if (!result.accepted) {
  console.error(result);
}
```

No fallback occurs on rejection or provider failure.
