import * as compiler from '../compiler/index.js';
import { checkCanonicalAdmissions } from '../pskernel-lean-wasm/index.mjs';

const source = 'def bundleSmoke : Nat := 1;\n';
const generated = compiler.psCompilerAdmissionsSource(
  compiler.PsCompilerSourceKind.proofScript,
  source,
);
if (!generated || typeof generated !== 'object' || typeof generated.value !== 'string') {
  console.error(generated);
  throw new Error('PSC2_RUNTIME_BUNDLE_COMPILER_SMOKE_FAILED');
}
const checked = await checkCanonicalAdmissions(generated.value);
if (checked?.accepted !== true) {
  console.error(checked);
  throw new Error('PSC2_RUNTIME_BUNDLE_KERNEL_SMOKE_FAILED');
}
console.log('PSC2_RUNTIME_BUNDLE_COMPILER_KERNEL_SMOKE: PASS');
