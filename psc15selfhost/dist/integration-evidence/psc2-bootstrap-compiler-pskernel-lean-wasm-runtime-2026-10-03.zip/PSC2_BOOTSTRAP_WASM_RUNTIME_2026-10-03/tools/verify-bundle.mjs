import { createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createKernel } from '../pskernel-lean-wasm/index.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const sha256 = data => createHash('sha256').update(data).digest('hex');
const manifest = JSON.parse(await readFile(path.join(root, 'BUNDLE_MANIFEST.json'), 'utf8'));

for (const entry of manifest.files) {
  const actual = sha256(await readFile(path.join(root, ...entry.path.split('/'))));
  if (actual !== entry.sha256) throw new Error(`HASH_MISMATCH: ${entry.path}`);
}
console.log(`PSC2_RUNTIME_BUNDLE_HASHES: PASS (${manifest.files.length} files)`);

const receipt = JSON.parse(await readFile(path.join(root, 'compiler/index.checked.json'), 'utf8'));
const compilerPath = path.join(root, 'compiler/index.js');
if (receipt.sourceCount !== 55) throw new Error('SOURCE_COUNT');
if (receipt.sourceClosureSha256 !== 'ee6dd22f1b74b97113cc1a5e36aadad3cceecb2b152653f2c0dc26dd07aa22f7') throw new Error('SOURCE_CLOSURE');
if (sha256(await readFile(compilerPath)) !== '74dcebb7b296d81924d92987e99146b5d1c5ff9fbe3d8076ca591952d2ef7f76') throw new Error('COMPILER_JS_HASH');

async function countPs(dir) {
  let n = 0;
  for (const e of await readdir(dir, {withFileTypes:true})) {
    const p = path.join(dir,e.name);
    if (e.isDirectory()) n += await countPs(p);
    else if (e.isFile() && e.name.endsWith('.ps')) n++;
  }
  return n;
}
if (await countPs(path.join(root,'compiler/workspace')) !== 55) throw new Error('WORKSPACE_COUNT');

const compiler = await import(pathToFileURL(compilerPath).href);
for (const name of ['psCompilerPrepareSource','psCompilerAdmissionsSource','psCompilerTypeScriptSource']) {
  if (typeof compiler[name] !== 'function') throw new Error(`COMPILER_API_MISSING: ${name}`);
}
console.log('PSC2_RUNTIME_BUNDLE_COMPILER: PASS');

const kernel = await createKernel();
if (kernel.metadata?.status !== 'ok' ||
    kernel.metadata?.protocol !== 'pskernel-lean/1' ||
    kernel.metadata?.provider !== 'lean4-cpp' ||
    kernel.metadata?.leanVersion !== '4.34.0' ||
    kernel.metadata?.leanCommit !== '293d5d0c0c3f3dded4688b3ccd6a33939ac5102b') {
  throw new Error('WASM_IDENTITY');
}
console.log('PSC2_RUNTIME_BUNDLE_WASM_HEALTH: PASS');

const source = 'def bundleSmoke : Nat := 1;\n';
const generated = compiler.psCompilerAdmissionsSource(
  compiler.PsCompilerSourceKind.proofScript, source);
if (typeof generated?.value !== 'string') throw new Error('COMPILER_SMOKE');
const checked = await kernel.checkCanonicalAdmissions(generated.value);
if (checked?.accepted !== true) throw new Error('KERNEL_SMOKE');
console.log('PSC2_RUNTIME_BUNDLE_COMPILER_KERNEL_SMOKE: PASS');

const bad = JSON.stringify({
  protocol:'pskernel-lean/1',
  format:'proofscript-checked-admissions',
  version:2,
  admissions:[{kind:'constant',declaration:{
    h:{h:'1',k:'regular'}, k:'definition', lp:[],
    n:{k:'s',p:{k:'a'},v:'Bundle.Bad'}, s:'safe',
    t:{k:'const',ls:[],n:{k:'s',p:{k:'a'},v:'Nat'}},
    v:{k:'sort',l:{k:'z'}}
  }}]
});
const rejected = await kernel.checkCanonicalAdmissions(bad);
if (rejected?.accepted !== false || rejected?.errorKind !== 'kernel-rejection') {
  throw new Error('FAIL_CLOSED_REJECTION');
}
console.log('PSC2_RUNTIME_BUNDLE_REJECTION: PASS');
console.log('PSC2_RUNTIME_BUNDLE: PASS');
