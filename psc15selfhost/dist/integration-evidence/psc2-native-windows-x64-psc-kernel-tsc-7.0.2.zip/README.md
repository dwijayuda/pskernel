# ProofScript native toolchain (win32-x64)

This directory is a platform-specific native PSC toolchain.

- `bin/psc.exe` — PSC compiler built by Lean 4.34.
- `bin/pskernel-lean.exe` — native Lean 4.34 kernel provider.
- `typescript/lib/tsc.exe` — native TypeScript 7.0.2 compiler.
- `typescript/lib/lib*.d.ts` — TypeScript standard-library declarations.

The native PSC executable auto-detects the bundled TypeScript compiler relative to
its own executable path, so normal `psc build` does not require Node.

Examples:

    bin/psc.exe --version
    bin/psc.exe check example.ps
    bin/psc.exe build example.ps --out example.js
    bin/pskernel-lean.exe --health
    typescript/lib/tsc.exe --version

The default checked profile in the source repository is `lean434` (native).
WASM remains the explicit portable alternative `lean434-wasm`.

The kernel remains outside the 55-module compiler bootstrap closure.
